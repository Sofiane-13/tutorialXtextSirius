/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Layout</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Layout#getName <em>Name</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Layout#getTitre <em>Titre</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Layout#getContient <em>Contient</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Layout#getStyle <em>Style</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Layout#getStyleB <em>Style B</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getLayout()
 * @model
 * @generated
 */
public interface Layout extends Elements
{
  /**
   * Returns the value of the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' attribute.
   * @see #setName(String)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getLayout_Name()
   * @model
   * @generated
   */
  String getName();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Layout#getName <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name</em>' attribute.
   * @see #getName()
   * @generated
   */
  void setName(String value);

  /**
   * Returns the value of the '<em><b>Titre</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Titre</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Titre</em>' attribute.
   * @see #setTitre(String)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getLayout_Titre()
   * @model
   * @generated
   */
  String getTitre();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Layout#getTitre <em>Titre</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Titre</em>' attribute.
   * @see #getTitre()
   * @generated
   */
  void setTitre(String value);

  /**
   * Returns the value of the '<em><b>Contient</b></em>' reference list.
   * The list contents are of type {@link org.xtext.UnivTlemcen.pfe.pfe.Elements}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Contient</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Contient</em>' reference list.
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getLayout_Contient()
   * @model
   * @generated
   */
  EList<Elements> getContient();

  /**
   * Returns the value of the '<em><b>Style</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Style</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Style</em>' reference.
   * @see #setStyle(StyleView)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getLayout_Style()
   * @model
   * @generated
   */
  StyleView getStyle();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Layout#getStyle <em>Style</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Style</em>' reference.
   * @see #getStyle()
   * @generated
   */
  void setStyle(StyleView value);

  /**
   * Returns the value of the '<em><b>Style B</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Style B</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Style B</em>' reference.
   * @see #setStyleB(StyleView)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getLayout_StyleB()
   * @model
   * @generated
   */
  StyleView getStyleB();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Layout#getStyleB <em>Style B</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Style B</em>' reference.
   * @see #getStyleB()
   * @generated
   */
  void setStyleB(StyleView value);

} // Layout
