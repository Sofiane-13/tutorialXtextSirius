/**
 */
package org.xtext.UnivTlemcen.pfe.pfe.util;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

import org.xtext.UnivTlemcen.pfe.pfe.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage
 * @generated
 */
public class PfeSwitch<T> extends Switch<T>
{
  /**
   * The cached model package
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected static PfePackage modelPackage;

  /**
   * Creates an instance of the switch.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public PfeSwitch()
  {
    if (modelPackage == null)
    {
      modelPackage = PfePackage.eINSTANCE;
    }
  }

  /**
   * Checks whether this is a switch for the given package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @parameter ePackage the package in question.
   * @return whether this is a switch for the given package.
   * @generated
   */
  @Override
  protected boolean isSwitchFor(EPackage ePackage)
  {
    return ePackage == modelPackage;
  }

  /**
   * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the first non-null result returned by a <code>caseXXX</code> call.
   * @generated
   */
  @Override
  protected T doSwitch(int classifierID, EObject theEObject)
  {
    switch (classifierID)
    {
      case PfePackage.APPLICATION:
      {
        Application application = (Application)theEObject;
        T result = caseApplication(application);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.CONTROLEUR:
      {
        Controleur controleur = (Controleur)theEObject;
        T result = caseControleur(controleur);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.FONCTIONS:
      {
        Fonctions fonctions = (Fonctions)theEObject;
        T result = caseFonctions(fonctions);
        if (result == null) result = caseControleur(fonctions);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.STYLESHEET:
      {
        stylesheet stylesheet = (stylesheet)theEObject;
        T result = casestylesheet(stylesheet);
        if (result == null) result = caseFonctions(stylesheet);
        if (result == null) result = caseControleur(stylesheet);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.FONCTION:
      {
        fonction fonction = (fonction)theEObject;
        T result = casefonction(fonction);
        if (result == null) result = caseFonctions(fonction);
        if (result == null) result = caseControleur(fonction);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.STYLE_TEXT:
      {
        StyleText styleText = (StyleText)theEObject;
        T result = caseStyleText(styleText);
        if (result == null) result = casestylesheet(styleText);
        if (result == null) result = caseFonctions(styleText);
        if (result == null) result = caseControleur(styleText);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.STYLE_VIEW:
      {
        StyleView styleView = (StyleView)theEObject;
        T result = caseStyleView(styleView);
        if (result == null) result = casestylesheet(styleView);
        if (result == null) result = caseFonctions(styleView);
        if (result == null) result = caseControleur(styleView);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.STYLE_IMAGE:
      {
        StyleImage styleImage = (StyleImage)theEObject;
        T result = caseStyleImage(styleImage);
        if (result == null) result = casestylesheet(styleImage);
        if (result == null) result = caseFonctions(styleImage);
        if (result == null) result = caseControleur(styleImage);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.STYLEFLEXBOX:
      {
        Styleflexbox styleflexbox = (Styleflexbox)theEObject;
        T result = caseStyleflexbox(styleflexbox);
        if (result == null) result = casestylesheet(styleflexbox);
        if (result == null) result = caseFonctions(styleflexbox);
        if (result == null) result = caseControleur(styleflexbox);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.REMPLIR_TABLE:
      {
        RemplirTable remplirTable = (RemplirTable)theEObject;
        T result = caseRemplirTable(remplirTable);
        if (result == null) result = casefonction(remplirTable);
        if (result == null) result = caseFonctions(remplirTable);
        if (result == null) result = caseControleur(remplirTable);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.ALERTE_FONCTION:
      {
        AlerteFonction alerteFonction = (AlerteFonction)theEObject;
        T result = caseAlerteFonction(alerteFonction);
        if (result == null) result = casefonction(alerteFonction);
        if (result == null) result = caseFonctions(alerteFonction);
        if (result == null) result = caseControleur(alerteFonction);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.NAVIGATE:
      {
        Navigate navigate = (Navigate)theEObject;
        T result = caseNavigate(navigate);
        if (result == null) result = casefonction(navigate);
        if (result == null) result = caseFonctions(navigate);
        if (result == null) result = caseControleur(navigate);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.VUE:
      {
        Vue vue = (Vue)theEObject;
        T result = caseVue(vue);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.ELEMENTS:
      {
        Elements elements = (Elements)theEObject;
        T result = caseElements(elements);
        if (result == null) result = caseVue(elements);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.COMPOSANT:
      {
        composant composant = (composant)theEObject;
        T result = casecomposant(composant);
        if (result == null) result = caseElements(composant);
        if (result == null) result = caseVue(composant);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.FORMS:
      {
        Forms forms = (Forms)theEObject;
        T result = caseForms(forms);
        if (result == null) result = caseElements(forms);
        if (result == null) result = caseVue(forms);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.LISTS:
      {
        lists lists = (lists)theEObject;
        T result = caselists(lists);
        if (result == null) result = caseElements(lists);
        if (result == null) result = caseVue(lists);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.ICONS:
      {
        Icons icons = (Icons)theEObject;
        T result = caseIcons(icons);
        if (result == null) result = caseElements(icons);
        if (result == null) result = caseVue(icons);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.LIST_VIEW:
      {
        listView listView = (listView)theEObject;
        T result = caselistView(listView);
        if (result == null) result = caselists(listView);
        if (result == null) result = caseElements(listView);
        if (result == null) result = caseVue(listView);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.RADIO_BUTTON:
      {
        RadioButton radioButton = (RadioButton)theEObject;
        T result = caseRadioButton(radioButton);
        if (result == null) result = caseElements(radioButton);
        if (result == null) result = caseVue(radioButton);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.CHECK_BOX:
      {
        CheckBox checkBox = (CheckBox)theEObject;
        T result = caseCheckBox(checkBox);
        if (result == null) result = caseElements(checkBox);
        if (result == null) result = caseVue(checkBox);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.TEXT:
      {
        Text text = (Text)theEObject;
        T result = caseText(text);
        if (result == null) result = caseForms(text);
        if (result == null) result = caseElements(text);
        if (result == null) result = caseVue(text);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.INPUT:
      {
        Input input = (Input)theEObject;
        T result = caseInput(input);
        if (result == null) result = caseForms(input);
        if (result == null) result = caseElements(input);
        if (result == null) result = caseVue(input);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.ICONE:
      {
        Icone icone = (Icone)theEObject;
        T result = caseIcone(icone);
        if (result == null) result = caseIcons(icone);
        if (result == null) result = caseElements(icone);
        if (result == null) result = caseVue(icone);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.SOCIAL_ICON:
      {
        SocialIcon socialIcon = (SocialIcon)theEObject;
        T result = caseSocialIcon(socialIcon);
        if (result == null) result = caseIcons(socialIcon);
        if (result == null) result = caseElements(socialIcon);
        if (result == null) result = caseVue(socialIcon);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.TAB:
      {
        Tab tab = (Tab)theEObject;
        T result = caseTab(tab);
        if (result == null) result = caseElements(tab);
        if (result == null) result = caseVue(tab);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.HEADING:
      {
        Heading heading = (Heading)theEObject;
        T result = caseHeading(heading);
        if (result == null) result = caseElements(heading);
        if (result == null) result = caseVue(heading);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.CONTAINER_STYLE:
      {
        ContainerStyle containerStyle = (ContainerStyle)theEObject;
        T result = caseContainerStyle(containerStyle);
        if (result == null) result = caseElements(containerStyle);
        if (result == null) result = caseVue(containerStyle);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.CONTAINER_FONCTIONS:
      {
        ContainerFonctions containerFonctions = (ContainerFonctions)theEObject;
        T result = caseContainerFonctions(containerFonctions);
        if (result == null) result = caseElements(containerFonctions);
        if (result == null) result = caseVue(containerFonctions);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.LAYOUT:
      {
        Layout layout = (Layout)theEObject;
        T result = caseLayout(layout);
        if (result == null) result = caseElements(layout);
        if (result == null) result = caseVue(layout);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.BOUTON:
      {
        Bouton bouton = (Bouton)theEObject;
        T result = caseBouton(bouton);
        if (result == null) result = caseElements(bouton);
        if (result == null) result = caseVue(bouton);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.VIDEO:
      {
        Video video = (Video)theEObject;
        T result = caseVideo(video);
        if (result == null) result = casecomposant(video);
        if (result == null) result = caseElements(video);
        if (result == null) result = caseVue(video);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.AUDIO:
      {
        Audio audio = (Audio)theEObject;
        T result = caseAudio(audio);
        if (result == null) result = casecomposant(audio);
        if (result == null) result = caseElements(audio);
        if (result == null) result = caseVue(audio);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.MAP_VIEW:
      {
        MapView mapView = (MapView)theEObject;
        T result = caseMapView(mapView);
        if (result == null) result = casecomposant(mapView);
        if (result == null) result = caseElements(mapView);
        if (result == null) result = caseVue(mapView);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.IMAGE:
      {
        Image image = (Image)theEObject;
        T result = caseImage(image);
        if (result == null) result = casecomposant(image);
        if (result == null) result = caseElements(image);
        if (result == null) result = caseVue(image);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.MODEL:
      {
        Model model = (Model)theEObject;
        T result = caseModel(model);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      case PfePackage.TABLE_DEFINITION:
      {
        TableDefinition tableDefinition = (TableDefinition)theEObject;
        T result = caseTableDefinition(tableDefinition);
        if (result == null) result = caseModel(tableDefinition);
        if (result == null) result = defaultCase(theEObject);
        return result;
      }
      default: return defaultCase(theEObject);
    }
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Application</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Application</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseApplication(Application object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Controleur</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Controleur</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseControleur(Controleur object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Fonctions</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Fonctions</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseFonctions(Fonctions object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>stylesheet</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>stylesheet</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T casestylesheet(stylesheet object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>fonction</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>fonction</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T casefonction(fonction object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Style Text</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Style Text</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseStyleText(StyleText object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Style View</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Style View</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseStyleView(StyleView object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Style Image</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Style Image</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseStyleImage(StyleImage object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Styleflexbox</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Styleflexbox</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseStyleflexbox(Styleflexbox object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Remplir Table</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Remplir Table</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseRemplirTable(RemplirTable object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Alerte Fonction</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Alerte Fonction</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseAlerteFonction(AlerteFonction object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Navigate</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Navigate</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseNavigate(Navigate object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Vue</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Vue</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVue(Vue object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Elements</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Elements</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseElements(Elements object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>composant</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>composant</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T casecomposant(composant object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Forms</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Forms</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseForms(Forms object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>lists</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>lists</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caselists(lists object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Icons</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Icons</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseIcons(Icons object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>list View</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>list View</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caselistView(listView object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Radio Button</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Radio Button</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseRadioButton(RadioButton object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Check Box</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Check Box</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseCheckBox(CheckBox object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Text</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Text</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseText(Text object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Input</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Input</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseInput(Input object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Icone</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Icone</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseIcone(Icone object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Social Icon</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Social Icon</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseSocialIcon(SocialIcon object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Tab</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Tab</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseTab(Tab object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Heading</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Heading</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseHeading(Heading object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Container Style</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Container Style</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseContainerStyle(ContainerStyle object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Container Fonctions</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Container Fonctions</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseContainerFonctions(ContainerFonctions object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Layout</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Layout</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseLayout(Layout object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Bouton</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Bouton</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseBouton(Bouton object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Video</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Video</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseVideo(Video object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Audio</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Audio</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseAudio(Audio object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Map View</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Map View</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseMapView(MapView object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Image</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Image</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseImage(Image object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Model</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Model</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseModel(Model object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>Table Definition</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>Table Definition</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
   * @generated
   */
  public T caseTableDefinition(TableDefinition object)
  {
    return null;
  }

  /**
   * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
   * <!-- begin-user-doc -->
   * This implementation returns null;
   * returning a non-null result will terminate the switch, but this is the last case anyway.
   * <!-- end-user-doc -->
   * @param object the target of the switch.
   * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
   * @see #doSwitch(org.eclipse.emf.ecore.EObject)
   * @generated
   */
  @Override
  public T defaultCase(EObject object)
  {
    return null;
  }

} //PfeSwitch
