/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage
 * @generated
 */
public interface PfeFactory extends EFactory
{
  /**
   * The singleton instance of the factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  PfeFactory eINSTANCE = org.xtext.UnivTlemcen.pfe.pfe.impl.PfeFactoryImpl.init();

  /**
   * Returns a new object of class '<em>Application</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Application</em>'.
   * @generated
   */
  Application createApplication();

  /**
   * Returns a new object of class '<em>Controleur</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Controleur</em>'.
   * @generated
   */
  Controleur createControleur();

  /**
   * Returns a new object of class '<em>Fonctions</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Fonctions</em>'.
   * @generated
   */
  Fonctions createFonctions();

  /**
   * Returns a new object of class '<em>stylesheet</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>stylesheet</em>'.
   * @generated
   */
  stylesheet createstylesheet();

  /**
   * Returns a new object of class '<em>fonction</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>fonction</em>'.
   * @generated
   */
  fonction createfonction();

  /**
   * Returns a new object of class '<em>Style Text</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Style Text</em>'.
   * @generated
   */
  StyleText createStyleText();

  /**
   * Returns a new object of class '<em>Style View</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Style View</em>'.
   * @generated
   */
  StyleView createStyleView();

  /**
   * Returns a new object of class '<em>Style Image</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Style Image</em>'.
   * @generated
   */
  StyleImage createStyleImage();

  /**
   * Returns a new object of class '<em>Styleflexbox</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Styleflexbox</em>'.
   * @generated
   */
  Styleflexbox createStyleflexbox();

  /**
   * Returns a new object of class '<em>Remplir Table</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Remplir Table</em>'.
   * @generated
   */
  RemplirTable createRemplirTable();

  /**
   * Returns a new object of class '<em>Alerte Fonction</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Alerte Fonction</em>'.
   * @generated
   */
  AlerteFonction createAlerteFonction();

  /**
   * Returns a new object of class '<em>Navigate</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Navigate</em>'.
   * @generated
   */
  Navigate createNavigate();

  /**
   * Returns a new object of class '<em>Vue</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Vue</em>'.
   * @generated
   */
  Vue createVue();

  /**
   * Returns a new object of class '<em>Elements</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Elements</em>'.
   * @generated
   */
  Elements createElements();

  /**
   * Returns a new object of class '<em>composant</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>composant</em>'.
   * @generated
   */
  composant createcomposant();

  /**
   * Returns a new object of class '<em>Forms</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Forms</em>'.
   * @generated
   */
  Forms createForms();

  /**
   * Returns a new object of class '<em>lists</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>lists</em>'.
   * @generated
   */
  lists createlists();

  /**
   * Returns a new object of class '<em>Icons</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Icons</em>'.
   * @generated
   */
  Icons createIcons();

  /**
   * Returns a new object of class '<em>list View</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>list View</em>'.
   * @generated
   */
  listView createlistView();

  /**
   * Returns a new object of class '<em>Radio Button</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Radio Button</em>'.
   * @generated
   */
  RadioButton createRadioButton();

  /**
   * Returns a new object of class '<em>Check Box</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Check Box</em>'.
   * @generated
   */
  CheckBox createCheckBox();

  /**
   * Returns a new object of class '<em>Text</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Text</em>'.
   * @generated
   */
  Text createText();

  /**
   * Returns a new object of class '<em>Input</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Input</em>'.
   * @generated
   */
  Input createInput();

  /**
   * Returns a new object of class '<em>Icone</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Icone</em>'.
   * @generated
   */
  Icone createIcone();

  /**
   * Returns a new object of class '<em>Social Icon</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Social Icon</em>'.
   * @generated
   */
  SocialIcon createSocialIcon();

  /**
   * Returns a new object of class '<em>Tab</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Tab</em>'.
   * @generated
   */
  Tab createTab();

  /**
   * Returns a new object of class '<em>Heading</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Heading</em>'.
   * @generated
   */
  Heading createHeading();

  /**
   * Returns a new object of class '<em>Container Style</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Container Style</em>'.
   * @generated
   */
  ContainerStyle createContainerStyle();

  /**
   * Returns a new object of class '<em>Container Fonctions</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Container Fonctions</em>'.
   * @generated
   */
  ContainerFonctions createContainerFonctions();

  /**
   * Returns a new object of class '<em>Layout</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Layout</em>'.
   * @generated
   */
  Layout createLayout();

  /**
   * Returns a new object of class '<em>Bouton</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Bouton</em>'.
   * @generated
   */
  Bouton createBouton();

  /**
   * Returns a new object of class '<em>Video</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Video</em>'.
   * @generated
   */
  Video createVideo();

  /**
   * Returns a new object of class '<em>Audio</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Audio</em>'.
   * @generated
   */
  Audio createAudio();

  /**
   * Returns a new object of class '<em>Map View</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Map View</em>'.
   * @generated
   */
  MapView createMapView();

  /**
   * Returns a new object of class '<em>Image</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Image</em>'.
   * @generated
   */
  Image createImage();

  /**
   * Returns a new object of class '<em>Model</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Model</em>'.
   * @generated
   */
  Model createModel();

  /**
   * Returns a new object of class '<em>Table Definition</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Table Definition</em>'.
   * @generated
   */
  TableDefinition createTableDefinition();

  /**
   * Returns the package supported by this factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the package supported by this factory.
   * @generated
   */
  PfePackage getPfePackage();

} //PfeFactory
