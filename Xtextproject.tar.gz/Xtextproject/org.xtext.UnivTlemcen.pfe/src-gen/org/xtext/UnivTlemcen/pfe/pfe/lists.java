/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>lists</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getlists()
 * @model
 * @generated
 */
public interface lists extends Elements
{
} // lists
