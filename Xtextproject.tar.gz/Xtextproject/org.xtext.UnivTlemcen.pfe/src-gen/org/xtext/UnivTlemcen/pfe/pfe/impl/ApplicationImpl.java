/**
 */
package org.xtext.UnivTlemcen.pfe.pfe.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.xtext.UnivTlemcen.pfe.pfe.Application;
import org.xtext.UnivTlemcen.pfe.pfe.Controleur;
import org.xtext.UnivTlemcen.pfe.pfe.Layout;
import org.xtext.UnivTlemcen.pfe.pfe.Model;
import org.xtext.UnivTlemcen.pfe.pfe.PfePackage;
import org.xtext.UnivTlemcen.pfe.pfe.Vue;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Application</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ApplicationImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ApplicationImpl#getPackageName <em>Package Name</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ApplicationImpl#getFirstLayout <em>First Layout</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ApplicationImpl#getModel <em>Model</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ApplicationImpl#getVue <em>Vue</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ApplicationImpl#getControleur <em>Controleur</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ApplicationImpl extends MinimalEObjectImpl.Container implements Application
{
  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The default value of the '{@link #getPackageName() <em>Package Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPackageName()
   * @generated
   * @ordered
   */
  protected static final String PACKAGE_NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getPackageName() <em>Package Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPackageName()
   * @generated
   * @ordered
   */
  protected String packageName = PACKAGE_NAME_EDEFAULT;

  /**
   * The cached value of the '{@link #getFirstLayout() <em>First Layout</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFirstLayout()
   * @generated
   * @ordered
   */
  protected EList<Layout> firstLayout;

  /**
   * The cached value of the '{@link #getModel() <em>Model</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getModel()
   * @generated
   * @ordered
   */
  protected EList<Model> model;

  /**
   * The cached value of the '{@link #getVue() <em>Vue</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getVue()
   * @generated
   * @ordered
   */
  protected EList<Vue> vue;

  /**
   * The cached value of the '{@link #getControleur() <em>Controleur</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getControleur()
   * @generated
   * @ordered
   */
  protected EList<Controleur> controleur;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ApplicationImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return PfePackage.Literals.APPLICATION;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName)
  {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.APPLICATION__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getPackageName()
  {
    return packageName;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPackageName(String newPackageName)
  {
    String oldPackageName = packageName;
    packageName = newPackageName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.APPLICATION__PACKAGE_NAME, oldPackageName, packageName));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Layout> getFirstLayout()
  {
    if (firstLayout == null)
    {
      firstLayout = new EObjectResolvingEList<Layout>(Layout.class, this, PfePackage.APPLICATION__FIRST_LAYOUT);
    }
    return firstLayout;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Model> getModel()
  {
    if (model == null)
    {
      model = new EObjectContainmentEList<Model>(Model.class, this, PfePackage.APPLICATION__MODEL);
    }
    return model;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Vue> getVue()
  {
    if (vue == null)
    {
      vue = new EObjectContainmentEList<Vue>(Vue.class, this, PfePackage.APPLICATION__VUE);
    }
    return vue;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Controleur> getControleur()
  {
    if (controleur == null)
    {
      controleur = new EObjectContainmentEList<Controleur>(Controleur.class, this, PfePackage.APPLICATION__CONTROLEUR);
    }
    return controleur;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case PfePackage.APPLICATION__MODEL:
        return ((InternalEList<?>)getModel()).basicRemove(otherEnd, msgs);
      case PfePackage.APPLICATION__VUE:
        return ((InternalEList<?>)getVue()).basicRemove(otherEnd, msgs);
      case PfePackage.APPLICATION__CONTROLEUR:
        return ((InternalEList<?>)getControleur()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case PfePackage.APPLICATION__NAME:
        return getName();
      case PfePackage.APPLICATION__PACKAGE_NAME:
        return getPackageName();
      case PfePackage.APPLICATION__FIRST_LAYOUT:
        return getFirstLayout();
      case PfePackage.APPLICATION__MODEL:
        return getModel();
      case PfePackage.APPLICATION__VUE:
        return getVue();
      case PfePackage.APPLICATION__CONTROLEUR:
        return getControleur();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case PfePackage.APPLICATION__NAME:
        setName((String)newValue);
        return;
      case PfePackage.APPLICATION__PACKAGE_NAME:
        setPackageName((String)newValue);
        return;
      case PfePackage.APPLICATION__FIRST_LAYOUT:
        getFirstLayout().clear();
        getFirstLayout().addAll((Collection<? extends Layout>)newValue);
        return;
      case PfePackage.APPLICATION__MODEL:
        getModel().clear();
        getModel().addAll((Collection<? extends Model>)newValue);
        return;
      case PfePackage.APPLICATION__VUE:
        getVue().clear();
        getVue().addAll((Collection<? extends Vue>)newValue);
        return;
      case PfePackage.APPLICATION__CONTROLEUR:
        getControleur().clear();
        getControleur().addAll((Collection<? extends Controleur>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.APPLICATION__NAME:
        setName(NAME_EDEFAULT);
        return;
      case PfePackage.APPLICATION__PACKAGE_NAME:
        setPackageName(PACKAGE_NAME_EDEFAULT);
        return;
      case PfePackage.APPLICATION__FIRST_LAYOUT:
        getFirstLayout().clear();
        return;
      case PfePackage.APPLICATION__MODEL:
        getModel().clear();
        return;
      case PfePackage.APPLICATION__VUE:
        getVue().clear();
        return;
      case PfePackage.APPLICATION__CONTROLEUR:
        getControleur().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.APPLICATION__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case PfePackage.APPLICATION__PACKAGE_NAME:
        return PACKAGE_NAME_EDEFAULT == null ? packageName != null : !PACKAGE_NAME_EDEFAULT.equals(packageName);
      case PfePackage.APPLICATION__FIRST_LAYOUT:
        return firstLayout != null && !firstLayout.isEmpty();
      case PfePackage.APPLICATION__MODEL:
        return model != null && !model.isEmpty();
      case PfePackage.APPLICATION__VUE:
        return vue != null && !vue.isEmpty();
      case PfePackage.APPLICATION__CONTROLEUR:
        return controleur != null && !controleur.isEmpty();
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (name: ");
    result.append(name);
    result.append(", packageName: ");
    result.append(packageName);
    result.append(')');
    return result.toString();
  }

} //ApplicationImpl
