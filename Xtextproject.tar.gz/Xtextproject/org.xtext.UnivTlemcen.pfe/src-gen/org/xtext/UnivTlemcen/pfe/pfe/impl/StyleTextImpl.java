/**
 */
package org.xtext.UnivTlemcen.pfe.pfe.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.xtext.UnivTlemcen.pfe.pfe.Backnum;
import org.xtext.UnivTlemcen.pfe.pfe.Colors;
import org.xtext.UnivTlemcen.pfe.pfe.Eignth;
import org.xtext.UnivTlemcen.pfe.pfe.Foor;
import org.xtext.UnivTlemcen.pfe.pfe.PfePackage;
import org.xtext.UnivTlemcen.pfe.pfe.StyleText;
import org.xtext.UnivTlemcen.pfe.pfe.Three;
import org.xtext.UnivTlemcen.pfe.pfe.TypeH;
import org.xtext.UnivTlemcen.pfe.pfe.bordersty;
import org.xtext.UnivTlemcen.pfe.pfe.entier;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Style Text</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getColore <em>Colore</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getFontFamilyE <em>Font Family E</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getFontSizes <em>Font Sizes</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getFontStyles <em>Font Styles</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getFontWeighte <em>Font Weighte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getLineHeighte <em>Line Heighte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getTextAligne <em>Text Aligne</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getBackfaceVisibilitye <em>Backface Visibilitye</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getBackgroundColore <em>Background Colore</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getBorderBottomColore <em>Border Bottom Colore</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getBorderBottomLeftRadiuse <em>Border Bottom Left Radiuse</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getBorderBottomRightRadiuse <em>Border Bottom Right Radiuse</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getBorderBottomWidthe <em>Border Bottom Widthe</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getBorderColore <em>Border Colore</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getBorderLeftColore <em>Border Left Colore</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getBorderLeftWidthe <em>Border Left Widthe</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getBorderRadiuse <em>Border Radiuse</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getBorderRightColore <em>Border Right Colore</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getBorderRightWidth <em>Border Right Width</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getBorderStyles <em>Border Styles</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getBorderTopColore <em>Border Top Colore</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getBorderTopLeftRadiuse <em>Border Top Left Radiuse</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getBorderTopRightRadiuse <em>Border Top Right Radiuse</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getBorderTopWidthe <em>Border Top Widthe</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getBorderWidthe <em>Border Widthe</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl#getOpacitye <em>Opacitye</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class StyleTextImpl extends stylesheetImpl implements StyleText
{
  /**
   * The default value of the '{@link #getColore() <em>Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getColore()
   * @generated
   * @ordered
   */
  protected static final Colors COLORE_EDEFAULT = Colors.NONE;

  /**
   * The cached value of the '{@link #getColore() <em>Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getColore()
   * @generated
   * @ordered
   */
  protected Colors colore = COLORE_EDEFAULT;

  /**
   * The default value of the '{@link #getFontFamilyE() <em>Font Family E</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFontFamilyE()
   * @generated
   * @ordered
   */
  protected static final TypeH FONT_FAMILY_E_EDEFAULT = TypeH.H1;

  /**
   * The cached value of the '{@link #getFontFamilyE() <em>Font Family E</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFontFamilyE()
   * @generated
   * @ordered
   */
  protected TypeH fontFamilyE = FONT_FAMILY_E_EDEFAULT;

  /**
   * The default value of the '{@link #getFontSizes() <em>Font Sizes</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFontSizes()
   * @generated
   * @ordered
   */
  protected static final entier FONT_SIZES_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getFontSizes() <em>Font Sizes</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFontSizes()
   * @generated
   * @ordered
   */
  protected entier fontSizes = FONT_SIZES_EDEFAULT;

  /**
   * The default value of the '{@link #getFontStyles() <em>Font Styles</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFontStyles()
   * @generated
   * @ordered
   */
  protected static final Three FONT_STYLES_EDEFAULT = Three.NORMAL;

  /**
   * The cached value of the '{@link #getFontStyles() <em>Font Styles</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFontStyles()
   * @generated
   * @ordered
   */
  protected Three fontStyles = FONT_STYLES_EDEFAULT;

  /**
   * The default value of the '{@link #getFontWeighte() <em>Font Weighte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFontWeighte()
   * @generated
   * @ordered
   */
  protected static final Foor FONT_WEIGHTE_EDEFAULT = Foor.NRMAL;

  /**
   * The cached value of the '{@link #getFontWeighte() <em>Font Weighte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFontWeighte()
   * @generated
   * @ordered
   */
  protected Foor fontWeighte = FONT_WEIGHTE_EDEFAULT;

  /**
   * The default value of the '{@link #getLineHeighte() <em>Line Heighte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLineHeighte()
   * @generated
   * @ordered
   */
  protected static final entier LINE_HEIGHTE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getLineHeighte() <em>Line Heighte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLineHeighte()
   * @generated
   * @ordered
   */
  protected entier lineHeighte = LINE_HEIGHTE_EDEFAULT;

  /**
   * The default value of the '{@link #getTextAligne() <em>Text Aligne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTextAligne()
   * @generated
   * @ordered
   */
  protected static final Eignth TEXT_ALIGNE_EDEFAULT = Eignth.ATO;

  /**
   * The cached value of the '{@link #getTextAligne() <em>Text Aligne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTextAligne()
   * @generated
   * @ordered
   */
  protected Eignth textAligne = TEXT_ALIGNE_EDEFAULT;

  /**
   * The default value of the '{@link #getBackfaceVisibilitye() <em>Backface Visibilitye</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBackfaceVisibilitye()
   * @generated
   * @ordered
   */
  protected static final Backnum BACKFACE_VISIBILITYE_EDEFAULT = Backnum.NONE;

  /**
   * The cached value of the '{@link #getBackfaceVisibilitye() <em>Backface Visibilitye</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBackfaceVisibilitye()
   * @generated
   * @ordered
   */
  protected Backnum backfaceVisibilitye = BACKFACE_VISIBILITYE_EDEFAULT;

  /**
   * The default value of the '{@link #getBackgroundColore() <em>Background Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBackgroundColore()
   * @generated
   * @ordered
   */
  protected static final Colors BACKGROUND_COLORE_EDEFAULT = Colors.NONE;

  /**
   * The cached value of the '{@link #getBackgroundColore() <em>Background Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBackgroundColore()
   * @generated
   * @ordered
   */
  protected Colors backgroundColore = BACKGROUND_COLORE_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderBottomColore() <em>Border Bottom Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomColore()
   * @generated
   * @ordered
   */
  protected static final Colors BORDER_BOTTOM_COLORE_EDEFAULT = Colors.NONE;

  /**
   * The cached value of the '{@link #getBorderBottomColore() <em>Border Bottom Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomColore()
   * @generated
   * @ordered
   */
  protected Colors borderBottomColore = BORDER_BOTTOM_COLORE_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderBottomLeftRadiuse() <em>Border Bottom Left Radiuse</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomLeftRadiuse()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_BOTTOM_LEFT_RADIUSE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderBottomLeftRadiuse() <em>Border Bottom Left Radiuse</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomLeftRadiuse()
   * @generated
   * @ordered
   */
  protected entier borderBottomLeftRadiuse = BORDER_BOTTOM_LEFT_RADIUSE_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderBottomRightRadiuse() <em>Border Bottom Right Radiuse</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomRightRadiuse()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_BOTTOM_RIGHT_RADIUSE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderBottomRightRadiuse() <em>Border Bottom Right Radiuse</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomRightRadiuse()
   * @generated
   * @ordered
   */
  protected entier borderBottomRightRadiuse = BORDER_BOTTOM_RIGHT_RADIUSE_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderBottomWidthe() <em>Border Bottom Widthe</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomWidthe()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_BOTTOM_WIDTHE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderBottomWidthe() <em>Border Bottom Widthe</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomWidthe()
   * @generated
   * @ordered
   */
  protected entier borderBottomWidthe = BORDER_BOTTOM_WIDTHE_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderColore() <em>Border Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderColore()
   * @generated
   * @ordered
   */
  protected static final Colors BORDER_COLORE_EDEFAULT = Colors.NONE;

  /**
   * The cached value of the '{@link #getBorderColore() <em>Border Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderColore()
   * @generated
   * @ordered
   */
  protected Colors borderColore = BORDER_COLORE_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderLeftColore() <em>Border Left Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderLeftColore()
   * @generated
   * @ordered
   */
  protected static final Colors BORDER_LEFT_COLORE_EDEFAULT = Colors.NONE;

  /**
   * The cached value of the '{@link #getBorderLeftColore() <em>Border Left Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderLeftColore()
   * @generated
   * @ordered
   */
  protected Colors borderLeftColore = BORDER_LEFT_COLORE_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderLeftWidthe() <em>Border Left Widthe</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderLeftWidthe()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_LEFT_WIDTHE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderLeftWidthe() <em>Border Left Widthe</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderLeftWidthe()
   * @generated
   * @ordered
   */
  protected entier borderLeftWidthe = BORDER_LEFT_WIDTHE_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderRadiuse() <em>Border Radiuse</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderRadiuse()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_RADIUSE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderRadiuse() <em>Border Radiuse</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderRadiuse()
   * @generated
   * @ordered
   */
  protected entier borderRadiuse = BORDER_RADIUSE_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderRightColore() <em>Border Right Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderRightColore()
   * @generated
   * @ordered
   */
  protected static final Colors BORDER_RIGHT_COLORE_EDEFAULT = Colors.NONE;

  /**
   * The cached value of the '{@link #getBorderRightColore() <em>Border Right Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderRightColore()
   * @generated
   * @ordered
   */
  protected Colors borderRightColore = BORDER_RIGHT_COLORE_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderRightWidth() <em>Border Right Width</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderRightWidth()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_RIGHT_WIDTH_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderRightWidth() <em>Border Right Width</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderRightWidth()
   * @generated
   * @ordered
   */
  protected entier borderRightWidth = BORDER_RIGHT_WIDTH_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderStyles() <em>Border Styles</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderStyles()
   * @generated
   * @ordered
   */
  protected static final bordersty BORDER_STYLES_EDEFAULT = bordersty.NONE;

  /**
   * The cached value of the '{@link #getBorderStyles() <em>Border Styles</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderStyles()
   * @generated
   * @ordered
   */
  protected bordersty borderStyles = BORDER_STYLES_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderTopColore() <em>Border Top Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopColore()
   * @generated
   * @ordered
   */
  protected static final Colors BORDER_TOP_COLORE_EDEFAULT = Colors.NONE;

  /**
   * The cached value of the '{@link #getBorderTopColore() <em>Border Top Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopColore()
   * @generated
   * @ordered
   */
  protected Colors borderTopColore = BORDER_TOP_COLORE_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderTopLeftRadiuse() <em>Border Top Left Radiuse</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopLeftRadiuse()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_TOP_LEFT_RADIUSE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderTopLeftRadiuse() <em>Border Top Left Radiuse</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopLeftRadiuse()
   * @generated
   * @ordered
   */
  protected entier borderTopLeftRadiuse = BORDER_TOP_LEFT_RADIUSE_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderTopRightRadiuse() <em>Border Top Right Radiuse</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopRightRadiuse()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_TOP_RIGHT_RADIUSE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderTopRightRadiuse() <em>Border Top Right Radiuse</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopRightRadiuse()
   * @generated
   * @ordered
   */
  protected entier borderTopRightRadiuse = BORDER_TOP_RIGHT_RADIUSE_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderTopWidthe() <em>Border Top Widthe</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopWidthe()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_TOP_WIDTHE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderTopWidthe() <em>Border Top Widthe</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopWidthe()
   * @generated
   * @ordered
   */
  protected entier borderTopWidthe = BORDER_TOP_WIDTHE_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderWidthe() <em>Border Widthe</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderWidthe()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_WIDTHE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderWidthe() <em>Border Widthe</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderWidthe()
   * @generated
   * @ordered
   */
  protected entier borderWidthe = BORDER_WIDTHE_EDEFAULT;

  /**
   * The default value of the '{@link #getOpacitye() <em>Opacitye</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOpacitye()
   * @generated
   * @ordered
   */
  protected static final entier OPACITYE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getOpacitye() <em>Opacitye</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOpacitye()
   * @generated
   * @ordered
   */
  protected entier opacitye = OPACITYE_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected StyleTextImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return PfePackage.Literals.STYLE_TEXT;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Colors getColore()
  {
    return colore;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setColore(Colors newColore)
  {
    Colors oldColore = colore;
    colore = newColore == null ? COLORE_EDEFAULT : newColore;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__COLORE, oldColore, colore));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TypeH getFontFamilyE()
  {
    return fontFamilyE;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFontFamilyE(TypeH newFontFamilyE)
  {
    TypeH oldFontFamilyE = fontFamilyE;
    fontFamilyE = newFontFamilyE == null ? FONT_FAMILY_E_EDEFAULT : newFontFamilyE;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__FONT_FAMILY_E, oldFontFamilyE, fontFamilyE));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getFontSizes()
  {
    return fontSizes;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFontSizes(entier newFontSizes)
  {
    entier oldFontSizes = fontSizes;
    fontSizes = newFontSizes == null ? FONT_SIZES_EDEFAULT : newFontSizes;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__FONT_SIZES, oldFontSizes, fontSizes));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Three getFontStyles()
  {
    return fontStyles;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFontStyles(Three newFontStyles)
  {
    Three oldFontStyles = fontStyles;
    fontStyles = newFontStyles == null ? FONT_STYLES_EDEFAULT : newFontStyles;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__FONT_STYLES, oldFontStyles, fontStyles));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Foor getFontWeighte()
  {
    return fontWeighte;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFontWeighte(Foor newFontWeighte)
  {
    Foor oldFontWeighte = fontWeighte;
    fontWeighte = newFontWeighte == null ? FONT_WEIGHTE_EDEFAULT : newFontWeighte;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__FONT_WEIGHTE, oldFontWeighte, fontWeighte));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getLineHeighte()
  {
    return lineHeighte;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLineHeighte(entier newLineHeighte)
  {
    entier oldLineHeighte = lineHeighte;
    lineHeighte = newLineHeighte == null ? LINE_HEIGHTE_EDEFAULT : newLineHeighte;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__LINE_HEIGHTE, oldLineHeighte, lineHeighte));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Eignth getTextAligne()
  {
    return textAligne;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTextAligne(Eignth newTextAligne)
  {
    Eignth oldTextAligne = textAligne;
    textAligne = newTextAligne == null ? TEXT_ALIGNE_EDEFAULT : newTextAligne;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__TEXT_ALIGNE, oldTextAligne, textAligne));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Backnum getBackfaceVisibilitye()
  {
    return backfaceVisibilitye;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBackfaceVisibilitye(Backnum newBackfaceVisibilitye)
  {
    Backnum oldBackfaceVisibilitye = backfaceVisibilitye;
    backfaceVisibilitye = newBackfaceVisibilitye == null ? BACKFACE_VISIBILITYE_EDEFAULT : newBackfaceVisibilitye;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__BACKFACE_VISIBILITYE, oldBackfaceVisibilitye, backfaceVisibilitye));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Colors getBackgroundColore()
  {
    return backgroundColore;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBackgroundColore(Colors newBackgroundColore)
  {
    Colors oldBackgroundColore = backgroundColore;
    backgroundColore = newBackgroundColore == null ? BACKGROUND_COLORE_EDEFAULT : newBackgroundColore;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__BACKGROUND_COLORE, oldBackgroundColore, backgroundColore));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Colors getBorderBottomColore()
  {
    return borderBottomColore;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderBottomColore(Colors newBorderBottomColore)
  {
    Colors oldBorderBottomColore = borderBottomColore;
    borderBottomColore = newBorderBottomColore == null ? BORDER_BOTTOM_COLORE_EDEFAULT : newBorderBottomColore;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__BORDER_BOTTOM_COLORE, oldBorderBottomColore, borderBottomColore));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderBottomLeftRadiuse()
  {
    return borderBottomLeftRadiuse;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderBottomLeftRadiuse(entier newBorderBottomLeftRadiuse)
  {
    entier oldBorderBottomLeftRadiuse = borderBottomLeftRadiuse;
    borderBottomLeftRadiuse = newBorderBottomLeftRadiuse == null ? BORDER_BOTTOM_LEFT_RADIUSE_EDEFAULT : newBorderBottomLeftRadiuse;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__BORDER_BOTTOM_LEFT_RADIUSE, oldBorderBottomLeftRadiuse, borderBottomLeftRadiuse));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderBottomRightRadiuse()
  {
    return borderBottomRightRadiuse;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderBottomRightRadiuse(entier newBorderBottomRightRadiuse)
  {
    entier oldBorderBottomRightRadiuse = borderBottomRightRadiuse;
    borderBottomRightRadiuse = newBorderBottomRightRadiuse == null ? BORDER_BOTTOM_RIGHT_RADIUSE_EDEFAULT : newBorderBottomRightRadiuse;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__BORDER_BOTTOM_RIGHT_RADIUSE, oldBorderBottomRightRadiuse, borderBottomRightRadiuse));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderBottomWidthe()
  {
    return borderBottomWidthe;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderBottomWidthe(entier newBorderBottomWidthe)
  {
    entier oldBorderBottomWidthe = borderBottomWidthe;
    borderBottomWidthe = newBorderBottomWidthe == null ? BORDER_BOTTOM_WIDTHE_EDEFAULT : newBorderBottomWidthe;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__BORDER_BOTTOM_WIDTHE, oldBorderBottomWidthe, borderBottomWidthe));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Colors getBorderColore()
  {
    return borderColore;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderColore(Colors newBorderColore)
  {
    Colors oldBorderColore = borderColore;
    borderColore = newBorderColore == null ? BORDER_COLORE_EDEFAULT : newBorderColore;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__BORDER_COLORE, oldBorderColore, borderColore));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Colors getBorderLeftColore()
  {
    return borderLeftColore;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderLeftColore(Colors newBorderLeftColore)
  {
    Colors oldBorderLeftColore = borderLeftColore;
    borderLeftColore = newBorderLeftColore == null ? BORDER_LEFT_COLORE_EDEFAULT : newBorderLeftColore;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__BORDER_LEFT_COLORE, oldBorderLeftColore, borderLeftColore));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderLeftWidthe()
  {
    return borderLeftWidthe;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderLeftWidthe(entier newBorderLeftWidthe)
  {
    entier oldBorderLeftWidthe = borderLeftWidthe;
    borderLeftWidthe = newBorderLeftWidthe == null ? BORDER_LEFT_WIDTHE_EDEFAULT : newBorderLeftWidthe;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__BORDER_LEFT_WIDTHE, oldBorderLeftWidthe, borderLeftWidthe));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderRadiuse()
  {
    return borderRadiuse;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderRadiuse(entier newBorderRadiuse)
  {
    entier oldBorderRadiuse = borderRadiuse;
    borderRadiuse = newBorderRadiuse == null ? BORDER_RADIUSE_EDEFAULT : newBorderRadiuse;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__BORDER_RADIUSE, oldBorderRadiuse, borderRadiuse));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Colors getBorderRightColore()
  {
    return borderRightColore;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderRightColore(Colors newBorderRightColore)
  {
    Colors oldBorderRightColore = borderRightColore;
    borderRightColore = newBorderRightColore == null ? BORDER_RIGHT_COLORE_EDEFAULT : newBorderRightColore;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__BORDER_RIGHT_COLORE, oldBorderRightColore, borderRightColore));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderRightWidth()
  {
    return borderRightWidth;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderRightWidth(entier newBorderRightWidth)
  {
    entier oldBorderRightWidth = borderRightWidth;
    borderRightWidth = newBorderRightWidth == null ? BORDER_RIGHT_WIDTH_EDEFAULT : newBorderRightWidth;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__BORDER_RIGHT_WIDTH, oldBorderRightWidth, borderRightWidth));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public bordersty getBorderStyles()
  {
    return borderStyles;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderStyles(bordersty newBorderStyles)
  {
    bordersty oldBorderStyles = borderStyles;
    borderStyles = newBorderStyles == null ? BORDER_STYLES_EDEFAULT : newBorderStyles;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__BORDER_STYLES, oldBorderStyles, borderStyles));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Colors getBorderTopColore()
  {
    return borderTopColore;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderTopColore(Colors newBorderTopColore)
  {
    Colors oldBorderTopColore = borderTopColore;
    borderTopColore = newBorderTopColore == null ? BORDER_TOP_COLORE_EDEFAULT : newBorderTopColore;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__BORDER_TOP_COLORE, oldBorderTopColore, borderTopColore));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderTopLeftRadiuse()
  {
    return borderTopLeftRadiuse;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderTopLeftRadiuse(entier newBorderTopLeftRadiuse)
  {
    entier oldBorderTopLeftRadiuse = borderTopLeftRadiuse;
    borderTopLeftRadiuse = newBorderTopLeftRadiuse == null ? BORDER_TOP_LEFT_RADIUSE_EDEFAULT : newBorderTopLeftRadiuse;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__BORDER_TOP_LEFT_RADIUSE, oldBorderTopLeftRadiuse, borderTopLeftRadiuse));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderTopRightRadiuse()
  {
    return borderTopRightRadiuse;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderTopRightRadiuse(entier newBorderTopRightRadiuse)
  {
    entier oldBorderTopRightRadiuse = borderTopRightRadiuse;
    borderTopRightRadiuse = newBorderTopRightRadiuse == null ? BORDER_TOP_RIGHT_RADIUSE_EDEFAULT : newBorderTopRightRadiuse;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__BORDER_TOP_RIGHT_RADIUSE, oldBorderTopRightRadiuse, borderTopRightRadiuse));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderTopWidthe()
  {
    return borderTopWidthe;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderTopWidthe(entier newBorderTopWidthe)
  {
    entier oldBorderTopWidthe = borderTopWidthe;
    borderTopWidthe = newBorderTopWidthe == null ? BORDER_TOP_WIDTHE_EDEFAULT : newBorderTopWidthe;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__BORDER_TOP_WIDTHE, oldBorderTopWidthe, borderTopWidthe));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderWidthe()
  {
    return borderWidthe;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderWidthe(entier newBorderWidthe)
  {
    entier oldBorderWidthe = borderWidthe;
    borderWidthe = newBorderWidthe == null ? BORDER_WIDTHE_EDEFAULT : newBorderWidthe;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__BORDER_WIDTHE, oldBorderWidthe, borderWidthe));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getOpacitye()
  {
    return opacitye;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setOpacitye(entier newOpacitye)
  {
    entier oldOpacitye = opacitye;
    opacitye = newOpacitye == null ? OPACITYE_EDEFAULT : newOpacitye;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_TEXT__OPACITYE, oldOpacitye, opacitye));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case PfePackage.STYLE_TEXT__COLORE:
        return getColore();
      case PfePackage.STYLE_TEXT__FONT_FAMILY_E:
        return getFontFamilyE();
      case PfePackage.STYLE_TEXT__FONT_SIZES:
        return getFontSizes();
      case PfePackage.STYLE_TEXT__FONT_STYLES:
        return getFontStyles();
      case PfePackage.STYLE_TEXT__FONT_WEIGHTE:
        return getFontWeighte();
      case PfePackage.STYLE_TEXT__LINE_HEIGHTE:
        return getLineHeighte();
      case PfePackage.STYLE_TEXT__TEXT_ALIGNE:
        return getTextAligne();
      case PfePackage.STYLE_TEXT__BACKFACE_VISIBILITYE:
        return getBackfaceVisibilitye();
      case PfePackage.STYLE_TEXT__BACKGROUND_COLORE:
        return getBackgroundColore();
      case PfePackage.STYLE_TEXT__BORDER_BOTTOM_COLORE:
        return getBorderBottomColore();
      case PfePackage.STYLE_TEXT__BORDER_BOTTOM_LEFT_RADIUSE:
        return getBorderBottomLeftRadiuse();
      case PfePackage.STYLE_TEXT__BORDER_BOTTOM_RIGHT_RADIUSE:
        return getBorderBottomRightRadiuse();
      case PfePackage.STYLE_TEXT__BORDER_BOTTOM_WIDTHE:
        return getBorderBottomWidthe();
      case PfePackage.STYLE_TEXT__BORDER_COLORE:
        return getBorderColore();
      case PfePackage.STYLE_TEXT__BORDER_LEFT_COLORE:
        return getBorderLeftColore();
      case PfePackage.STYLE_TEXT__BORDER_LEFT_WIDTHE:
        return getBorderLeftWidthe();
      case PfePackage.STYLE_TEXT__BORDER_RADIUSE:
        return getBorderRadiuse();
      case PfePackage.STYLE_TEXT__BORDER_RIGHT_COLORE:
        return getBorderRightColore();
      case PfePackage.STYLE_TEXT__BORDER_RIGHT_WIDTH:
        return getBorderRightWidth();
      case PfePackage.STYLE_TEXT__BORDER_STYLES:
        return getBorderStyles();
      case PfePackage.STYLE_TEXT__BORDER_TOP_COLORE:
        return getBorderTopColore();
      case PfePackage.STYLE_TEXT__BORDER_TOP_LEFT_RADIUSE:
        return getBorderTopLeftRadiuse();
      case PfePackage.STYLE_TEXT__BORDER_TOP_RIGHT_RADIUSE:
        return getBorderTopRightRadiuse();
      case PfePackage.STYLE_TEXT__BORDER_TOP_WIDTHE:
        return getBorderTopWidthe();
      case PfePackage.STYLE_TEXT__BORDER_WIDTHE:
        return getBorderWidthe();
      case PfePackage.STYLE_TEXT__OPACITYE:
        return getOpacitye();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case PfePackage.STYLE_TEXT__COLORE:
        setColore((Colors)newValue);
        return;
      case PfePackage.STYLE_TEXT__FONT_FAMILY_E:
        setFontFamilyE((TypeH)newValue);
        return;
      case PfePackage.STYLE_TEXT__FONT_SIZES:
        setFontSizes((entier)newValue);
        return;
      case PfePackage.STYLE_TEXT__FONT_STYLES:
        setFontStyles((Three)newValue);
        return;
      case PfePackage.STYLE_TEXT__FONT_WEIGHTE:
        setFontWeighte((Foor)newValue);
        return;
      case PfePackage.STYLE_TEXT__LINE_HEIGHTE:
        setLineHeighte((entier)newValue);
        return;
      case PfePackage.STYLE_TEXT__TEXT_ALIGNE:
        setTextAligne((Eignth)newValue);
        return;
      case PfePackage.STYLE_TEXT__BACKFACE_VISIBILITYE:
        setBackfaceVisibilitye((Backnum)newValue);
        return;
      case PfePackage.STYLE_TEXT__BACKGROUND_COLORE:
        setBackgroundColore((Colors)newValue);
        return;
      case PfePackage.STYLE_TEXT__BORDER_BOTTOM_COLORE:
        setBorderBottomColore((Colors)newValue);
        return;
      case PfePackage.STYLE_TEXT__BORDER_BOTTOM_LEFT_RADIUSE:
        setBorderBottomLeftRadiuse((entier)newValue);
        return;
      case PfePackage.STYLE_TEXT__BORDER_BOTTOM_RIGHT_RADIUSE:
        setBorderBottomRightRadiuse((entier)newValue);
        return;
      case PfePackage.STYLE_TEXT__BORDER_BOTTOM_WIDTHE:
        setBorderBottomWidthe((entier)newValue);
        return;
      case PfePackage.STYLE_TEXT__BORDER_COLORE:
        setBorderColore((Colors)newValue);
        return;
      case PfePackage.STYLE_TEXT__BORDER_LEFT_COLORE:
        setBorderLeftColore((Colors)newValue);
        return;
      case PfePackage.STYLE_TEXT__BORDER_LEFT_WIDTHE:
        setBorderLeftWidthe((entier)newValue);
        return;
      case PfePackage.STYLE_TEXT__BORDER_RADIUSE:
        setBorderRadiuse((entier)newValue);
        return;
      case PfePackage.STYLE_TEXT__BORDER_RIGHT_COLORE:
        setBorderRightColore((Colors)newValue);
        return;
      case PfePackage.STYLE_TEXT__BORDER_RIGHT_WIDTH:
        setBorderRightWidth((entier)newValue);
        return;
      case PfePackage.STYLE_TEXT__BORDER_STYLES:
        setBorderStyles((bordersty)newValue);
        return;
      case PfePackage.STYLE_TEXT__BORDER_TOP_COLORE:
        setBorderTopColore((Colors)newValue);
        return;
      case PfePackage.STYLE_TEXT__BORDER_TOP_LEFT_RADIUSE:
        setBorderTopLeftRadiuse((entier)newValue);
        return;
      case PfePackage.STYLE_TEXT__BORDER_TOP_RIGHT_RADIUSE:
        setBorderTopRightRadiuse((entier)newValue);
        return;
      case PfePackage.STYLE_TEXT__BORDER_TOP_WIDTHE:
        setBorderTopWidthe((entier)newValue);
        return;
      case PfePackage.STYLE_TEXT__BORDER_WIDTHE:
        setBorderWidthe((entier)newValue);
        return;
      case PfePackage.STYLE_TEXT__OPACITYE:
        setOpacitye((entier)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.STYLE_TEXT__COLORE:
        setColore(COLORE_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__FONT_FAMILY_E:
        setFontFamilyE(FONT_FAMILY_E_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__FONT_SIZES:
        setFontSizes(FONT_SIZES_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__FONT_STYLES:
        setFontStyles(FONT_STYLES_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__FONT_WEIGHTE:
        setFontWeighte(FONT_WEIGHTE_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__LINE_HEIGHTE:
        setLineHeighte(LINE_HEIGHTE_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__TEXT_ALIGNE:
        setTextAligne(TEXT_ALIGNE_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__BACKFACE_VISIBILITYE:
        setBackfaceVisibilitye(BACKFACE_VISIBILITYE_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__BACKGROUND_COLORE:
        setBackgroundColore(BACKGROUND_COLORE_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__BORDER_BOTTOM_COLORE:
        setBorderBottomColore(BORDER_BOTTOM_COLORE_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__BORDER_BOTTOM_LEFT_RADIUSE:
        setBorderBottomLeftRadiuse(BORDER_BOTTOM_LEFT_RADIUSE_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__BORDER_BOTTOM_RIGHT_RADIUSE:
        setBorderBottomRightRadiuse(BORDER_BOTTOM_RIGHT_RADIUSE_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__BORDER_BOTTOM_WIDTHE:
        setBorderBottomWidthe(BORDER_BOTTOM_WIDTHE_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__BORDER_COLORE:
        setBorderColore(BORDER_COLORE_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__BORDER_LEFT_COLORE:
        setBorderLeftColore(BORDER_LEFT_COLORE_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__BORDER_LEFT_WIDTHE:
        setBorderLeftWidthe(BORDER_LEFT_WIDTHE_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__BORDER_RADIUSE:
        setBorderRadiuse(BORDER_RADIUSE_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__BORDER_RIGHT_COLORE:
        setBorderRightColore(BORDER_RIGHT_COLORE_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__BORDER_RIGHT_WIDTH:
        setBorderRightWidth(BORDER_RIGHT_WIDTH_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__BORDER_STYLES:
        setBorderStyles(BORDER_STYLES_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__BORDER_TOP_COLORE:
        setBorderTopColore(BORDER_TOP_COLORE_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__BORDER_TOP_LEFT_RADIUSE:
        setBorderTopLeftRadiuse(BORDER_TOP_LEFT_RADIUSE_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__BORDER_TOP_RIGHT_RADIUSE:
        setBorderTopRightRadiuse(BORDER_TOP_RIGHT_RADIUSE_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__BORDER_TOP_WIDTHE:
        setBorderTopWidthe(BORDER_TOP_WIDTHE_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__BORDER_WIDTHE:
        setBorderWidthe(BORDER_WIDTHE_EDEFAULT);
        return;
      case PfePackage.STYLE_TEXT__OPACITYE:
        setOpacitye(OPACITYE_EDEFAULT);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.STYLE_TEXT__COLORE:
        return colore != COLORE_EDEFAULT;
      case PfePackage.STYLE_TEXT__FONT_FAMILY_E:
        return fontFamilyE != FONT_FAMILY_E_EDEFAULT;
      case PfePackage.STYLE_TEXT__FONT_SIZES:
        return fontSizes != FONT_SIZES_EDEFAULT;
      case PfePackage.STYLE_TEXT__FONT_STYLES:
        return fontStyles != FONT_STYLES_EDEFAULT;
      case PfePackage.STYLE_TEXT__FONT_WEIGHTE:
        return fontWeighte != FONT_WEIGHTE_EDEFAULT;
      case PfePackage.STYLE_TEXT__LINE_HEIGHTE:
        return lineHeighte != LINE_HEIGHTE_EDEFAULT;
      case PfePackage.STYLE_TEXT__TEXT_ALIGNE:
        return textAligne != TEXT_ALIGNE_EDEFAULT;
      case PfePackage.STYLE_TEXT__BACKFACE_VISIBILITYE:
        return backfaceVisibilitye != BACKFACE_VISIBILITYE_EDEFAULT;
      case PfePackage.STYLE_TEXT__BACKGROUND_COLORE:
        return backgroundColore != BACKGROUND_COLORE_EDEFAULT;
      case PfePackage.STYLE_TEXT__BORDER_BOTTOM_COLORE:
        return borderBottomColore != BORDER_BOTTOM_COLORE_EDEFAULT;
      case PfePackage.STYLE_TEXT__BORDER_BOTTOM_LEFT_RADIUSE:
        return borderBottomLeftRadiuse != BORDER_BOTTOM_LEFT_RADIUSE_EDEFAULT;
      case PfePackage.STYLE_TEXT__BORDER_BOTTOM_RIGHT_RADIUSE:
        return borderBottomRightRadiuse != BORDER_BOTTOM_RIGHT_RADIUSE_EDEFAULT;
      case PfePackage.STYLE_TEXT__BORDER_BOTTOM_WIDTHE:
        return borderBottomWidthe != BORDER_BOTTOM_WIDTHE_EDEFAULT;
      case PfePackage.STYLE_TEXT__BORDER_COLORE:
        return borderColore != BORDER_COLORE_EDEFAULT;
      case PfePackage.STYLE_TEXT__BORDER_LEFT_COLORE:
        return borderLeftColore != BORDER_LEFT_COLORE_EDEFAULT;
      case PfePackage.STYLE_TEXT__BORDER_LEFT_WIDTHE:
        return borderLeftWidthe != BORDER_LEFT_WIDTHE_EDEFAULT;
      case PfePackage.STYLE_TEXT__BORDER_RADIUSE:
        return borderRadiuse != BORDER_RADIUSE_EDEFAULT;
      case PfePackage.STYLE_TEXT__BORDER_RIGHT_COLORE:
        return borderRightColore != BORDER_RIGHT_COLORE_EDEFAULT;
      case PfePackage.STYLE_TEXT__BORDER_RIGHT_WIDTH:
        return borderRightWidth != BORDER_RIGHT_WIDTH_EDEFAULT;
      case PfePackage.STYLE_TEXT__BORDER_STYLES:
        return borderStyles != BORDER_STYLES_EDEFAULT;
      case PfePackage.STYLE_TEXT__BORDER_TOP_COLORE:
        return borderTopColore != BORDER_TOP_COLORE_EDEFAULT;
      case PfePackage.STYLE_TEXT__BORDER_TOP_LEFT_RADIUSE:
        return borderTopLeftRadiuse != BORDER_TOP_LEFT_RADIUSE_EDEFAULT;
      case PfePackage.STYLE_TEXT__BORDER_TOP_RIGHT_RADIUSE:
        return borderTopRightRadiuse != BORDER_TOP_RIGHT_RADIUSE_EDEFAULT;
      case PfePackage.STYLE_TEXT__BORDER_TOP_WIDTHE:
        return borderTopWidthe != BORDER_TOP_WIDTHE_EDEFAULT;
      case PfePackage.STYLE_TEXT__BORDER_WIDTHE:
        return borderWidthe != BORDER_WIDTHE_EDEFAULT;
      case PfePackage.STYLE_TEXT__OPACITYE:
        return opacitye != OPACITYE_EDEFAULT;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (colore: ");
    result.append(colore);
    result.append(", fontFamilyE: ");
    result.append(fontFamilyE);
    result.append(", fontSizes: ");
    result.append(fontSizes);
    result.append(", fontStyles: ");
    result.append(fontStyles);
    result.append(", fontWeighte: ");
    result.append(fontWeighte);
    result.append(", lineHeighte: ");
    result.append(lineHeighte);
    result.append(", TextAligne: ");
    result.append(textAligne);
    result.append(", backfaceVisibilitye: ");
    result.append(backfaceVisibilitye);
    result.append(", backgroundColore: ");
    result.append(backgroundColore);
    result.append(", borderBottomColore: ");
    result.append(borderBottomColore);
    result.append(", borderBottomLeftRadiuse: ");
    result.append(borderBottomLeftRadiuse);
    result.append(", borderBottomRightRadiuse: ");
    result.append(borderBottomRightRadiuse);
    result.append(", borderBottomWidthe: ");
    result.append(borderBottomWidthe);
    result.append(", borderColore: ");
    result.append(borderColore);
    result.append(", borderLeftColore: ");
    result.append(borderLeftColore);
    result.append(", borderLeftWidthe: ");
    result.append(borderLeftWidthe);
    result.append(", borderRadiuse: ");
    result.append(borderRadiuse);
    result.append(", borderRightColore: ");
    result.append(borderRightColore);
    result.append(", borderRightWidth: ");
    result.append(borderRightWidth);
    result.append(", borderStyles: ");
    result.append(borderStyles);
    result.append(", borderTopColore: ");
    result.append(borderTopColore);
    result.append(", borderTopLeftRadiuse: ");
    result.append(borderTopLeftRadiuse);
    result.append(", borderTopRightRadiuse: ");
    result.append(borderTopRightRadiuse);
    result.append(", borderTopWidthe: ");
    result.append(borderTopWidthe);
    result.append(", borderWidthe: ");
    result.append(borderWidthe);
    result.append(", opacitye: ");
    result.append(opacitye);
    result.append(')');
    return result.toString();
  }

} //StyleTextImpl
