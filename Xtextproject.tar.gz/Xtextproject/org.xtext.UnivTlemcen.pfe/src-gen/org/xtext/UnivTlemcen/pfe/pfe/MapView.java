/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;

import java.math.BigDecimal;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Map View</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.MapView#getLatitude <em>Latitude</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.MapView#getLongitude <em>Longitude</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.MapView#getLatitudeDelta <em>Latitude Delta</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.MapView#getLongitudeDelta <em>Longitude Delta</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.MapView#getLigne <em>Ligne</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.MapView#getColone <em>Colone</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getMapView()
 * @model
 * @generated
 */
public interface MapView extends composant
{
  /**
   * Returns the value of the '<em><b>Latitude</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Latitude</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Latitude</em>' attribute.
   * @see #setLatitude(BigDecimal)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getMapView_Latitude()
   * @model
   * @generated
   */
  BigDecimal getLatitude();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.MapView#getLatitude <em>Latitude</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Latitude</em>' attribute.
   * @see #getLatitude()
   * @generated
   */
  void setLatitude(BigDecimal value);

  /**
   * Returns the value of the '<em><b>Longitude</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Longitude</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Longitude</em>' attribute.
   * @see #setLongitude(BigDecimal)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getMapView_Longitude()
   * @model
   * @generated
   */
  BigDecimal getLongitude();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.MapView#getLongitude <em>Longitude</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Longitude</em>' attribute.
   * @see #getLongitude()
   * @generated
   */
  void setLongitude(BigDecimal value);

  /**
   * Returns the value of the '<em><b>Latitude Delta</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Latitude Delta</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Latitude Delta</em>' attribute.
   * @see #setLatitudeDelta(BigDecimal)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getMapView_LatitudeDelta()
   * @model
   * @generated
   */
  BigDecimal getLatitudeDelta();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.MapView#getLatitudeDelta <em>Latitude Delta</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Latitude Delta</em>' attribute.
   * @see #getLatitudeDelta()
   * @generated
   */
  void setLatitudeDelta(BigDecimal value);

  /**
   * Returns the value of the '<em><b>Longitude Delta</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Longitude Delta</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Longitude Delta</em>' attribute.
   * @see #setLongitudeDelta(BigDecimal)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getMapView_LongitudeDelta()
   * @model
   * @generated
   */
  BigDecimal getLongitudeDelta();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.MapView#getLongitudeDelta <em>Longitude Delta</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Longitude Delta</em>' attribute.
   * @see #getLongitudeDelta()
   * @generated
   */
  void setLongitudeDelta(BigDecimal value);

  /**
   * Returns the value of the '<em><b>Ligne</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.LC}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Ligne</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Ligne</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #setLigne(LC)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getMapView_Ligne()
   * @model
   * @generated
   */
  LC getLigne();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.MapView#getLigne <em>Ligne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Ligne</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #getLigne()
   * @generated
   */
  void setLigne(LC value);

  /**
   * Returns the value of the '<em><b>Colone</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.LC}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Colone</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Colone</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #setColone(LC)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getMapView_Colone()
   * @model
   * @generated
   */
  LC getColone();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.MapView#getColone <em>Colone</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Colone</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #getColone()
   * @generated
   */
  void setColone(LC value);

} // MapView
