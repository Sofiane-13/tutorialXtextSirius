/**
 */
package org.xtext.UnivTlemcen.pfe.pfe.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.xtext.UnivTlemcen.pfe.pfe.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class PfeFactoryImpl extends EFactoryImpl implements PfeFactory
{
  /**
   * Creates the default factory implementation.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static PfeFactory init()
  {
    try
    {
      PfeFactory thePfeFactory = (PfeFactory)EPackage.Registry.INSTANCE.getEFactory(PfePackage.eNS_URI);
      if (thePfeFactory != null)
      {
        return thePfeFactory;
      }
    }
    catch (Exception exception)
    {
      EcorePlugin.INSTANCE.log(exception);
    }
    return new PfeFactoryImpl();
  }

  /**
   * Creates an instance of the factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public PfeFactoryImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public EObject create(EClass eClass)
  {
    switch (eClass.getClassifierID())
    {
      case PfePackage.APPLICATION: return createApplication();
      case PfePackage.CONTROLEUR: return createControleur();
      case PfePackage.FONCTIONS: return createFonctions();
      case PfePackage.STYLESHEET: return createstylesheet();
      case PfePackage.FONCTION: return createfonction();
      case PfePackage.STYLE_TEXT: return createStyleText();
      case PfePackage.STYLE_VIEW: return createStyleView();
      case PfePackage.STYLE_IMAGE: return createStyleImage();
      case PfePackage.STYLEFLEXBOX: return createStyleflexbox();
      case PfePackage.REMPLIR_TABLE: return createRemplirTable();
      case PfePackage.ALERTE_FONCTION: return createAlerteFonction();
      case PfePackage.NAVIGATE: return createNavigate();
      case PfePackage.VUE: return createVue();
      case PfePackage.ELEMENTS: return createElements();
      case PfePackage.COMPOSANT: return createcomposant();
      case PfePackage.FORMS: return createForms();
      case PfePackage.LISTS: return createlists();
      case PfePackage.ICONS: return createIcons();
      case PfePackage.LIST_VIEW: return createlistView();
      case PfePackage.RADIO_BUTTON: return createRadioButton();
      case PfePackage.CHECK_BOX: return createCheckBox();
      case PfePackage.TEXT: return createText();
      case PfePackage.INPUT: return createInput();
      case PfePackage.ICONE: return createIcone();
      case PfePackage.SOCIAL_ICON: return createSocialIcon();
      case PfePackage.TAB: return createTab();
      case PfePackage.HEADING: return createHeading();
      case PfePackage.CONTAINER_STYLE: return createContainerStyle();
      case PfePackage.CONTAINER_FONCTIONS: return createContainerFonctions();
      case PfePackage.LAYOUT: return createLayout();
      case PfePackage.BOUTON: return createBouton();
      case PfePackage.VIDEO: return createVideo();
      case PfePackage.AUDIO: return createAudio();
      case PfePackage.MAP_VIEW: return createMapView();
      case PfePackage.IMAGE: return createImage();
      case PfePackage.MODEL: return createModel();
      case PfePackage.TABLE_DEFINITION: return createTableDefinition();
      default:
        throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object createFromString(EDataType eDataType, String initialValue)
  {
    switch (eDataType.getClassifierID())
    {
      case PfePackage.ONE:
        return createOneFromString(eDataType, initialValue);
      case PfePackage.NINE:
        return createNineFromString(eDataType, initialValue);
      case PfePackage.EIGNTH:
        return createEignthFromString(eDataType, initialValue);
      case PfePackage.THREE:
        return createThreeFromString(eDataType, initialValue);
      case PfePackage.FOOR:
        return createFoorFromString(eDataType, initialValue);
      case PfePackage.COLORS:
        return createColorsFromString(eDataType, initialValue);
      case PfePackage.ALI_IT:
        return createaliITFromString(eDataType, initialValue);
      case PfePackage.ALFEM:
        return createalfemFromString(eDataType, initialValue);
      case PfePackage.BORDERSTY:
        return createborderstyFromString(eDataType, initialValue);
      case PfePackage.TEXT_TYPE:
        return createtextTypeFromString(eDataType, initialValue);
      case PfePackage.BACKNUM:
        return createBacknumFromString(eDataType, initialValue);
      case PfePackage.TYPE_H:
        return createTypeHFromString(eDataType, initialValue);
      case PfePackage.ICON_TYPE:
        return createIconTypeFromString(eDataType, initialValue);
      case PfePackage.SIZELIST:
        return createsizelistFromString(eDataType, initialValue);
      case PfePackage.SOCIAL_ICON_TYPE:
        return createSocialIconTypeFromString(eDataType, initialValue);
      case PfePackage.FLEXD:
        return createflexdFromString(eDataType, initialValue);
      case PfePackage.MUT:
        return createmutFromString(eDataType, initialValue);
      case PfePackage.BUTTON_TYPE:
        return createbuttonTypeFromString(eDataType, initialValue);
      case PfePackage.RAISED_TYPE:
        return createraisedTypeFromString(eDataType, initialValue);
      case PfePackage.PROP_TYPE:
        return createPropTypeFromString(eDataType, initialValue);
      case PfePackage.ICON_RIGHT_TYPE:
        return createIconRightTypeFromString(eDataType, initialValue);
      case PfePackage.JUSTIFY_CONTENT_TYPE:
        return createJustifyContentTypeFromString(eDataType, initialValue);
      case PfePackage.ENTIER:
        return createentierFromString(eDataType, initialValue);
      case PfePackage.LC:
        return createLCFromString(eDataType, initialValue);
      default:
        throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String convertToString(EDataType eDataType, Object instanceValue)
  {
    switch (eDataType.getClassifierID())
    {
      case PfePackage.ONE:
        return convertOneToString(eDataType, instanceValue);
      case PfePackage.NINE:
        return convertNineToString(eDataType, instanceValue);
      case PfePackage.EIGNTH:
        return convertEignthToString(eDataType, instanceValue);
      case PfePackage.THREE:
        return convertThreeToString(eDataType, instanceValue);
      case PfePackage.FOOR:
        return convertFoorToString(eDataType, instanceValue);
      case PfePackage.COLORS:
        return convertColorsToString(eDataType, instanceValue);
      case PfePackage.ALI_IT:
        return convertaliITToString(eDataType, instanceValue);
      case PfePackage.ALFEM:
        return convertalfemToString(eDataType, instanceValue);
      case PfePackage.BORDERSTY:
        return convertborderstyToString(eDataType, instanceValue);
      case PfePackage.TEXT_TYPE:
        return converttextTypeToString(eDataType, instanceValue);
      case PfePackage.BACKNUM:
        return convertBacknumToString(eDataType, instanceValue);
      case PfePackage.TYPE_H:
        return convertTypeHToString(eDataType, instanceValue);
      case PfePackage.ICON_TYPE:
        return convertIconTypeToString(eDataType, instanceValue);
      case PfePackage.SIZELIST:
        return convertsizelistToString(eDataType, instanceValue);
      case PfePackage.SOCIAL_ICON_TYPE:
        return convertSocialIconTypeToString(eDataType, instanceValue);
      case PfePackage.FLEXD:
        return convertflexdToString(eDataType, instanceValue);
      case PfePackage.MUT:
        return convertmutToString(eDataType, instanceValue);
      case PfePackage.BUTTON_TYPE:
        return convertbuttonTypeToString(eDataType, instanceValue);
      case PfePackage.RAISED_TYPE:
        return convertraisedTypeToString(eDataType, instanceValue);
      case PfePackage.PROP_TYPE:
        return convertPropTypeToString(eDataType, instanceValue);
      case PfePackage.ICON_RIGHT_TYPE:
        return convertIconRightTypeToString(eDataType, instanceValue);
      case PfePackage.JUSTIFY_CONTENT_TYPE:
        return convertJustifyContentTypeToString(eDataType, instanceValue);
      case PfePackage.ENTIER:
        return convertentierToString(eDataType, instanceValue);
      case PfePackage.LC:
        return convertLCToString(eDataType, instanceValue);
      default:
        throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Application createApplication()
  {
    ApplicationImpl application = new ApplicationImpl();
    return application;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Controleur createControleur()
  {
    ControleurImpl controleur = new ControleurImpl();
    return controleur;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Fonctions createFonctions()
  {
    FonctionsImpl fonctions = new FonctionsImpl();
    return fonctions;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public stylesheet createstylesheet()
  {
    stylesheetImpl stylesheet = new stylesheetImpl();
    return stylesheet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public fonction createfonction()
  {
    fonctionImpl fonction = new fonctionImpl();
    return fonction;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public StyleText createStyleText()
  {
    StyleTextImpl styleText = new StyleTextImpl();
    return styleText;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public StyleView createStyleView()
  {
    StyleViewImpl styleView = new StyleViewImpl();
    return styleView;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public StyleImage createStyleImage()
  {
    StyleImageImpl styleImage = new StyleImageImpl();
    return styleImage;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Styleflexbox createStyleflexbox()
  {
    StyleflexboxImpl styleflexbox = new StyleflexboxImpl();
    return styleflexbox;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public RemplirTable createRemplirTable()
  {
    RemplirTableImpl remplirTable = new RemplirTableImpl();
    return remplirTable;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public AlerteFonction createAlerteFonction()
  {
    AlerteFonctionImpl alerteFonction = new AlerteFonctionImpl();
    return alerteFonction;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Navigate createNavigate()
  {
    NavigateImpl navigate = new NavigateImpl();
    return navigate;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Vue createVue()
  {
    VueImpl vue = new VueImpl();
    return vue;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Elements createElements()
  {
    ElementsImpl elements = new ElementsImpl();
    return elements;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public composant createcomposant()
  {
    composantImpl composant = new composantImpl();
    return composant;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Forms createForms()
  {
    FormsImpl forms = new FormsImpl();
    return forms;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public lists createlists()
  {
    listsImpl lists = new listsImpl();
    return lists;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Icons createIcons()
  {
    IconsImpl icons = new IconsImpl();
    return icons;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public listView createlistView()
  {
    listViewImpl listView = new listViewImpl();
    return listView;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public RadioButton createRadioButton()
  {
    RadioButtonImpl radioButton = new RadioButtonImpl();
    return radioButton;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public CheckBox createCheckBox()
  {
    CheckBoxImpl checkBox = new CheckBoxImpl();
    return checkBox;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Text createText()
  {
    TextImpl text = new TextImpl();
    return text;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Input createInput()
  {
    InputImpl input = new InputImpl();
    return input;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Icone createIcone()
  {
    IconeImpl icone = new IconeImpl();
    return icone;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public SocialIcon createSocialIcon()
  {
    SocialIconImpl socialIcon = new SocialIconImpl();
    return socialIcon;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Tab createTab()
  {
    TabImpl tab = new TabImpl();
    return tab;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Heading createHeading()
  {
    HeadingImpl heading = new HeadingImpl();
    return heading;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ContainerStyle createContainerStyle()
  {
    ContainerStyleImpl containerStyle = new ContainerStyleImpl();
    return containerStyle;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ContainerFonctions createContainerFonctions()
  {
    ContainerFonctionsImpl containerFonctions = new ContainerFonctionsImpl();
    return containerFonctions;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Layout createLayout()
  {
    LayoutImpl layout = new LayoutImpl();
    return layout;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Bouton createBouton()
  {
    BoutonImpl bouton = new BoutonImpl();
    return bouton;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Video createVideo()
  {
    VideoImpl video = new VideoImpl();
    return video;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Audio createAudio()
  {
    AudioImpl audio = new AudioImpl();
    return audio;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MapView createMapView()
  {
    MapViewImpl mapView = new MapViewImpl();
    return mapView;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Image createImage()
  {
    ImageImpl image = new ImageImpl();
    return image;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Model createModel()
  {
    ModelImpl model = new ModelImpl();
    return model;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TableDefinition createTableDefinition()
  {
    TableDefinitionImpl tableDefinition = new TableDefinitionImpl();
    return tableDefinition;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public One createOneFromString(EDataType eDataType, String initialValue)
  {
    One result = One.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertOneToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Nine createNineFromString(EDataType eDataType, String initialValue)
  {
    Nine result = Nine.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertNineToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Eignth createEignthFromString(EDataType eDataType, String initialValue)
  {
    Eignth result = Eignth.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertEignthToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Three createThreeFromString(EDataType eDataType, String initialValue)
  {
    Three result = Three.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertThreeToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Foor createFoorFromString(EDataType eDataType, String initialValue)
  {
    Foor result = Foor.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertFoorToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Colors createColorsFromString(EDataType eDataType, String initialValue)
  {
    Colors result = Colors.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertColorsToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public aliIT createaliITFromString(EDataType eDataType, String initialValue)
  {
    aliIT result = aliIT.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertaliITToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public alfem createalfemFromString(EDataType eDataType, String initialValue)
  {
    alfem result = alfem.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertalfemToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public bordersty createborderstyFromString(EDataType eDataType, String initialValue)
  {
    bordersty result = bordersty.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertborderstyToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public textType createtextTypeFromString(EDataType eDataType, String initialValue)
  {
    textType result = textType.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String converttextTypeToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Backnum createBacknumFromString(EDataType eDataType, String initialValue)
  {
    Backnum result = Backnum.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertBacknumToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TypeH createTypeHFromString(EDataType eDataType, String initialValue)
  {
    TypeH result = TypeH.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertTypeHToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public IconType createIconTypeFromString(EDataType eDataType, String initialValue)
  {
    IconType result = IconType.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertIconTypeToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public sizelist createsizelistFromString(EDataType eDataType, String initialValue)
  {
    sizelist result = sizelist.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertsizelistToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public SocialIconType createSocialIconTypeFromString(EDataType eDataType, String initialValue)
  {
    SocialIconType result = SocialIconType.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertSocialIconTypeToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public flexd createflexdFromString(EDataType eDataType, String initialValue)
  {
    flexd result = flexd.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertflexdToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public mut createmutFromString(EDataType eDataType, String initialValue)
  {
    mut result = mut.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertmutToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public buttonType createbuttonTypeFromString(EDataType eDataType, String initialValue)
  {
    buttonType result = buttonType.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertbuttonTypeToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public raisedType createraisedTypeFromString(EDataType eDataType, String initialValue)
  {
    raisedType result = raisedType.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertraisedTypeToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public PropType createPropTypeFromString(EDataType eDataType, String initialValue)
  {
    PropType result = PropType.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertPropTypeToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public IconRightType createIconRightTypeFromString(EDataType eDataType, String initialValue)
  {
    IconRightType result = IconRightType.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertIconRightTypeToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public JustifyContentType createJustifyContentTypeFromString(EDataType eDataType, String initialValue)
  {
    JustifyContentType result = JustifyContentType.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertJustifyContentTypeToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier createentierFromString(EDataType eDataType, String initialValue)
  {
    entier result = entier.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertentierToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LC createLCFromString(EDataType eDataType, String initialValue)
  {
    LC result = LC.get(initialValue);
    if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertLCToString(EDataType eDataType, Object instanceValue)
  {
    return instanceValue == null ? null : instanceValue.toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public PfePackage getPfePackage()
  {
    return (PfePackage)getEPackage();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @deprecated
   * @generated
   */
  @Deprecated
  public static PfePackage getPackage()
  {
    return PfePackage.eINSTANCE;
  }

} //PfeFactoryImpl
