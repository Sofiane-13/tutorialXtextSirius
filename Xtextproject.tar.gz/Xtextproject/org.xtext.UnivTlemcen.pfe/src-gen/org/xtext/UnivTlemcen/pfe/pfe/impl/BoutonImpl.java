/**
 */
package org.xtext.UnivTlemcen.pfe.pfe.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import org.xtext.UnivTlemcen.pfe.pfe.Bouton;
import org.xtext.UnivTlemcen.pfe.pfe.IconRightType;
import org.xtext.UnivTlemcen.pfe.pfe.Icone;
import org.xtext.UnivTlemcen.pfe.pfe.LC;
import org.xtext.UnivTlemcen.pfe.pfe.PfePackage;
import org.xtext.UnivTlemcen.pfe.pfe.PropType;
import org.xtext.UnivTlemcen.pfe.pfe.StyleView;
import org.xtext.UnivTlemcen.pfe.pfe.fonction;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Bouton</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.BoutonImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.BoutonImpl#getIcon <em>Icon</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.BoutonImpl#getOnclique <em>Onclique</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.BoutonImpl#getOnlongclique <em>Onlongclique</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.BoutonImpl#getProp <em>Prop</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.BoutonImpl#getIconRight <em>Icon Right</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.BoutonImpl#getLigne <em>Ligne</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.BoutonImpl#getColonne <em>Colonne</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.BoutonImpl#getStyle <em>Style</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class BoutonImpl extends ElementsImpl implements Bouton
{
  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The cached value of the '{@link #getIcon() <em>Icon</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIcon()
   * @generated
   * @ordered
   */
  protected Icone icon;

  /**
   * The cached value of the '{@link #getOnclique() <em>Onclique</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOnclique()
   * @generated
   * @ordered
   */
  protected EList<fonction> onclique;

  /**
   * The cached value of the '{@link #getOnlongclique() <em>Onlongclique</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOnlongclique()
   * @generated
   * @ordered
   */
  protected EList<fonction> onlongclique;

  /**
   * The default value of the '{@link #getProp() <em>Prop</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getProp()
   * @generated
   * @ordered
   */
  protected static final PropType PROP_EDEFAULT = PropType.NONE;

  /**
   * The cached value of the '{@link #getProp() <em>Prop</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getProp()
   * @generated
   * @ordered
   */
  protected PropType prop = PROP_EDEFAULT;

  /**
   * The default value of the '{@link #getIconRight() <em>Icon Right</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIconRight()
   * @generated
   * @ordered
   */
  protected static final IconRightType ICON_RIGHT_EDEFAULT = IconRightType.NONE;

  /**
   * The cached value of the '{@link #getIconRight() <em>Icon Right</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIconRight()
   * @generated
   * @ordered
   */
  protected IconRightType iconRight = ICON_RIGHT_EDEFAULT;

  /**
   * The default value of the '{@link #getLigne() <em>Ligne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLigne()
   * @generated
   * @ordered
   */
  protected static final LC LIGNE_EDEFAULT = LC.UN;

  /**
   * The cached value of the '{@link #getLigne() <em>Ligne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLigne()
   * @generated
   * @ordered
   */
  protected LC ligne = LIGNE_EDEFAULT;

  /**
   * The default value of the '{@link #getColonne() <em>Colonne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getColonne()
   * @generated
   * @ordered
   */
  protected static final LC COLONNE_EDEFAULT = LC.UN;

  /**
   * The cached value of the '{@link #getColonne() <em>Colonne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getColonne()
   * @generated
   * @ordered
   */
  protected LC colonne = COLONNE_EDEFAULT;

  /**
   * The cached value of the '{@link #getStyle() <em>Style</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getStyle()
   * @generated
   * @ordered
   */
  protected StyleView style;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected BoutonImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return PfePackage.Literals.BOUTON;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName)
  {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.BOUTON__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Icone getIcon()
  {
    if (icon != null && icon.eIsProxy())
    {
      InternalEObject oldIcon = (InternalEObject)icon;
      icon = (Icone)eResolveProxy(oldIcon);
      if (icon != oldIcon)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, PfePackage.BOUTON__ICON, oldIcon, icon));
      }
    }
    return icon;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Icone basicGetIcon()
  {
    return icon;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setIcon(Icone newIcon)
  {
    Icone oldIcon = icon;
    icon = newIcon;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.BOUTON__ICON, oldIcon, icon));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<fonction> getOnclique()
  {
    if (onclique == null)
    {
      onclique = new EObjectResolvingEList<fonction>(fonction.class, this, PfePackage.BOUTON__ONCLIQUE);
    }
    return onclique;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<fonction> getOnlongclique()
  {
    if (onlongclique == null)
    {
      onlongclique = new EObjectResolvingEList<fonction>(fonction.class, this, PfePackage.BOUTON__ONLONGCLIQUE);
    }
    return onlongclique;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public PropType getProp()
  {
    return prop;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setProp(PropType newProp)
  {
    PropType oldProp = prop;
    prop = newProp == null ? PROP_EDEFAULT : newProp;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.BOUTON__PROP, oldProp, prop));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public IconRightType getIconRight()
  {
    return iconRight;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setIconRight(IconRightType newIconRight)
  {
    IconRightType oldIconRight = iconRight;
    iconRight = newIconRight == null ? ICON_RIGHT_EDEFAULT : newIconRight;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.BOUTON__ICON_RIGHT, oldIconRight, iconRight));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LC getLigne()
  {
    return ligne;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLigne(LC newLigne)
  {
    LC oldLigne = ligne;
    ligne = newLigne == null ? LIGNE_EDEFAULT : newLigne;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.BOUTON__LIGNE, oldLigne, ligne));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LC getColonne()
  {
    return colonne;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setColonne(LC newColonne)
  {
    LC oldColonne = colonne;
    colonne = newColonne == null ? COLONNE_EDEFAULT : newColonne;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.BOUTON__COLONNE, oldColonne, colonne));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public StyleView getStyle()
  {
    if (style != null && style.eIsProxy())
    {
      InternalEObject oldStyle = (InternalEObject)style;
      style = (StyleView)eResolveProxy(oldStyle);
      if (style != oldStyle)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, PfePackage.BOUTON__STYLE, oldStyle, style));
      }
    }
    return style;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public StyleView basicGetStyle()
  {
    return style;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setStyle(StyleView newStyle)
  {
    StyleView oldStyle = style;
    style = newStyle;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.BOUTON__STYLE, oldStyle, style));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case PfePackage.BOUTON__NAME:
        return getName();
      case PfePackage.BOUTON__ICON:
        if (resolve) return getIcon();
        return basicGetIcon();
      case PfePackage.BOUTON__ONCLIQUE:
        return getOnclique();
      case PfePackage.BOUTON__ONLONGCLIQUE:
        return getOnlongclique();
      case PfePackage.BOUTON__PROP:
        return getProp();
      case PfePackage.BOUTON__ICON_RIGHT:
        return getIconRight();
      case PfePackage.BOUTON__LIGNE:
        return getLigne();
      case PfePackage.BOUTON__COLONNE:
        return getColonne();
      case PfePackage.BOUTON__STYLE:
        if (resolve) return getStyle();
        return basicGetStyle();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case PfePackage.BOUTON__NAME:
        setName((String)newValue);
        return;
      case PfePackage.BOUTON__ICON:
        setIcon((Icone)newValue);
        return;
      case PfePackage.BOUTON__ONCLIQUE:
        getOnclique().clear();
        getOnclique().addAll((Collection<? extends fonction>)newValue);
        return;
      case PfePackage.BOUTON__ONLONGCLIQUE:
        getOnlongclique().clear();
        getOnlongclique().addAll((Collection<? extends fonction>)newValue);
        return;
      case PfePackage.BOUTON__PROP:
        setProp((PropType)newValue);
        return;
      case PfePackage.BOUTON__ICON_RIGHT:
        setIconRight((IconRightType)newValue);
        return;
      case PfePackage.BOUTON__LIGNE:
        setLigne((LC)newValue);
        return;
      case PfePackage.BOUTON__COLONNE:
        setColonne((LC)newValue);
        return;
      case PfePackage.BOUTON__STYLE:
        setStyle((StyleView)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.BOUTON__NAME:
        setName(NAME_EDEFAULT);
        return;
      case PfePackage.BOUTON__ICON:
        setIcon((Icone)null);
        return;
      case PfePackage.BOUTON__ONCLIQUE:
        getOnclique().clear();
        return;
      case PfePackage.BOUTON__ONLONGCLIQUE:
        getOnlongclique().clear();
        return;
      case PfePackage.BOUTON__PROP:
        setProp(PROP_EDEFAULT);
        return;
      case PfePackage.BOUTON__ICON_RIGHT:
        setIconRight(ICON_RIGHT_EDEFAULT);
        return;
      case PfePackage.BOUTON__LIGNE:
        setLigne(LIGNE_EDEFAULT);
        return;
      case PfePackage.BOUTON__COLONNE:
        setColonne(COLONNE_EDEFAULT);
        return;
      case PfePackage.BOUTON__STYLE:
        setStyle((StyleView)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.BOUTON__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case PfePackage.BOUTON__ICON:
        return icon != null;
      case PfePackage.BOUTON__ONCLIQUE:
        return onclique != null && !onclique.isEmpty();
      case PfePackage.BOUTON__ONLONGCLIQUE:
        return onlongclique != null && !onlongclique.isEmpty();
      case PfePackage.BOUTON__PROP:
        return prop != PROP_EDEFAULT;
      case PfePackage.BOUTON__ICON_RIGHT:
        return iconRight != ICON_RIGHT_EDEFAULT;
      case PfePackage.BOUTON__LIGNE:
        return ligne != LIGNE_EDEFAULT;
      case PfePackage.BOUTON__COLONNE:
        return colonne != COLONNE_EDEFAULT;
      case PfePackage.BOUTON__STYLE:
        return style != null;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (name: ");
    result.append(name);
    result.append(", Prop: ");
    result.append(prop);
    result.append(", IconRight: ");
    result.append(iconRight);
    result.append(", ligne: ");
    result.append(ligne);
    result.append(", colonne: ");
    result.append(colonne);
    result.append(')');
    return result.toString();
  }

} //BoutonImpl
