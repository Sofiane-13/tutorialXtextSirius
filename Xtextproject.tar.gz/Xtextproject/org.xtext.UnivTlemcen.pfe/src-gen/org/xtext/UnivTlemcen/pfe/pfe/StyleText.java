/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Style Text</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getColore <em>Colore</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getFontFamilyE <em>Font Family E</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getFontSizes <em>Font Sizes</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getFontStyles <em>Font Styles</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getFontWeighte <em>Font Weighte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getLineHeighte <em>Line Heighte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getTextAligne <em>Text Aligne</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBackfaceVisibilitye <em>Backface Visibilitye</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBackgroundColore <em>Background Colore</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderBottomColore <em>Border Bottom Colore</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderBottomLeftRadiuse <em>Border Bottom Left Radiuse</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderBottomRightRadiuse <em>Border Bottom Right Radiuse</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderBottomWidthe <em>Border Bottom Widthe</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderColore <em>Border Colore</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderLeftColore <em>Border Left Colore</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderLeftWidthe <em>Border Left Widthe</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderRadiuse <em>Border Radiuse</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderRightColore <em>Border Right Colore</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderRightWidth <em>Border Right Width</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderStyles <em>Border Styles</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderTopColore <em>Border Top Colore</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderTopLeftRadiuse <em>Border Top Left Radiuse</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderTopRightRadiuse <em>Border Top Right Radiuse</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderTopWidthe <em>Border Top Widthe</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderWidthe <em>Border Widthe</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getOpacitye <em>Opacitye</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText()
 * @model
 * @generated
 */
public interface StyleText extends stylesheet
{
  /**
   * Returns the value of the '<em><b>Colore</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Colors}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Colore</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Colore</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #setColore(Colors)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_Colore()
   * @model
   * @generated
   */
  Colors getColore();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getColore <em>Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Colore</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #getColore()
   * @generated
   */
  void setColore(Colors value);

  /**
   * Returns the value of the '<em><b>Font Family E</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.TypeH}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Font Family E</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Font Family E</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.TypeH
   * @see #setFontFamilyE(TypeH)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_FontFamilyE()
   * @model
   * @generated
   */
  TypeH getFontFamilyE();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getFontFamilyE <em>Font Family E</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Font Family E</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.TypeH
   * @see #getFontFamilyE()
   * @generated
   */
  void setFontFamilyE(TypeH value);

  /**
   * Returns the value of the '<em><b>Font Sizes</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Font Sizes</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Font Sizes</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setFontSizes(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_FontSizes()
   * @model
   * @generated
   */
  entier getFontSizes();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getFontSizes <em>Font Sizes</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Font Sizes</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getFontSizes()
   * @generated
   */
  void setFontSizes(entier value);

  /**
   * Returns the value of the '<em><b>Font Styles</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Three}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Font Styles</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Font Styles</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Three
   * @see #setFontStyles(Three)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_FontStyles()
   * @model
   * @generated
   */
  Three getFontStyles();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getFontStyles <em>Font Styles</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Font Styles</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Three
   * @see #getFontStyles()
   * @generated
   */
  void setFontStyles(Three value);

  /**
   * Returns the value of the '<em><b>Font Weighte</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Foor}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Font Weighte</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Font Weighte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Foor
   * @see #setFontWeighte(Foor)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_FontWeighte()
   * @model
   * @generated
   */
  Foor getFontWeighte();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getFontWeighte <em>Font Weighte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Font Weighte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Foor
   * @see #getFontWeighte()
   * @generated
   */
  void setFontWeighte(Foor value);

  /**
   * Returns the value of the '<em><b>Line Heighte</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Line Heighte</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Line Heighte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setLineHeighte(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_LineHeighte()
   * @model
   * @generated
   */
  entier getLineHeighte();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getLineHeighte <em>Line Heighte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Line Heighte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getLineHeighte()
   * @generated
   */
  void setLineHeighte(entier value);

  /**
   * Returns the value of the '<em><b>Text Aligne</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Eignth}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Text Aligne</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Text Aligne</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Eignth
   * @see #setTextAligne(Eignth)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_TextAligne()
   * @model
   * @generated
   */
  Eignth getTextAligne();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getTextAligne <em>Text Aligne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Text Aligne</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Eignth
   * @see #getTextAligne()
   * @generated
   */
  void setTextAligne(Eignth value);

  /**
   * Returns the value of the '<em><b>Backface Visibilitye</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Backnum}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Backface Visibilitye</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Backface Visibilitye</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Backnum
   * @see #setBackfaceVisibilitye(Backnum)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_BackfaceVisibilitye()
   * @model
   * @generated
   */
  Backnum getBackfaceVisibilitye();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBackfaceVisibilitye <em>Backface Visibilitye</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Backface Visibilitye</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Backnum
   * @see #getBackfaceVisibilitye()
   * @generated
   */
  void setBackfaceVisibilitye(Backnum value);

  /**
   * Returns the value of the '<em><b>Background Colore</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Colors}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Background Colore</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Background Colore</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #setBackgroundColore(Colors)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_BackgroundColore()
   * @model
   * @generated
   */
  Colors getBackgroundColore();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBackgroundColore <em>Background Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Background Colore</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #getBackgroundColore()
   * @generated
   */
  void setBackgroundColore(Colors value);

  /**
   * Returns the value of the '<em><b>Border Bottom Colore</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Colors}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Bottom Colore</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Bottom Colore</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #setBorderBottomColore(Colors)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_BorderBottomColore()
   * @model
   * @generated
   */
  Colors getBorderBottomColore();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderBottomColore <em>Border Bottom Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Bottom Colore</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #getBorderBottomColore()
   * @generated
   */
  void setBorderBottomColore(Colors value);

  /**
   * Returns the value of the '<em><b>Border Bottom Left Radiuse</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Bottom Left Radiuse</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Bottom Left Radiuse</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderBottomLeftRadiuse(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_BorderBottomLeftRadiuse()
   * @model
   * @generated
   */
  entier getBorderBottomLeftRadiuse();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderBottomLeftRadiuse <em>Border Bottom Left Radiuse</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Bottom Left Radiuse</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderBottomLeftRadiuse()
   * @generated
   */
  void setBorderBottomLeftRadiuse(entier value);

  /**
   * Returns the value of the '<em><b>Border Bottom Right Radiuse</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Bottom Right Radiuse</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Bottom Right Radiuse</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderBottomRightRadiuse(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_BorderBottomRightRadiuse()
   * @model
   * @generated
   */
  entier getBorderBottomRightRadiuse();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderBottomRightRadiuse <em>Border Bottom Right Radiuse</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Bottom Right Radiuse</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderBottomRightRadiuse()
   * @generated
   */
  void setBorderBottomRightRadiuse(entier value);

  /**
   * Returns the value of the '<em><b>Border Bottom Widthe</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Bottom Widthe</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Bottom Widthe</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderBottomWidthe(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_BorderBottomWidthe()
   * @model
   * @generated
   */
  entier getBorderBottomWidthe();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderBottomWidthe <em>Border Bottom Widthe</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Bottom Widthe</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderBottomWidthe()
   * @generated
   */
  void setBorderBottomWidthe(entier value);

  /**
   * Returns the value of the '<em><b>Border Colore</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Colors}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Colore</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Colore</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #setBorderColore(Colors)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_BorderColore()
   * @model
   * @generated
   */
  Colors getBorderColore();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderColore <em>Border Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Colore</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #getBorderColore()
   * @generated
   */
  void setBorderColore(Colors value);

  /**
   * Returns the value of the '<em><b>Border Left Colore</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Colors}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Left Colore</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Left Colore</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #setBorderLeftColore(Colors)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_BorderLeftColore()
   * @model
   * @generated
   */
  Colors getBorderLeftColore();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderLeftColore <em>Border Left Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Left Colore</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #getBorderLeftColore()
   * @generated
   */
  void setBorderLeftColore(Colors value);

  /**
   * Returns the value of the '<em><b>Border Left Widthe</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Left Widthe</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Left Widthe</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderLeftWidthe(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_BorderLeftWidthe()
   * @model
   * @generated
   */
  entier getBorderLeftWidthe();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderLeftWidthe <em>Border Left Widthe</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Left Widthe</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderLeftWidthe()
   * @generated
   */
  void setBorderLeftWidthe(entier value);

  /**
   * Returns the value of the '<em><b>Border Radiuse</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Radiuse</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Radiuse</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderRadiuse(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_BorderRadiuse()
   * @model
   * @generated
   */
  entier getBorderRadiuse();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderRadiuse <em>Border Radiuse</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Radiuse</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderRadiuse()
   * @generated
   */
  void setBorderRadiuse(entier value);

  /**
   * Returns the value of the '<em><b>Border Right Colore</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Colors}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Right Colore</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Right Colore</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #setBorderRightColore(Colors)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_BorderRightColore()
   * @model
   * @generated
   */
  Colors getBorderRightColore();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderRightColore <em>Border Right Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Right Colore</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #getBorderRightColore()
   * @generated
   */
  void setBorderRightColore(Colors value);

  /**
   * Returns the value of the '<em><b>Border Right Width</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Right Width</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Right Width</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderRightWidth(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_BorderRightWidth()
   * @model
   * @generated
   */
  entier getBorderRightWidth();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderRightWidth <em>Border Right Width</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Right Width</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderRightWidth()
   * @generated
   */
  void setBorderRightWidth(entier value);

  /**
   * Returns the value of the '<em><b>Border Styles</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.bordersty}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Styles</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Styles</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.bordersty
   * @see #setBorderStyles(bordersty)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_BorderStyles()
   * @model
   * @generated
   */
  bordersty getBorderStyles();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderStyles <em>Border Styles</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Styles</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.bordersty
   * @see #getBorderStyles()
   * @generated
   */
  void setBorderStyles(bordersty value);

  /**
   * Returns the value of the '<em><b>Border Top Colore</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Colors}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Top Colore</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Top Colore</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #setBorderTopColore(Colors)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_BorderTopColore()
   * @model
   * @generated
   */
  Colors getBorderTopColore();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderTopColore <em>Border Top Colore</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Top Colore</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #getBorderTopColore()
   * @generated
   */
  void setBorderTopColore(Colors value);

  /**
   * Returns the value of the '<em><b>Border Top Left Radiuse</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Top Left Radiuse</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Top Left Radiuse</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderTopLeftRadiuse(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_BorderTopLeftRadiuse()
   * @model
   * @generated
   */
  entier getBorderTopLeftRadiuse();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderTopLeftRadiuse <em>Border Top Left Radiuse</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Top Left Radiuse</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderTopLeftRadiuse()
   * @generated
   */
  void setBorderTopLeftRadiuse(entier value);

  /**
   * Returns the value of the '<em><b>Border Top Right Radiuse</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Top Right Radiuse</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Top Right Radiuse</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderTopRightRadiuse(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_BorderTopRightRadiuse()
   * @model
   * @generated
   */
  entier getBorderTopRightRadiuse();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderTopRightRadiuse <em>Border Top Right Radiuse</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Top Right Radiuse</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderTopRightRadiuse()
   * @generated
   */
  void setBorderTopRightRadiuse(entier value);

  /**
   * Returns the value of the '<em><b>Border Top Widthe</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Top Widthe</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Top Widthe</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderTopWidthe(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_BorderTopWidthe()
   * @model
   * @generated
   */
  entier getBorderTopWidthe();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderTopWidthe <em>Border Top Widthe</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Top Widthe</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderTopWidthe()
   * @generated
   */
  void setBorderTopWidthe(entier value);

  /**
   * Returns the value of the '<em><b>Border Widthe</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Widthe</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Widthe</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderWidthe(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_BorderWidthe()
   * @model
   * @generated
   */
  entier getBorderWidthe();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderWidthe <em>Border Widthe</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Widthe</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderWidthe()
   * @generated
   */
  void setBorderWidthe(entier value);

  /**
   * Returns the value of the '<em><b>Opacitye</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Opacitye</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Opacitye</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setOpacitye(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleText_Opacitye()
   * @model
   * @generated
   */
  entier getOpacitye();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getOpacitye <em>Opacitye</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Opacitye</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getOpacitye()
   * @generated
   */
  void setOpacitye(entier value);

} // StyleText
