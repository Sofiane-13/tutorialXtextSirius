/**
 */
package org.xtext.UnivTlemcen.pfe.pfe.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.xtext.UnivTlemcen.pfe.pfe.Controleur;
import org.xtext.UnivTlemcen.pfe.pfe.PfePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Controleur</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class ControleurImpl extends MinimalEObjectImpl.Container implements Controleur
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ControleurImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return PfePackage.Literals.CONTROLEUR;
  }

} //ControleurImpl
