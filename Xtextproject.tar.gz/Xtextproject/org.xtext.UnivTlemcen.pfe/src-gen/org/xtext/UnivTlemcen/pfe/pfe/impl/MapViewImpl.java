/**
 */
package org.xtext.UnivTlemcen.pfe.pfe.impl;

import java.math.BigDecimal;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.xtext.UnivTlemcen.pfe.pfe.LC;
import org.xtext.UnivTlemcen.pfe.pfe.MapView;
import org.xtext.UnivTlemcen.pfe.pfe.PfePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Map View</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.MapViewImpl#getLatitude <em>Latitude</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.MapViewImpl#getLongitude <em>Longitude</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.MapViewImpl#getLatitudeDelta <em>Latitude Delta</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.MapViewImpl#getLongitudeDelta <em>Longitude Delta</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.MapViewImpl#getLigne <em>Ligne</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.MapViewImpl#getColone <em>Colone</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class MapViewImpl extends composantImpl implements MapView
{
  /**
   * The default value of the '{@link #getLatitude() <em>Latitude</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLatitude()
   * @generated
   * @ordered
   */
  protected static final BigDecimal LATITUDE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getLatitude() <em>Latitude</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLatitude()
   * @generated
   * @ordered
   */
  protected BigDecimal latitude = LATITUDE_EDEFAULT;

  /**
   * The default value of the '{@link #getLongitude() <em>Longitude</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLongitude()
   * @generated
   * @ordered
   */
  protected static final BigDecimal LONGITUDE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getLongitude() <em>Longitude</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLongitude()
   * @generated
   * @ordered
   */
  protected BigDecimal longitude = LONGITUDE_EDEFAULT;

  /**
   * The default value of the '{@link #getLatitudeDelta() <em>Latitude Delta</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLatitudeDelta()
   * @generated
   * @ordered
   */
  protected static final BigDecimal LATITUDE_DELTA_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getLatitudeDelta() <em>Latitude Delta</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLatitudeDelta()
   * @generated
   * @ordered
   */
  protected BigDecimal latitudeDelta = LATITUDE_DELTA_EDEFAULT;

  /**
   * The default value of the '{@link #getLongitudeDelta() <em>Longitude Delta</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLongitudeDelta()
   * @generated
   * @ordered
   */
  protected static final BigDecimal LONGITUDE_DELTA_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getLongitudeDelta() <em>Longitude Delta</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLongitudeDelta()
   * @generated
   * @ordered
   */
  protected BigDecimal longitudeDelta = LONGITUDE_DELTA_EDEFAULT;

  /**
   * The default value of the '{@link #getLigne() <em>Ligne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLigne()
   * @generated
   * @ordered
   */
  protected static final LC LIGNE_EDEFAULT = LC.UN;

  /**
   * The cached value of the '{@link #getLigne() <em>Ligne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLigne()
   * @generated
   * @ordered
   */
  protected LC ligne = LIGNE_EDEFAULT;

  /**
   * The default value of the '{@link #getColone() <em>Colone</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getColone()
   * @generated
   * @ordered
   */
  protected static final LC COLONE_EDEFAULT = LC.UN;

  /**
   * The cached value of the '{@link #getColone() <em>Colone</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getColone()
   * @generated
   * @ordered
   */
  protected LC colone = COLONE_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected MapViewImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return PfePackage.Literals.MAP_VIEW;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BigDecimal getLatitude()
  {
    return latitude;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLatitude(BigDecimal newLatitude)
  {
    BigDecimal oldLatitude = latitude;
    latitude = newLatitude;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.MAP_VIEW__LATITUDE, oldLatitude, latitude));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BigDecimal getLongitude()
  {
    return longitude;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLongitude(BigDecimal newLongitude)
  {
    BigDecimal oldLongitude = longitude;
    longitude = newLongitude;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.MAP_VIEW__LONGITUDE, oldLongitude, longitude));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BigDecimal getLatitudeDelta()
  {
    return latitudeDelta;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLatitudeDelta(BigDecimal newLatitudeDelta)
  {
    BigDecimal oldLatitudeDelta = latitudeDelta;
    latitudeDelta = newLatitudeDelta;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.MAP_VIEW__LATITUDE_DELTA, oldLatitudeDelta, latitudeDelta));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public BigDecimal getLongitudeDelta()
  {
    return longitudeDelta;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLongitudeDelta(BigDecimal newLongitudeDelta)
  {
    BigDecimal oldLongitudeDelta = longitudeDelta;
    longitudeDelta = newLongitudeDelta;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.MAP_VIEW__LONGITUDE_DELTA, oldLongitudeDelta, longitudeDelta));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LC getLigne()
  {
    return ligne;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLigne(LC newLigne)
  {
    LC oldLigne = ligne;
    ligne = newLigne == null ? LIGNE_EDEFAULT : newLigne;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.MAP_VIEW__LIGNE, oldLigne, ligne));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LC getColone()
  {
    return colone;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setColone(LC newColone)
  {
    LC oldColone = colone;
    colone = newColone == null ? COLONE_EDEFAULT : newColone;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.MAP_VIEW__COLONE, oldColone, colone));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case PfePackage.MAP_VIEW__LATITUDE:
        return getLatitude();
      case PfePackage.MAP_VIEW__LONGITUDE:
        return getLongitude();
      case PfePackage.MAP_VIEW__LATITUDE_DELTA:
        return getLatitudeDelta();
      case PfePackage.MAP_VIEW__LONGITUDE_DELTA:
        return getLongitudeDelta();
      case PfePackage.MAP_VIEW__LIGNE:
        return getLigne();
      case PfePackage.MAP_VIEW__COLONE:
        return getColone();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case PfePackage.MAP_VIEW__LATITUDE:
        setLatitude((BigDecimal)newValue);
        return;
      case PfePackage.MAP_VIEW__LONGITUDE:
        setLongitude((BigDecimal)newValue);
        return;
      case PfePackage.MAP_VIEW__LATITUDE_DELTA:
        setLatitudeDelta((BigDecimal)newValue);
        return;
      case PfePackage.MAP_VIEW__LONGITUDE_DELTA:
        setLongitudeDelta((BigDecimal)newValue);
        return;
      case PfePackage.MAP_VIEW__LIGNE:
        setLigne((LC)newValue);
        return;
      case PfePackage.MAP_VIEW__COLONE:
        setColone((LC)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.MAP_VIEW__LATITUDE:
        setLatitude(LATITUDE_EDEFAULT);
        return;
      case PfePackage.MAP_VIEW__LONGITUDE:
        setLongitude(LONGITUDE_EDEFAULT);
        return;
      case PfePackage.MAP_VIEW__LATITUDE_DELTA:
        setLatitudeDelta(LATITUDE_DELTA_EDEFAULT);
        return;
      case PfePackage.MAP_VIEW__LONGITUDE_DELTA:
        setLongitudeDelta(LONGITUDE_DELTA_EDEFAULT);
        return;
      case PfePackage.MAP_VIEW__LIGNE:
        setLigne(LIGNE_EDEFAULT);
        return;
      case PfePackage.MAP_VIEW__COLONE:
        setColone(COLONE_EDEFAULT);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.MAP_VIEW__LATITUDE:
        return LATITUDE_EDEFAULT == null ? latitude != null : !LATITUDE_EDEFAULT.equals(latitude);
      case PfePackage.MAP_VIEW__LONGITUDE:
        return LONGITUDE_EDEFAULT == null ? longitude != null : !LONGITUDE_EDEFAULT.equals(longitude);
      case PfePackage.MAP_VIEW__LATITUDE_DELTA:
        return LATITUDE_DELTA_EDEFAULT == null ? latitudeDelta != null : !LATITUDE_DELTA_EDEFAULT.equals(latitudeDelta);
      case PfePackage.MAP_VIEW__LONGITUDE_DELTA:
        return LONGITUDE_DELTA_EDEFAULT == null ? longitudeDelta != null : !LONGITUDE_DELTA_EDEFAULT.equals(longitudeDelta);
      case PfePackage.MAP_VIEW__LIGNE:
        return ligne != LIGNE_EDEFAULT;
      case PfePackage.MAP_VIEW__COLONE:
        return colone != COLONE_EDEFAULT;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (latitude: ");
    result.append(latitude);
    result.append(", longitude: ");
    result.append(longitude);
    result.append(", latitudeDelta: ");
    result.append(latitudeDelta);
    result.append(", longitudeDelta: ");
    result.append(longitudeDelta);
    result.append(", ligne: ");
    result.append(ligne);
    result.append(", colone: ");
    result.append(colone);
    result.append(')');
    return result.toString();
  }

} //MapViewImpl
