/**
 */
package org.xtext.UnivTlemcen.pfe.pfe.impl;

import java.util.Collection;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import org.xtext.UnivTlemcen.pfe.pfe.PfePackage;
import org.xtext.UnivTlemcen.pfe.pfe.RemplirTable;
import org.xtext.UnivTlemcen.pfe.pfe.TableDefinition;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Remplir Table</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.RemplirTableImpl#getUtiliser <em>Utiliser</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class RemplirTableImpl extends fonctionImpl implements RemplirTable
{
  /**
   * The cached value of the '{@link #getUtiliser() <em>Utiliser</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUtiliser()
   * @generated
   * @ordered
   */
  protected EList<TableDefinition> utiliser;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected RemplirTableImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return PfePackage.Literals.REMPLIR_TABLE;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<TableDefinition> getUtiliser()
  {
    if (utiliser == null)
    {
      utiliser = new EObjectResolvingEList<TableDefinition>(TableDefinition.class, this, PfePackage.REMPLIR_TABLE__UTILISER);
    }
    return utiliser;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case PfePackage.REMPLIR_TABLE__UTILISER:
        return getUtiliser();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case PfePackage.REMPLIR_TABLE__UTILISER:
        getUtiliser().clear();
        getUtiliser().addAll((Collection<? extends TableDefinition>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.REMPLIR_TABLE__UTILISER:
        getUtiliser().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.REMPLIR_TABLE__UTILISER:
        return utiliser != null && !utiliser.isEmpty();
    }
    return super.eIsSet(featureID);
  }

} //RemplirTableImpl
