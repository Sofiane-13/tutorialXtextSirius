/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Icone</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Icone#getType <em>Type</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getIcone()
 * @model
 * @generated
 */
public interface Icone extends Icons
{
  /**
   * Returns the value of the '<em><b>Type</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.IconType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Type</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Type</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.IconType
   * @see #setType(IconType)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getIcone_Type()
   * @model
   * @generated
   */
  IconType getType();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Icone#getType <em>Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Type</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.IconType
   * @see #getType()
   * @generated
   */
  void setType(IconType value);

} // Icone
