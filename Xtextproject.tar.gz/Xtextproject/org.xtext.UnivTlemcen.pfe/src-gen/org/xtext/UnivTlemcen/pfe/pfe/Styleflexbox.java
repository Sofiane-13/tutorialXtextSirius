/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Styleflexbox</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getAlignItems3 <em>Align Items3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getAlignSelf3 <em>Align Self3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBorderBottomWidth3 <em>Border Bottom Width3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBorderLeftWidth3 <em>Border Left Width3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBorderRightWidth3 <em>Border Right Width3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBorderTopWidth3 <em>Border Top Width3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBorderWidth3 <em>Border Width3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBottom3 <em>Bottom3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getFlex3 <em>Flex3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getFlexDirection3 <em>Flex Direction3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getFlexWrap3 <em>Flex Wrap3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getHeight3 <em>Height3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getJustifyContent3 <em>Justify Content3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getLeft3 <em>Left3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMargin3 <em>Margin3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMarginBottom3 <em>Margin Bottom3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMarginLeft3 <em>Margin Left3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMarginRight3 <em>Margin Right3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMarginTop3 <em>Margin Top3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMarginVertical3 <em>Margin Vertical3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getPendding3 <em>Pendding3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getPanddingB <em>Pandding B</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox()
 * @model
 * @generated
 */
public interface Styleflexbox extends stylesheet
{
  /**
   * Returns the value of the '<em><b>Align Items3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.aliIT}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Align Items3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Align Items3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.aliIT
   * @see #setAlignItems3(aliIT)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_AlignItems3()
   * @model
   * @generated
   */
  aliIT getAlignItems3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getAlignItems3 <em>Align Items3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Align Items3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.aliIT
   * @see #getAlignItems3()
   * @generated
   */
  void setAlignItems3(aliIT value);

  /**
   * Returns the value of the '<em><b>Align Self3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.alfem}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Align Self3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Align Self3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.alfem
   * @see #setAlignSelf3(alfem)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_AlignSelf3()
   * @model
   * @generated
   */
  alfem getAlignSelf3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getAlignSelf3 <em>Align Self3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Align Self3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.alfem
   * @see #getAlignSelf3()
   * @generated
   */
  void setAlignSelf3(alfem value);

  /**
   * Returns the value of the '<em><b>Border Bottom Width3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Bottom Width3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Bottom Width3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderBottomWidth3(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_BorderBottomWidth3()
   * @model
   * @generated
   */
  entier getBorderBottomWidth3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBorderBottomWidth3 <em>Border Bottom Width3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Bottom Width3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderBottomWidth3()
   * @generated
   */
  void setBorderBottomWidth3(entier value);

  /**
   * Returns the value of the '<em><b>Border Left Width3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Left Width3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Left Width3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderLeftWidth3(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_BorderLeftWidth3()
   * @model
   * @generated
   */
  entier getBorderLeftWidth3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBorderLeftWidth3 <em>Border Left Width3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Left Width3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderLeftWidth3()
   * @generated
   */
  void setBorderLeftWidth3(entier value);

  /**
   * Returns the value of the '<em><b>Border Right Width3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Right Width3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Right Width3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderRightWidth3(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_BorderRightWidth3()
   * @model
   * @generated
   */
  entier getBorderRightWidth3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBorderRightWidth3 <em>Border Right Width3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Right Width3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderRightWidth3()
   * @generated
   */
  void setBorderRightWidth3(entier value);

  /**
   * Returns the value of the '<em><b>Border Top Width3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Top Width3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Top Width3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderTopWidth3(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_BorderTopWidth3()
   * @model
   * @generated
   */
  entier getBorderTopWidth3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBorderTopWidth3 <em>Border Top Width3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Top Width3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderTopWidth3()
   * @generated
   */
  void setBorderTopWidth3(entier value);

  /**
   * Returns the value of the '<em><b>Border Width3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Width3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Width3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderWidth3(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_BorderWidth3()
   * @model
   * @generated
   */
  entier getBorderWidth3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBorderWidth3 <em>Border Width3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Width3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderWidth3()
   * @generated
   */
  void setBorderWidth3(entier value);

  /**
   * Returns the value of the '<em><b>Bottom3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Bottom3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Bottom3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBottom3(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_Bottom3()
   * @model
   * @generated
   */
  entier getBottom3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBottom3 <em>Bottom3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Bottom3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBottom3()
   * @generated
   */
  void setBottom3(entier value);

  /**
   * Returns the value of the '<em><b>Flex3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Flex3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Flex3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setFlex3(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_Flex3()
   * @model
   * @generated
   */
  entier getFlex3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getFlex3 <em>Flex3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Flex3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getFlex3()
   * @generated
   */
  void setFlex3(entier value);

  /**
   * Returns the value of the '<em><b>Flex Direction3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.flexd}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Flex Direction3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Flex Direction3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.flexd
   * @see #setFlexDirection3(flexd)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_FlexDirection3()
   * @model
   * @generated
   */
  flexd getFlexDirection3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getFlexDirection3 <em>Flex Direction3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Flex Direction3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.flexd
   * @see #getFlexDirection3()
   * @generated
   */
  void setFlexDirection3(flexd value);

  /**
   * Returns the value of the '<em><b>Flex Wrap3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.One}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Flex Wrap3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Flex Wrap3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.One
   * @see #setFlexWrap3(One)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_FlexWrap3()
   * @model
   * @generated
   */
  One getFlexWrap3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getFlexWrap3 <em>Flex Wrap3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Flex Wrap3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.One
   * @see #getFlexWrap3()
   * @generated
   */
  void setFlexWrap3(One value);

  /**
   * Returns the value of the '<em><b>Height3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Height3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Height3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setHeight3(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_Height3()
   * @model
   * @generated
   */
  entier getHeight3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getHeight3 <em>Height3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Height3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getHeight3()
   * @generated
   */
  void setHeight3(entier value);

  /**
   * Returns the value of the '<em><b>Justify Content3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.JustifyContentType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Justify Content3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Justify Content3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.JustifyContentType
   * @see #setJustifyContent3(JustifyContentType)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_JustifyContent3()
   * @model
   * @generated
   */
  JustifyContentType getJustifyContent3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getJustifyContent3 <em>Justify Content3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Justify Content3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.JustifyContentType
   * @see #getJustifyContent3()
   * @generated
   */
  void setJustifyContent3(JustifyContentType value);

  /**
   * Returns the value of the '<em><b>Left3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Left3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Left3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setLeft3(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_Left3()
   * @model
   * @generated
   */
  entier getLeft3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getLeft3 <em>Left3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Left3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getLeft3()
   * @generated
   */
  void setLeft3(entier value);

  /**
   * Returns the value of the '<em><b>Margin3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Margin3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Margin3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setMargin3(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_Margin3()
   * @model
   * @generated
   */
  entier getMargin3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMargin3 <em>Margin3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Margin3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getMargin3()
   * @generated
   */
  void setMargin3(entier value);

  /**
   * Returns the value of the '<em><b>Margin Bottom3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Margin Bottom3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Margin Bottom3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setMarginBottom3(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_MarginBottom3()
   * @model
   * @generated
   */
  entier getMarginBottom3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMarginBottom3 <em>Margin Bottom3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Margin Bottom3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getMarginBottom3()
   * @generated
   */
  void setMarginBottom3(entier value);

  /**
   * Returns the value of the '<em><b>Margin Left3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Margin Left3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Margin Left3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setMarginLeft3(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_MarginLeft3()
   * @model
   * @generated
   */
  entier getMarginLeft3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMarginLeft3 <em>Margin Left3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Margin Left3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getMarginLeft3()
   * @generated
   */
  void setMarginLeft3(entier value);

  /**
   * Returns the value of the '<em><b>Margin Right3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Margin Right3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Margin Right3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setMarginRight3(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_MarginRight3()
   * @model
   * @generated
   */
  entier getMarginRight3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMarginRight3 <em>Margin Right3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Margin Right3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getMarginRight3()
   * @generated
   */
  void setMarginRight3(entier value);

  /**
   * Returns the value of the '<em><b>Margin Top3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Margin Top3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Margin Top3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setMarginTop3(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_MarginTop3()
   * @model
   * @generated
   */
  entier getMarginTop3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMarginTop3 <em>Margin Top3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Margin Top3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getMarginTop3()
   * @generated
   */
  void setMarginTop3(entier value);

  /**
   * Returns the value of the '<em><b>Margin Vertical3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Margin Vertical3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Margin Vertical3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setMarginVertical3(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_MarginVertical3()
   * @model
   * @generated
   */
  entier getMarginVertical3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMarginVertical3 <em>Margin Vertical3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Margin Vertical3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getMarginVertical3()
   * @generated
   */
  void setMarginVertical3(entier value);

  /**
   * Returns the value of the '<em><b>Pendding3</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Pendding3</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Pendding3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setPendding3(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_Pendding3()
   * @model
   * @generated
   */
  entier getPendding3();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getPendding3 <em>Pendding3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Pendding3</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getPendding3()
   * @generated
   */
  void setPendding3(entier value);

  /**
   * Returns the value of the '<em><b>Pandding B</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Pandding B</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Pandding B</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setPanddingB(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleflexbox_PanddingB()
   * @model
   * @generated
   */
  entier getPanddingB();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getPanddingB <em>Pandding B</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Pandding B</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getPanddingB()
   * @generated
   */
  void setPanddingB(entier value);

} // Styleflexbox
