/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>fonction</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getfonction()
 * @model
 * @generated
 */
public interface fonction extends Fonctions
{
} // fonction
