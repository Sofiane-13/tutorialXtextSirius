/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Model</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getModel()
 * @model
 * @generated
 */
public interface Model extends EObject
{
} // Model
