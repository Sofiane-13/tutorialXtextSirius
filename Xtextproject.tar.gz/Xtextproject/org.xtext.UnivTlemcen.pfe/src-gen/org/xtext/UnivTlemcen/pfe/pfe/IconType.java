/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Icon Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getIconType()
 * @model
 * @generated
 */
public enum IconType implements Enumerator
{
  /**
   * The '<em><b>Octicon</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #OCTICON_VALUE
   * @generated
   * @ordered
   */
  OCTICON(0, "octicon", "octicon"),

  /**
   * The '<em><b>Material</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #MATERIAL_VALUE
   * @generated
   * @ordered
   */
  MATERIAL(1, "material", "material"),

  /**
   * The '<em><b>Community</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #COMMUNITY_VALUE
   * @generated
   * @ordered
   */
  COMMUNITY(2, "community", "community"),

  /**
   * The '<em><b>Zocial</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #ZOCIAL_VALUE
   * @generated
   * @ordered
   */
  ZOCIAL(3, "zocial", "zocial"),

  /**
   * The '<em><b>Ionicon</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #IONICON_VALUE
   * @generated
   * @ordered
   */
  IONICON(4, "ionicon", "ionicon"),

  /**
   * The '<em><b>Foundation</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #FOUNDATION_VALUE
   * @generated
   * @ordered
   */
  FOUNDATION(5, "foundation", "foundation"),

  /**
   * The '<em><b>Evilicon</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #EVILICON_VALUE
   * @generated
   * @ordered
   */
  EVILICON(6, "evilicon", "evilicon"),

  /**
   * The '<em><b>Entypo</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #ENTYPO_VALUE
   * @generated
   * @ordered
   */
  ENTYPO(7, "entypo", "entypo"),

  /**
   * The '<em><b>None</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #NONE_VALUE
   * @generated
   * @ordered
   */
  NONE(8, "none", "none");

  /**
   * The '<em><b>Octicon</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Octicon</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #OCTICON
   * @model name="octicon"
   * @generated
   * @ordered
   */
  public static final int OCTICON_VALUE = 0;

  /**
   * The '<em><b>Material</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Material</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #MATERIAL
   * @model name="material"
   * @generated
   * @ordered
   */
  public static final int MATERIAL_VALUE = 1;

  /**
   * The '<em><b>Community</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Community</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #COMMUNITY
   * @model name="community"
   * @generated
   * @ordered
   */
  public static final int COMMUNITY_VALUE = 2;

  /**
   * The '<em><b>Zocial</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Zocial</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #ZOCIAL
   * @model name="zocial"
   * @generated
   * @ordered
   */
  public static final int ZOCIAL_VALUE = 3;

  /**
   * The '<em><b>Ionicon</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Ionicon</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #IONICON
   * @model name="ionicon"
   * @generated
   * @ordered
   */
  public static final int IONICON_VALUE = 4;

  /**
   * The '<em><b>Foundation</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Foundation</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #FOUNDATION
   * @model name="foundation"
   * @generated
   * @ordered
   */
  public static final int FOUNDATION_VALUE = 5;

  /**
   * The '<em><b>Evilicon</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Evilicon</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #EVILICON
   * @model name="evilicon"
   * @generated
   * @ordered
   */
  public static final int EVILICON_VALUE = 6;

  /**
   * The '<em><b>Entypo</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Entypo</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #ENTYPO
   * @model name="entypo"
   * @generated
   * @ordered
   */
  public static final int ENTYPO_VALUE = 7;

  /**
   * The '<em><b>None</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>None</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #NONE
   * @model name="none"
   * @generated
   * @ordered
   */
  public static final int NONE_VALUE = 8;

  /**
   * An array of all the '<em><b>Icon Type</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static final IconType[] VALUES_ARRAY =
    new IconType[]
    {
      OCTICON,
      MATERIAL,
      COMMUNITY,
      ZOCIAL,
      IONICON,
      FOUNDATION,
      EVILICON,
      ENTYPO,
      NONE,
    };

  /**
   * A public read-only list of all the '<em><b>Icon Type</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static final List<IconType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

  /**
   * Returns the '<em><b>Icon Type</b></em>' literal with the specified literal value.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static IconType get(String literal)
  {
    for (int i = 0; i < VALUES_ARRAY.length; ++i)
    {
      IconType result = VALUES_ARRAY[i];
      if (result.toString().equals(literal))
      {
        return result;
      }
    }
    return null;
  }

  /**
   * Returns the '<em><b>Icon Type</b></em>' literal with the specified name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static IconType getByName(String name)
  {
    for (int i = 0; i < VALUES_ARRAY.length; ++i)
    {
      IconType result = VALUES_ARRAY[i];
      if (result.getName().equals(name))
      {
        return result;
      }
    }
    return null;
  }

  /**
   * Returns the '<em><b>Icon Type</b></em>' literal with the specified integer value.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static IconType get(int value)
  {
    switch (value)
    {
      case OCTICON_VALUE: return OCTICON;
      case MATERIAL_VALUE: return MATERIAL;
      case COMMUNITY_VALUE: return COMMUNITY;
      case ZOCIAL_VALUE: return ZOCIAL;
      case IONICON_VALUE: return IONICON;
      case FOUNDATION_VALUE: return FOUNDATION;
      case EVILICON_VALUE: return EVILICON;
      case ENTYPO_VALUE: return ENTYPO;
      case NONE_VALUE: return NONE;
    }
    return null;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final int value;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final String name;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final String literal;

  /**
   * Only this class can construct instances.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private IconType(int value, String name, String literal)
  {
    this.value = value;
    this.name = name;
    this.literal = literal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public int getValue()
  {
    return value;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getLiteral()
  {
    return literal;
  }

  /**
   * Returns the literal value of the enumerator, which is its string representation.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    return literal;
  }
  
} //IconType
