/**
 */
package org.xtext.UnivTlemcen.pfe.pfe.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.xtext.UnivTlemcen.pfe.pfe.Audio;
import org.xtext.UnivTlemcen.pfe.pfe.LC;
import org.xtext.UnivTlemcen.pfe.pfe.PfePackage;
import org.xtext.UnivTlemcen.pfe.pfe.StyleView;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Audio</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.AudioImpl#getUrlT <em>Url T</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.AudioImpl#getTextbout <em>Textbout</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.AudioImpl#getLigneAudio <em>Ligne Audio</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.AudioImpl#getColoneAudio <em>Colone Audio</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.AudioImpl#getStyleAudio <em>Style Audio</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class AudioImpl extends composantImpl implements Audio
{
  /**
   * The default value of the '{@link #getUrlT() <em>Url T</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUrlT()
   * @generated
   * @ordered
   */
  protected static final String URL_T_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getUrlT() <em>Url T</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUrlT()
   * @generated
   * @ordered
   */
  protected String urlT = URL_T_EDEFAULT;

  /**
   * The default value of the '{@link #getTextbout() <em>Textbout</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTextbout()
   * @generated
   * @ordered
   */
  protected static final String TEXTBOUT_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getTextbout() <em>Textbout</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTextbout()
   * @generated
   * @ordered
   */
  protected String textbout = TEXTBOUT_EDEFAULT;

  /**
   * The default value of the '{@link #getLigneAudio() <em>Ligne Audio</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLigneAudio()
   * @generated
   * @ordered
   */
  protected static final LC LIGNE_AUDIO_EDEFAULT = LC.UN;

  /**
   * The cached value of the '{@link #getLigneAudio() <em>Ligne Audio</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLigneAudio()
   * @generated
   * @ordered
   */
  protected LC ligneAudio = LIGNE_AUDIO_EDEFAULT;

  /**
   * The default value of the '{@link #getColoneAudio() <em>Colone Audio</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getColoneAudio()
   * @generated
   * @ordered
   */
  protected static final LC COLONE_AUDIO_EDEFAULT = LC.UN;

  /**
   * The cached value of the '{@link #getColoneAudio() <em>Colone Audio</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getColoneAudio()
   * @generated
   * @ordered
   */
  protected LC coloneAudio = COLONE_AUDIO_EDEFAULT;

  /**
   * The cached value of the '{@link #getStyleAudio() <em>Style Audio</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getStyleAudio()
   * @generated
   * @ordered
   */
  protected StyleView styleAudio;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected AudioImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return PfePackage.Literals.AUDIO;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getUrlT()
  {
    return urlT;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setUrlT(String newUrlT)
  {
    String oldUrlT = urlT;
    urlT = newUrlT;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.AUDIO__URL_T, oldUrlT, urlT));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getTextbout()
  {
    return textbout;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTextbout(String newTextbout)
  {
    String oldTextbout = textbout;
    textbout = newTextbout;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.AUDIO__TEXTBOUT, oldTextbout, textbout));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LC getLigneAudio()
  {
    return ligneAudio;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLigneAudio(LC newLigneAudio)
  {
    LC oldLigneAudio = ligneAudio;
    ligneAudio = newLigneAudio == null ? LIGNE_AUDIO_EDEFAULT : newLigneAudio;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.AUDIO__LIGNE_AUDIO, oldLigneAudio, ligneAudio));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LC getColoneAudio()
  {
    return coloneAudio;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setColoneAudio(LC newColoneAudio)
  {
    LC oldColoneAudio = coloneAudio;
    coloneAudio = newColoneAudio == null ? COLONE_AUDIO_EDEFAULT : newColoneAudio;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.AUDIO__COLONE_AUDIO, oldColoneAudio, coloneAudio));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public StyleView getStyleAudio()
  {
    if (styleAudio != null && styleAudio.eIsProxy())
    {
      InternalEObject oldStyleAudio = (InternalEObject)styleAudio;
      styleAudio = (StyleView)eResolveProxy(oldStyleAudio);
      if (styleAudio != oldStyleAudio)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, PfePackage.AUDIO__STYLE_AUDIO, oldStyleAudio, styleAudio));
      }
    }
    return styleAudio;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public StyleView basicGetStyleAudio()
  {
    return styleAudio;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setStyleAudio(StyleView newStyleAudio)
  {
    StyleView oldStyleAudio = styleAudio;
    styleAudio = newStyleAudio;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.AUDIO__STYLE_AUDIO, oldStyleAudio, styleAudio));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case PfePackage.AUDIO__URL_T:
        return getUrlT();
      case PfePackage.AUDIO__TEXTBOUT:
        return getTextbout();
      case PfePackage.AUDIO__LIGNE_AUDIO:
        return getLigneAudio();
      case PfePackage.AUDIO__COLONE_AUDIO:
        return getColoneAudio();
      case PfePackage.AUDIO__STYLE_AUDIO:
        if (resolve) return getStyleAudio();
        return basicGetStyleAudio();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case PfePackage.AUDIO__URL_T:
        setUrlT((String)newValue);
        return;
      case PfePackage.AUDIO__TEXTBOUT:
        setTextbout((String)newValue);
        return;
      case PfePackage.AUDIO__LIGNE_AUDIO:
        setLigneAudio((LC)newValue);
        return;
      case PfePackage.AUDIO__COLONE_AUDIO:
        setColoneAudio((LC)newValue);
        return;
      case PfePackage.AUDIO__STYLE_AUDIO:
        setStyleAudio((StyleView)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.AUDIO__URL_T:
        setUrlT(URL_T_EDEFAULT);
        return;
      case PfePackage.AUDIO__TEXTBOUT:
        setTextbout(TEXTBOUT_EDEFAULT);
        return;
      case PfePackage.AUDIO__LIGNE_AUDIO:
        setLigneAudio(LIGNE_AUDIO_EDEFAULT);
        return;
      case PfePackage.AUDIO__COLONE_AUDIO:
        setColoneAudio(COLONE_AUDIO_EDEFAULT);
        return;
      case PfePackage.AUDIO__STYLE_AUDIO:
        setStyleAudio((StyleView)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.AUDIO__URL_T:
        return URL_T_EDEFAULT == null ? urlT != null : !URL_T_EDEFAULT.equals(urlT);
      case PfePackage.AUDIO__TEXTBOUT:
        return TEXTBOUT_EDEFAULT == null ? textbout != null : !TEXTBOUT_EDEFAULT.equals(textbout);
      case PfePackage.AUDIO__LIGNE_AUDIO:
        return ligneAudio != LIGNE_AUDIO_EDEFAULT;
      case PfePackage.AUDIO__COLONE_AUDIO:
        return coloneAudio != COLONE_AUDIO_EDEFAULT;
      case PfePackage.AUDIO__STYLE_AUDIO:
        return styleAudio != null;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (urlT: ");
    result.append(urlT);
    result.append(", Textbout: ");
    result.append(textbout);
    result.append(", ligneAudio: ");
    result.append(ligneAudio);
    result.append(", coloneAudio: ");
    result.append(coloneAudio);
    result.append(')');
    return result.toString();
  }

} //AudioImpl
