/**
 */
package org.xtext.UnivTlemcen.pfe.pfe.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.UnivTlemcen.pfe.pfe.Elements;
import org.xtext.UnivTlemcen.pfe.pfe.PfePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Elements</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class ElementsImpl extends VueImpl implements Elements
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ElementsImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return PfePackage.Literals.ELEMENTS;
  }

} //ElementsImpl
