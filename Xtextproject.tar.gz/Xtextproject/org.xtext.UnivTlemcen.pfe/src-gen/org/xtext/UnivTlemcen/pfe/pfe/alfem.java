/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>alfem</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getalfem()
 * @model
 * @generated
 */
public enum alfem implements Enumerator
{
  /**
   * The '<em><b>None</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #NONE_VALUE
   * @generated
   * @ordered
   */
  NONE(0, "none", "none"),

  /**
   * The '<em><b>Aut</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #AUT_VALUE
   * @generated
   * @ordered
   */
  AUT(1, "aut", "auto"),

  /**
   * The '<em><b>Flex2</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #FLEX2_VALUE
   * @generated
   * @ordered
   */
  FLEX2(2, "flex2", "flex-start"),

  /**
   * The '<em><b>Flex3</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #FLEX3_VALUE
   * @generated
   * @ordered
   */
  FLEX3(3, "flex3", "flex-end"),

  /**
   * The '<em><b>Cnn</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #CNN_VALUE
   * @generated
   * @ordered
   */
  CNN(4, "cnn", "center"),

  /**
   * The '<em><b>Sch</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #SCH_VALUE
   * @generated
   * @ordered
   */
  SCH(5, "sch", "stretch");

  /**
   * The '<em><b>None</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>None</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #NONE
   * @model name="none"
   * @generated
   * @ordered
   */
  public static final int NONE_VALUE = 0;

  /**
   * The '<em><b>Aut</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Aut</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #AUT
   * @model name="aut" literal="auto"
   * @generated
   * @ordered
   */
  public static final int AUT_VALUE = 1;

  /**
   * The '<em><b>Flex2</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Flex2</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #FLEX2
   * @model name="flex2" literal="flex-start"
   * @generated
   * @ordered
   */
  public static final int FLEX2_VALUE = 2;

  /**
   * The '<em><b>Flex3</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Flex3</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #FLEX3
   * @model name="flex3" literal="flex-end"
   * @generated
   * @ordered
   */
  public static final int FLEX3_VALUE = 3;

  /**
   * The '<em><b>Cnn</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Cnn</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #CNN
   * @model name="cnn" literal="center"
   * @generated
   * @ordered
   */
  public static final int CNN_VALUE = 4;

  /**
   * The '<em><b>Sch</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Sch</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #SCH
   * @model name="sch" literal="stretch"
   * @generated
   * @ordered
   */
  public static final int SCH_VALUE = 5;

  /**
   * An array of all the '<em><b>alfem</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static final alfem[] VALUES_ARRAY =
    new alfem[]
    {
      NONE,
      AUT,
      FLEX2,
      FLEX3,
      CNN,
      SCH,
    };

  /**
   * A public read-only list of all the '<em><b>alfem</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static final List<alfem> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

  /**
   * Returns the '<em><b>alfem</b></em>' literal with the specified literal value.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static alfem get(String literal)
  {
    for (int i = 0; i < VALUES_ARRAY.length; ++i)
    {
      alfem result = VALUES_ARRAY[i];
      if (result.toString().equals(literal))
      {
        return result;
      }
    }
    return null;
  }

  /**
   * Returns the '<em><b>alfem</b></em>' literal with the specified name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static alfem getByName(String name)
  {
    for (int i = 0; i < VALUES_ARRAY.length; ++i)
    {
      alfem result = VALUES_ARRAY[i];
      if (result.getName().equals(name))
      {
        return result;
      }
    }
    return null;
  }

  /**
   * Returns the '<em><b>alfem</b></em>' literal with the specified integer value.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static alfem get(int value)
  {
    switch (value)
    {
      case NONE_VALUE: return NONE;
      case AUT_VALUE: return AUT;
      case FLEX2_VALUE: return FLEX2;
      case FLEX3_VALUE: return FLEX3;
      case CNN_VALUE: return CNN;
      case SCH_VALUE: return SCH;
    }
    return null;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final int value;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final String name;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final String literal;

  /**
   * Only this class can construct instances.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private alfem(int value, String name, String literal)
  {
    this.value = value;
    this.name = name;
    this.literal = literal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public int getValue()
  {
    return value;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getLiteral()
  {
    return literal;
  }

  /**
   * Returns the literal value of the enumerator, which is its string representation.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    return literal;
  }
  
} //alfem
