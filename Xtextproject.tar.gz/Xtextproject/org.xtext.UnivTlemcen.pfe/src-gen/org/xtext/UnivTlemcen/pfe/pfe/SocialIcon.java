/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Social Icon</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.SocialIcon#getType <em>Type</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.SocialIcon#getButton <em>Button</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.SocialIcon#getRaised <em>Raised</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.SocialIcon#getOnclique <em>Onclique</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.SocialIcon#getOnlongclique <em>Onlongclique</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getSocialIcon()
 * @model
 * @generated
 */
public interface SocialIcon extends Icons
{
  /**
   * Returns the value of the '<em><b>Type</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.SocialIconType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Type</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Type</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.SocialIconType
   * @see #setType(SocialIconType)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getSocialIcon_Type()
   * @model
   * @generated
   */
  SocialIconType getType();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.SocialIcon#getType <em>Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Type</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.SocialIconType
   * @see #getType()
   * @generated
   */
  void setType(SocialIconType value);

  /**
   * Returns the value of the '<em><b>Button</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.buttonType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Button</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Button</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.buttonType
   * @see #setButton(buttonType)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getSocialIcon_Button()
   * @model
   * @generated
   */
  buttonType getButton();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.SocialIcon#getButton <em>Button</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Button</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.buttonType
   * @see #getButton()
   * @generated
   */
  void setButton(buttonType value);

  /**
   * Returns the value of the '<em><b>Raised</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.raisedType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Raised</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Raised</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.raisedType
   * @see #setRaised(raisedType)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getSocialIcon_Raised()
   * @model
   * @generated
   */
  raisedType getRaised();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.SocialIcon#getRaised <em>Raised</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Raised</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.raisedType
   * @see #getRaised()
   * @generated
   */
  void setRaised(raisedType value);

  /**
   * Returns the value of the '<em><b>Onclique</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Onclique</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Onclique</em>' reference.
   * @see #setOnclique(fonction)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getSocialIcon_Onclique()
   * @model
   * @generated
   */
  fonction getOnclique();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.SocialIcon#getOnclique <em>Onclique</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Onclique</em>' reference.
   * @see #getOnclique()
   * @generated
   */
  void setOnclique(fonction value);

  /**
   * Returns the value of the '<em><b>Onlongclique</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Onlongclique</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Onlongclique</em>' reference.
   * @see #setOnlongclique(fonction)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getSocialIcon_Onlongclique()
   * @model
   * @generated
   */
  fonction getOnlongclique();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.SocialIcon#getOnlongclique <em>Onlongclique</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Onlongclique</em>' reference.
   * @see #getOnlongclique()
   * @generated
   */
  void setOnlongclique(fonction value);

} // SocialIcon
