/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Video</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Video#getUrlV <em>Url V</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Video#getMutte <em>Mutte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Video#getWidtht <em>Widtht</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Video#getHeightr <em>Heightr</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Video#getLigneAudio <em>Ligne Audio</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Video#getColoneAudio <em>Colone Audio</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getVideo()
 * @model
 * @generated
 */
public interface Video extends composant
{
  /**
   * Returns the value of the '<em><b>Url V</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Url V</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Url V</em>' attribute.
   * @see #setUrlV(String)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getVideo_UrlV()
   * @model
   * @generated
   */
  String getUrlV();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Video#getUrlV <em>Url V</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Url V</em>' attribute.
   * @see #getUrlV()
   * @generated
   */
  void setUrlV(String value);

  /**
   * Returns the value of the '<em><b>Mutte</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.mut}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Mutte</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Mutte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.mut
   * @see #setMutte(mut)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getVideo_Mutte()
   * @model
   * @generated
   */
  mut getMutte();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Video#getMutte <em>Mutte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Mutte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.mut
   * @see #getMutte()
   * @generated
   */
  void setMutte(mut value);

  /**
   * Returns the value of the '<em><b>Widtht</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Widtht</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Widtht</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setWidtht(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getVideo_Widtht()
   * @model
   * @generated
   */
  entier getWidtht();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Video#getWidtht <em>Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Widtht</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getWidtht()
   * @generated
   */
  void setWidtht(entier value);

  /**
   * Returns the value of the '<em><b>Heightr</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Heightr</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Heightr</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setHeightr(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getVideo_Heightr()
   * @model
   * @generated
   */
  entier getHeightr();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Video#getHeightr <em>Heightr</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Heightr</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getHeightr()
   * @generated
   */
  void setHeightr(entier value);

  /**
   * Returns the value of the '<em><b>Ligne Audio</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.LC}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Ligne Audio</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Ligne Audio</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #setLigneAudio(LC)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getVideo_LigneAudio()
   * @model
   * @generated
   */
  LC getLigneAudio();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Video#getLigneAudio <em>Ligne Audio</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Ligne Audio</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #getLigneAudio()
   * @generated
   */
  void setLigneAudio(LC value);

  /**
   * Returns the value of the '<em><b>Colone Audio</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.LC}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Colone Audio</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Colone Audio</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #setColoneAudio(LC)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getVideo_ColoneAudio()
   * @model
   * @generated
   */
  LC getColoneAudio();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Video#getColoneAudio <em>Colone Audio</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Colone Audio</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #getColoneAudio()
   * @generated
   */
  void setColoneAudio(LC value);

} // Video
