/**
 */
package org.xtext.UnivTlemcen.pfe.pfe.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.xtext.UnivTlemcen.pfe.pfe.LC;
import org.xtext.UnivTlemcen.pfe.pfe.PfePackage;
import org.xtext.UnivTlemcen.pfe.pfe.Video;
import org.xtext.UnivTlemcen.pfe.pfe.entier;
import org.xtext.UnivTlemcen.pfe.pfe.mut;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Video</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.VideoImpl#getUrlV <em>Url V</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.VideoImpl#getMutte <em>Mutte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.VideoImpl#getWidtht <em>Widtht</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.VideoImpl#getHeightr <em>Heightr</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.VideoImpl#getLigneAudio <em>Ligne Audio</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.VideoImpl#getColoneAudio <em>Colone Audio</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class VideoImpl extends composantImpl implements Video
{
  /**
   * The default value of the '{@link #getUrlV() <em>Url V</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUrlV()
   * @generated
   * @ordered
   */
  protected static final String URL_V_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getUrlV() <em>Url V</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUrlV()
   * @generated
   * @ordered
   */
  protected String urlV = URL_V_EDEFAULT;

  /**
   * The default value of the '{@link #getMutte() <em>Mutte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMutte()
   * @generated
   * @ordered
   */
  protected static final mut MUTTE_EDEFAULT = mut.FALSE;

  /**
   * The cached value of the '{@link #getMutte() <em>Mutte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMutte()
   * @generated
   * @ordered
   */
  protected mut mutte = MUTTE_EDEFAULT;

  /**
   * The default value of the '{@link #getWidtht() <em>Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getWidtht()
   * @generated
   * @ordered
   */
  protected static final entier WIDTHT_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getWidtht() <em>Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getWidtht()
   * @generated
   * @ordered
   */
  protected entier widtht = WIDTHT_EDEFAULT;

  /**
   * The default value of the '{@link #getHeightr() <em>Heightr</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHeightr()
   * @generated
   * @ordered
   */
  protected static final entier HEIGHTR_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getHeightr() <em>Heightr</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHeightr()
   * @generated
   * @ordered
   */
  protected entier heightr = HEIGHTR_EDEFAULT;

  /**
   * The default value of the '{@link #getLigneAudio() <em>Ligne Audio</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLigneAudio()
   * @generated
   * @ordered
   */
  protected static final LC LIGNE_AUDIO_EDEFAULT = LC.UN;

  /**
   * The cached value of the '{@link #getLigneAudio() <em>Ligne Audio</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLigneAudio()
   * @generated
   * @ordered
   */
  protected LC ligneAudio = LIGNE_AUDIO_EDEFAULT;

  /**
   * The default value of the '{@link #getColoneAudio() <em>Colone Audio</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getColoneAudio()
   * @generated
   * @ordered
   */
  protected static final LC COLONE_AUDIO_EDEFAULT = LC.UN;

  /**
   * The cached value of the '{@link #getColoneAudio() <em>Colone Audio</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getColoneAudio()
   * @generated
   * @ordered
   */
  protected LC coloneAudio = COLONE_AUDIO_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected VideoImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return PfePackage.Literals.VIDEO;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getUrlV()
  {
    return urlV;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setUrlV(String newUrlV)
  {
    String oldUrlV = urlV;
    urlV = newUrlV;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.VIDEO__URL_V, oldUrlV, urlV));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public mut getMutte()
  {
    return mutte;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMutte(mut newMutte)
  {
    mut oldMutte = mutte;
    mutte = newMutte == null ? MUTTE_EDEFAULT : newMutte;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.VIDEO__MUTTE, oldMutte, mutte));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getWidtht()
  {
    return widtht;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setWidtht(entier newWidtht)
  {
    entier oldWidtht = widtht;
    widtht = newWidtht == null ? WIDTHT_EDEFAULT : newWidtht;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.VIDEO__WIDTHT, oldWidtht, widtht));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getHeightr()
  {
    return heightr;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setHeightr(entier newHeightr)
  {
    entier oldHeightr = heightr;
    heightr = newHeightr == null ? HEIGHTR_EDEFAULT : newHeightr;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.VIDEO__HEIGHTR, oldHeightr, heightr));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LC getLigneAudio()
  {
    return ligneAudio;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLigneAudio(LC newLigneAudio)
  {
    LC oldLigneAudio = ligneAudio;
    ligneAudio = newLigneAudio == null ? LIGNE_AUDIO_EDEFAULT : newLigneAudio;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.VIDEO__LIGNE_AUDIO, oldLigneAudio, ligneAudio));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LC getColoneAudio()
  {
    return coloneAudio;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setColoneAudio(LC newColoneAudio)
  {
    LC oldColoneAudio = coloneAudio;
    coloneAudio = newColoneAudio == null ? COLONE_AUDIO_EDEFAULT : newColoneAudio;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.VIDEO__COLONE_AUDIO, oldColoneAudio, coloneAudio));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case PfePackage.VIDEO__URL_V:
        return getUrlV();
      case PfePackage.VIDEO__MUTTE:
        return getMutte();
      case PfePackage.VIDEO__WIDTHT:
        return getWidtht();
      case PfePackage.VIDEO__HEIGHTR:
        return getHeightr();
      case PfePackage.VIDEO__LIGNE_AUDIO:
        return getLigneAudio();
      case PfePackage.VIDEO__COLONE_AUDIO:
        return getColoneAudio();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case PfePackage.VIDEO__URL_V:
        setUrlV((String)newValue);
        return;
      case PfePackage.VIDEO__MUTTE:
        setMutte((mut)newValue);
        return;
      case PfePackage.VIDEO__WIDTHT:
        setWidtht((entier)newValue);
        return;
      case PfePackage.VIDEO__HEIGHTR:
        setHeightr((entier)newValue);
        return;
      case PfePackage.VIDEO__LIGNE_AUDIO:
        setLigneAudio((LC)newValue);
        return;
      case PfePackage.VIDEO__COLONE_AUDIO:
        setColoneAudio((LC)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.VIDEO__URL_V:
        setUrlV(URL_V_EDEFAULT);
        return;
      case PfePackage.VIDEO__MUTTE:
        setMutte(MUTTE_EDEFAULT);
        return;
      case PfePackage.VIDEO__WIDTHT:
        setWidtht(WIDTHT_EDEFAULT);
        return;
      case PfePackage.VIDEO__HEIGHTR:
        setHeightr(HEIGHTR_EDEFAULT);
        return;
      case PfePackage.VIDEO__LIGNE_AUDIO:
        setLigneAudio(LIGNE_AUDIO_EDEFAULT);
        return;
      case PfePackage.VIDEO__COLONE_AUDIO:
        setColoneAudio(COLONE_AUDIO_EDEFAULT);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.VIDEO__URL_V:
        return URL_V_EDEFAULT == null ? urlV != null : !URL_V_EDEFAULT.equals(urlV);
      case PfePackage.VIDEO__MUTTE:
        return mutte != MUTTE_EDEFAULT;
      case PfePackage.VIDEO__WIDTHT:
        return widtht != WIDTHT_EDEFAULT;
      case PfePackage.VIDEO__HEIGHTR:
        return heightr != HEIGHTR_EDEFAULT;
      case PfePackage.VIDEO__LIGNE_AUDIO:
        return ligneAudio != LIGNE_AUDIO_EDEFAULT;
      case PfePackage.VIDEO__COLONE_AUDIO:
        return coloneAudio != COLONE_AUDIO_EDEFAULT;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (urlV: ");
    result.append(urlV);
    result.append(", mutte: ");
    result.append(mutte);
    result.append(", widtht: ");
    result.append(widtht);
    result.append(", heightr: ");
    result.append(heightr);
    result.append(", ligneAudio: ");
    result.append(ligneAudio);
    result.append(", coloneAudio: ");
    result.append(coloneAudio);
    result.append(')');
    return result.toString();
  }

} //VideoImpl
