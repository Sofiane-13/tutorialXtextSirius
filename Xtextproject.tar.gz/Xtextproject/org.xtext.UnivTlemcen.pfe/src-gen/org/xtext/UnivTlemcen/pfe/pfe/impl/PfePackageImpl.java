/**
 */
package org.xtext.UnivTlemcen.pfe.pfe.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.xtext.UnivTlemcen.pfe.pfe.AlerteFonction;
import org.xtext.UnivTlemcen.pfe.pfe.Application;
import org.xtext.UnivTlemcen.pfe.pfe.Audio;
import org.xtext.UnivTlemcen.pfe.pfe.Backnum;
import org.xtext.UnivTlemcen.pfe.pfe.Bouton;
import org.xtext.UnivTlemcen.pfe.pfe.CheckBox;
import org.xtext.UnivTlemcen.pfe.pfe.Colors;
import org.xtext.UnivTlemcen.pfe.pfe.ContainerFonctions;
import org.xtext.UnivTlemcen.pfe.pfe.ContainerStyle;
import org.xtext.UnivTlemcen.pfe.pfe.Controleur;
import org.xtext.UnivTlemcen.pfe.pfe.Eignth;
import org.xtext.UnivTlemcen.pfe.pfe.Elements;
import org.xtext.UnivTlemcen.pfe.pfe.Fonctions;
import org.xtext.UnivTlemcen.pfe.pfe.Foor;
import org.xtext.UnivTlemcen.pfe.pfe.Forms;
import org.xtext.UnivTlemcen.pfe.pfe.Heading;
import org.xtext.UnivTlemcen.pfe.pfe.IconRightType;
import org.xtext.UnivTlemcen.pfe.pfe.IconType;
import org.xtext.UnivTlemcen.pfe.pfe.Icone;
import org.xtext.UnivTlemcen.pfe.pfe.Icons;
import org.xtext.UnivTlemcen.pfe.pfe.Image;
import org.xtext.UnivTlemcen.pfe.pfe.Input;
import org.xtext.UnivTlemcen.pfe.pfe.JustifyContentType;
import org.xtext.UnivTlemcen.pfe.pfe.Layout;
import org.xtext.UnivTlemcen.pfe.pfe.MapView;
import org.xtext.UnivTlemcen.pfe.pfe.Model;
import org.xtext.UnivTlemcen.pfe.pfe.Navigate;
import org.xtext.UnivTlemcen.pfe.pfe.Nine;
import org.xtext.UnivTlemcen.pfe.pfe.One;
import org.xtext.UnivTlemcen.pfe.pfe.PfeFactory;
import org.xtext.UnivTlemcen.pfe.pfe.PfePackage;
import org.xtext.UnivTlemcen.pfe.pfe.PropType;
import org.xtext.UnivTlemcen.pfe.pfe.RadioButton;
import org.xtext.UnivTlemcen.pfe.pfe.RemplirTable;
import org.xtext.UnivTlemcen.pfe.pfe.SocialIcon;
import org.xtext.UnivTlemcen.pfe.pfe.SocialIconType;
import org.xtext.UnivTlemcen.pfe.pfe.StyleImage;
import org.xtext.UnivTlemcen.pfe.pfe.StyleText;
import org.xtext.UnivTlemcen.pfe.pfe.StyleView;
import org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox;
import org.xtext.UnivTlemcen.pfe.pfe.Tab;
import org.xtext.UnivTlemcen.pfe.pfe.TableDefinition;
import org.xtext.UnivTlemcen.pfe.pfe.Text;
import org.xtext.UnivTlemcen.pfe.pfe.Three;
import org.xtext.UnivTlemcen.pfe.pfe.TypeH;
import org.xtext.UnivTlemcen.pfe.pfe.Video;
import org.xtext.UnivTlemcen.pfe.pfe.Vue;
import org.xtext.UnivTlemcen.pfe.pfe.alfem;
import org.xtext.UnivTlemcen.pfe.pfe.aliIT;
import org.xtext.UnivTlemcen.pfe.pfe.bordersty;
import org.xtext.UnivTlemcen.pfe.pfe.buttonType;
import org.xtext.UnivTlemcen.pfe.pfe.composant;
import org.xtext.UnivTlemcen.pfe.pfe.entier;
import org.xtext.UnivTlemcen.pfe.pfe.flexd;
import org.xtext.UnivTlemcen.pfe.pfe.fonction;
import org.xtext.UnivTlemcen.pfe.pfe.listView;
import org.xtext.UnivTlemcen.pfe.pfe.lists;
import org.xtext.UnivTlemcen.pfe.pfe.mut;
import org.xtext.UnivTlemcen.pfe.pfe.raisedType;
import org.xtext.UnivTlemcen.pfe.pfe.sizelist;
import org.xtext.UnivTlemcen.pfe.pfe.stylesheet;
import org.xtext.UnivTlemcen.pfe.pfe.textType;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class PfePackageImpl extends EPackageImpl implements PfePackage
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass applicationEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass controleurEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass fonctionsEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass stylesheetEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass fonctionEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass styleTextEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass styleViewEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass styleImageEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass styleflexboxEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass remplirTableEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass alerteFonctionEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass navigateEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass vueEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass elementsEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass composantEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass formsEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass listsEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass iconsEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass listViewEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass radioButtonEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass checkBoxEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass textEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass inputEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass iconeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass socialIconEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass tabEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass headingEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass containerStyleEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass containerFonctionsEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass layoutEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass boutonEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass videoEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass audioEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass mapViewEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass imageEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass modelEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass tableDefinitionEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum oneEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum nineEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum eignthEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum threeEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum foorEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum colorsEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum aliITEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum alfemEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum borderstyEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum textTypeEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum backnumEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum typeHEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum iconTypeEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum sizelistEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum socialIconTypeEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum flexdEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum mutEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum buttonTypeEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum raisedTypeEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum propTypeEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum iconRightTypeEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum justifyContentTypeEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum entierEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum lcEEnum = null;

  /**
   * Creates an instance of the model <b>Package</b>, registered with
   * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
   * package URI value.
   * <p>Note: the correct way to create the package is via the static
   * factory method {@link #init init()}, which also performs
   * initialization of the package, or returns the registered package,
   * if one already exists.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.eclipse.emf.ecore.EPackage.Registry
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#eNS_URI
   * @see #init()
   * @generated
   */
  private PfePackageImpl()
  {
    super(eNS_URI, PfeFactory.eINSTANCE);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static boolean isInited = false;

  /**
   * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
   * 
   * <p>This method is used to initialize {@link PfePackage#eINSTANCE} when that field is accessed.
   * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #eNS_URI
   * @see #createPackageContents()
   * @see #initializePackageContents()
   * @generated
   */
  public static PfePackage init()
  {
    if (isInited) return (PfePackage)EPackage.Registry.INSTANCE.getEPackage(PfePackage.eNS_URI);

    // Obtain or create and register package
    PfePackageImpl thePfePackage = (PfePackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof PfePackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new PfePackageImpl());

    isInited = true;

    // Create package meta-data objects
    thePfePackage.createPackageContents();

    // Initialize created meta-data
    thePfePackage.initializePackageContents();

    // Mark meta-data to indicate it can't be changed
    thePfePackage.freeze();

  
    // Update the registry and return the package
    EPackage.Registry.INSTANCE.put(PfePackage.eNS_URI, thePfePackage);
    return thePfePackage;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getApplication()
  {
    return applicationEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getApplication_Name()
  {
    return (EAttribute)applicationEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getApplication_PackageName()
  {
    return (EAttribute)applicationEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getApplication_FirstLayout()
  {
    return (EReference)applicationEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getApplication_Model()
  {
    return (EReference)applicationEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getApplication_Vue()
  {
    return (EReference)applicationEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getApplication_Controleur()
  {
    return (EReference)applicationEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getControleur()
  {
    return controleurEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getFonctions()
  {
    return fonctionsEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getFonctions_Name()
  {
    return (EAttribute)fonctionsEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getstylesheet()
  {
    return stylesheetEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getfonction()
  {
    return fonctionEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getStyleText()
  {
    return styleTextEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_Colore()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_FontFamilyE()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_FontSizes()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_FontStyles()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_FontWeighte()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_LineHeighte()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_TextAligne()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_BackfaceVisibilitye()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_BackgroundColore()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_BorderBottomColore()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_BorderBottomLeftRadiuse()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(10);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_BorderBottomRightRadiuse()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(11);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_BorderBottomWidthe()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(12);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_BorderColore()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(13);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_BorderLeftColore()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(14);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_BorderLeftWidthe()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(15);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_BorderRadiuse()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(16);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_BorderRightColore()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(17);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_BorderRightWidth()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(18);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_BorderStyles()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(19);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_BorderTopColore()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(20);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_BorderTopLeftRadiuse()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(21);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_BorderTopRightRadiuse()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(22);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_BorderTopWidthe()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(23);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_BorderWidthe()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(24);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleText_Opacitye()
  {
    return (EAttribute)styleTextEClass.getEStructuralFeatures().get(25);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getStyleView()
  {
    return styleViewEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_BackfaceVisibility2()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_BackgroundColor2()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_BorderBottomColor2()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_BorderBottomLeftRadius2()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_BorderBottomRightRadius2()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_BorderBottomWidth2()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_BorderColort()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_BorderLeftColort()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_BorderLeftWidtht()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_BorderRadiust()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_BorderRightColort()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(10);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_BorderRightWidtht()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(11);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_BorderStylet()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(12);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_BorderTopColort()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(13);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_BorderTopLeftRadiust()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(14);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_BorderTopRightRadiust()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(15);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_BorderTopWidtht()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(16);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_BorderWidtht()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(17);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_Opacityt()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(18);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_AlignItemst()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(19);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_AlignSelft()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(20);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_Bottomt()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(21);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_Flext()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(22);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_FlexDirectiont()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(23);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_FlexWrapt()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(24);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_Heighte()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(25);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_JustifyContente()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(26);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_Lefte()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(27);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_Margin()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(28);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_MarginBottome()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(29);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_MarginLefte()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(30);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_MarginRighte()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(31);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_MarginTope()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(32);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_MarginVerticale()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(33);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_Paddingt()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(34);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_PaddingBottomt()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(35);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_PaddingHorizontale()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(36);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_PaddingRighte()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(37);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_PaddingTope()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(38);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_PaddingVerticale()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(39);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_Rightt()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(40);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleView_Widtht()
  {
    return (EAttribute)styleViewEClass.getEStructuralFeatures().get(41);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getStyleImage()
  {
    return styleImageEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_BackfaceVisibility()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_BackgroundColora()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_BorderBottomLeftRadiusa()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_BorderBottomRightRadiusa()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_BorderColora()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_BorderRadiusa()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_BorderTopLeftRadiusa()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_BorderTopRightRadiusa()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_BorderWidtha()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_Opacitya()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_Overflowa()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(10);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_AlignItemst()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(11);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_AlignSelft()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(12);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_Bottomt()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(13);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_Flext()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(14);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_JustifyContente()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(15);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_Lefte()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(16);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_Margin()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(17);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_MarginBottome()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(18);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_MarginLefte()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(19);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_MarginRighte()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(20);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_MarginTope()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(21);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_MarginVerticale()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(22);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_Paddingt()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(23);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_PaddingBottomt()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(24);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_PaddingHorizontale()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(25);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_PaddingRighte()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(26);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_PaddingTope()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(27);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_PaddingVerticale()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(28);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_Rightt()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(29);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_Widtht()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(30);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_FlexDirectiont()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(31);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_FlexWrapt()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(32);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleImage_Heighte()
  {
    return (EAttribute)styleImageEClass.getEStructuralFeatures().get(33);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getStyleflexbox()
  {
    return styleflexboxEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_AlignItems3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_AlignSelf3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_BorderBottomWidth3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_BorderLeftWidth3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_BorderRightWidth3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_BorderTopWidth3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_BorderWidth3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_Bottom3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_Flex3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_FlexDirection3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_FlexWrap3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(10);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_Height3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(11);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_JustifyContent3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(12);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_Left3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(13);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_Margin3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(14);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_MarginBottom3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(15);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_MarginLeft3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(16);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_MarginRight3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(17);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_MarginTop3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(18);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_MarginVertical3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(19);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_Pendding3()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(20);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getStyleflexbox_PanddingB()
  {
    return (EAttribute)styleflexboxEClass.getEStructuralFeatures().get(21);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getRemplirTable()
  {
    return remplirTableEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRemplirTable_Utiliser()
  {
    return (EReference)remplirTableEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getAlerteFonction()
  {
    return alerteFonctionEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getAlerteFonction_Message()
  {
    return (EAttribute)alerteFonctionEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getNavigate()
  {
    return navigateEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getNavigate_Ref()
  {
    return (EReference)navigateEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVue()
  {
    return vueEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getElements()
  {
    return elementsEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getcomposant()
  {
    return composantEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getcomposant_Name()
  {
    return (EAttribute)composantEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getForms()
  {
    return formsEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getForms_Name()
  {
    return (EAttribute)formsEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getForms_Ligne()
  {
    return (EAttribute)formsEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getForms_Colonne()
  {
    return (EAttribute)formsEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getlists()
  {
    return listsEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getIcons()
  {
    return iconsEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIcons_Name()
  {
    return (EAttribute)iconsEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIcons_Ligne()
  {
    return (EAttribute)iconsEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIcons_Colonne()
  {
    return (EAttribute)iconsEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getIcons_Style()
  {
    return (EReference)iconsEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getlistView()
  {
    return listViewEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getlistView_Name()
  {
    return (EAttribute)listViewEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getlistView_Utiliser()
  {
    return (EReference)listViewEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getlistView_Ligne()
  {
    return (EAttribute)listViewEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getlistView_Colonne()
  {
    return (EAttribute)listViewEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getlistView_Style()
  {
    return (EReference)listViewEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getRadioButton()
  {
    return radioButtonEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getRadioButton_Name()
  {
    return (EAttribute)radioButtonEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getRadioButton_Ligne()
  {
    return (EAttribute)radioButtonEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getRadioButton_Colonne()
  {
    return (EAttribute)radioButtonEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getRadioButton_Style()
  {
    return (EReference)radioButtonEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getCheckBox()
  {
    return checkBoxEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getCheckBox_Name()
  {
    return (EAttribute)checkBoxEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getCheckBox_Ligne()
  {
    return (EAttribute)checkBoxEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getCheckBox_Colonne()
  {
    return (EAttribute)checkBoxEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getCheckBox_Style()
  {
    return (EReference)checkBoxEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getText()
  {
    return textEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getText_Contenu()
  {
    return (EAttribute)textEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getText_Style()
  {
    return (EReference)textEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getInput()
  {
    return inputEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getInput_Style()
  {
    return (EReference)inputEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getIcone()
  {
    return iconeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getIcone_Type()
  {
    return (EAttribute)iconeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getSocialIcon()
  {
    return socialIconEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSocialIcon_Type()
  {
    return (EAttribute)socialIconEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSocialIcon_Button()
  {
    return (EAttribute)socialIconEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getSocialIcon_Raised()
  {
    return (EAttribute)socialIconEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSocialIcon_Onclique()
  {
    return (EReference)socialIconEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSocialIcon_Onlongclique()
  {
    return (EReference)socialIconEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getTab()
  {
    return tabEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getTab_Name()
  {
    return (EAttribute)tabEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getTab_Title()
  {
    return (EAttribute)tabEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getTab_Text()
  {
    return (EAttribute)tabEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTab_Icon()
  {
    return (EReference)tabEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTab_Elements()
  {
    return (EReference)tabEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getTab_Ligne()
  {
    return (EAttribute)tabEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getTab_Colonne()
  {
    return (EAttribute)tabEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getHeading()
  {
    return headingEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHeading_Name()
  {
    return (EAttribute)headingEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHeading_Type()
  {
    return (EAttribute)headingEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHeading_Ligne()
  {
    return (EAttribute)headingEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getHeading_Colonne()
  {
    return (EAttribute)headingEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getContainerStyle()
  {
    return containerStyleEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getContainerStyle_Name()
  {
    return (EAttribute)containerStyleEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getContainerFonctions()
  {
    return containerFonctionsEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getContainerFonctions_Name()
  {
    return (EAttribute)containerFonctionsEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getLayout()
  {
    return layoutEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getLayout_Name()
  {
    return (EAttribute)layoutEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getLayout_Titre()
  {
    return (EAttribute)layoutEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLayout_Contient()
  {
    return (EReference)layoutEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLayout_Style()
  {
    return (EReference)layoutEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getLayout_StyleB()
  {
    return (EReference)layoutEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getBouton()
  {
    return boutonEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getBouton_Name()
  {
    return (EAttribute)boutonEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBouton_Icon()
  {
    return (EReference)boutonEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBouton_Onclique()
  {
    return (EReference)boutonEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBouton_Onlongclique()
  {
    return (EReference)boutonEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getBouton_Prop()
  {
    return (EAttribute)boutonEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getBouton_IconRight()
  {
    return (EAttribute)boutonEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getBouton_Ligne()
  {
    return (EAttribute)boutonEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getBouton_Colonne()
  {
    return (EAttribute)boutonEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getBouton_Style()
  {
    return (EReference)boutonEClass.getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getVideo()
  {
    return videoEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getVideo_UrlV()
  {
    return (EAttribute)videoEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getVideo_Mutte()
  {
    return (EAttribute)videoEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getVideo_Widtht()
  {
    return (EAttribute)videoEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getVideo_Heightr()
  {
    return (EAttribute)videoEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getVideo_LigneAudio()
  {
    return (EAttribute)videoEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getVideo_ColoneAudio()
  {
    return (EAttribute)videoEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getAudio()
  {
    return audioEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getAudio_UrlT()
  {
    return (EAttribute)audioEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getAudio_Textbout()
  {
    return (EAttribute)audioEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getAudio_LigneAudio()
  {
    return (EAttribute)audioEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getAudio_ColoneAudio()
  {
    return (EAttribute)audioEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getAudio_StyleAudio()
  {
    return (EReference)audioEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getMapView()
  {
    return mapViewEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMapView_Latitude()
  {
    return (EAttribute)mapViewEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMapView_Longitude()
  {
    return (EAttribute)mapViewEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMapView_LatitudeDelta()
  {
    return (EAttribute)mapViewEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMapView_LongitudeDelta()
  {
    return (EAttribute)mapViewEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMapView_Ligne()
  {
    return (EAttribute)mapViewEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMapView_Colone()
  {
    return (EAttribute)mapViewEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getImage()
  {
    return imageEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getImage_Url()
  {
    return (EAttribute)imageEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getImage_Ligne()
  {
    return (EAttribute)imageEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getImage_Colone()
  {
    return (EAttribute)imageEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getImage_Style()
  {
    return (EReference)imageEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getModel()
  {
    return modelEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getTableDefinition()
  {
    return tableDefinitionEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getTableDefinition_Name()
  {
    return (EAttribute)tableDefinitionEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTableDefinition_Champ()
  {
    return (EReference)tableDefinitionEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getOne()
  {
    return oneEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getNine()
  {
    return nineEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getEignth()
  {
    return eignthEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getThree()
  {
    return threeEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getFoor()
  {
    return foorEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getColors()
  {
    return colorsEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getaliIT()
  {
    return aliITEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getalfem()
  {
    return alfemEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getbordersty()
  {
    return borderstyEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum gettextType()
  {
    return textTypeEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getBacknum()
  {
    return backnumEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getTypeH()
  {
    return typeHEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getIconType()
  {
    return iconTypeEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getsizelist()
  {
    return sizelistEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getSocialIconType()
  {
    return socialIconTypeEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getflexd()
  {
    return flexdEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getmut()
  {
    return mutEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getbuttonType()
  {
    return buttonTypeEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getraisedType()
  {
    return raisedTypeEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getPropType()
  {
    return propTypeEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getIconRightType()
  {
    return iconRightTypeEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getJustifyContentType()
  {
    return justifyContentTypeEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getentier()
  {
    return entierEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getLC()
  {
    return lcEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public PfeFactory getPfeFactory()
  {
    return (PfeFactory)getEFactoryInstance();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private boolean isCreated = false;

  /**
   * Creates the meta-model objects for the package.  This method is
   * guarded to have no affect on any invocation but its first.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void createPackageContents()
  {
    if (isCreated) return;
    isCreated = true;

    // Create classes and their features
    applicationEClass = createEClass(APPLICATION);
    createEAttribute(applicationEClass, APPLICATION__NAME);
    createEAttribute(applicationEClass, APPLICATION__PACKAGE_NAME);
    createEReference(applicationEClass, APPLICATION__FIRST_LAYOUT);
    createEReference(applicationEClass, APPLICATION__MODEL);
    createEReference(applicationEClass, APPLICATION__VUE);
    createEReference(applicationEClass, APPLICATION__CONTROLEUR);

    controleurEClass = createEClass(CONTROLEUR);

    fonctionsEClass = createEClass(FONCTIONS);
    createEAttribute(fonctionsEClass, FONCTIONS__NAME);

    stylesheetEClass = createEClass(STYLESHEET);

    fonctionEClass = createEClass(FONCTION);

    styleTextEClass = createEClass(STYLE_TEXT);
    createEAttribute(styleTextEClass, STYLE_TEXT__COLORE);
    createEAttribute(styleTextEClass, STYLE_TEXT__FONT_FAMILY_E);
    createEAttribute(styleTextEClass, STYLE_TEXT__FONT_SIZES);
    createEAttribute(styleTextEClass, STYLE_TEXT__FONT_STYLES);
    createEAttribute(styleTextEClass, STYLE_TEXT__FONT_WEIGHTE);
    createEAttribute(styleTextEClass, STYLE_TEXT__LINE_HEIGHTE);
    createEAttribute(styleTextEClass, STYLE_TEXT__TEXT_ALIGNE);
    createEAttribute(styleTextEClass, STYLE_TEXT__BACKFACE_VISIBILITYE);
    createEAttribute(styleTextEClass, STYLE_TEXT__BACKGROUND_COLORE);
    createEAttribute(styleTextEClass, STYLE_TEXT__BORDER_BOTTOM_COLORE);
    createEAttribute(styleTextEClass, STYLE_TEXT__BORDER_BOTTOM_LEFT_RADIUSE);
    createEAttribute(styleTextEClass, STYLE_TEXT__BORDER_BOTTOM_RIGHT_RADIUSE);
    createEAttribute(styleTextEClass, STYLE_TEXT__BORDER_BOTTOM_WIDTHE);
    createEAttribute(styleTextEClass, STYLE_TEXT__BORDER_COLORE);
    createEAttribute(styleTextEClass, STYLE_TEXT__BORDER_LEFT_COLORE);
    createEAttribute(styleTextEClass, STYLE_TEXT__BORDER_LEFT_WIDTHE);
    createEAttribute(styleTextEClass, STYLE_TEXT__BORDER_RADIUSE);
    createEAttribute(styleTextEClass, STYLE_TEXT__BORDER_RIGHT_COLORE);
    createEAttribute(styleTextEClass, STYLE_TEXT__BORDER_RIGHT_WIDTH);
    createEAttribute(styleTextEClass, STYLE_TEXT__BORDER_STYLES);
    createEAttribute(styleTextEClass, STYLE_TEXT__BORDER_TOP_COLORE);
    createEAttribute(styleTextEClass, STYLE_TEXT__BORDER_TOP_LEFT_RADIUSE);
    createEAttribute(styleTextEClass, STYLE_TEXT__BORDER_TOP_RIGHT_RADIUSE);
    createEAttribute(styleTextEClass, STYLE_TEXT__BORDER_TOP_WIDTHE);
    createEAttribute(styleTextEClass, STYLE_TEXT__BORDER_WIDTHE);
    createEAttribute(styleTextEClass, STYLE_TEXT__OPACITYE);

    styleViewEClass = createEClass(STYLE_VIEW);
    createEAttribute(styleViewEClass, STYLE_VIEW__BACKFACE_VISIBILITY2);
    createEAttribute(styleViewEClass, STYLE_VIEW__BACKGROUND_COLOR2);
    createEAttribute(styleViewEClass, STYLE_VIEW__BORDER_BOTTOM_COLOR2);
    createEAttribute(styleViewEClass, STYLE_VIEW__BORDER_BOTTOM_LEFT_RADIUS2);
    createEAttribute(styleViewEClass, STYLE_VIEW__BORDER_BOTTOM_RIGHT_RADIUS2);
    createEAttribute(styleViewEClass, STYLE_VIEW__BORDER_BOTTOM_WIDTH2);
    createEAttribute(styleViewEClass, STYLE_VIEW__BORDER_COLORT);
    createEAttribute(styleViewEClass, STYLE_VIEW__BORDER_LEFT_COLORT);
    createEAttribute(styleViewEClass, STYLE_VIEW__BORDER_LEFT_WIDTHT);
    createEAttribute(styleViewEClass, STYLE_VIEW__BORDER_RADIUST);
    createEAttribute(styleViewEClass, STYLE_VIEW__BORDER_RIGHT_COLORT);
    createEAttribute(styleViewEClass, STYLE_VIEW__BORDER_RIGHT_WIDTHT);
    createEAttribute(styleViewEClass, STYLE_VIEW__BORDER_STYLET);
    createEAttribute(styleViewEClass, STYLE_VIEW__BORDER_TOP_COLORT);
    createEAttribute(styleViewEClass, STYLE_VIEW__BORDER_TOP_LEFT_RADIUST);
    createEAttribute(styleViewEClass, STYLE_VIEW__BORDER_TOP_RIGHT_RADIUST);
    createEAttribute(styleViewEClass, STYLE_VIEW__BORDER_TOP_WIDTHT);
    createEAttribute(styleViewEClass, STYLE_VIEW__BORDER_WIDTHT);
    createEAttribute(styleViewEClass, STYLE_VIEW__OPACITYT);
    createEAttribute(styleViewEClass, STYLE_VIEW__ALIGN_ITEMST);
    createEAttribute(styleViewEClass, STYLE_VIEW__ALIGN_SELFT);
    createEAttribute(styleViewEClass, STYLE_VIEW__BOTTOMT);
    createEAttribute(styleViewEClass, STYLE_VIEW__FLEXT);
    createEAttribute(styleViewEClass, STYLE_VIEW__FLEX_DIRECTIONT);
    createEAttribute(styleViewEClass, STYLE_VIEW__FLEX_WRAPT);
    createEAttribute(styleViewEClass, STYLE_VIEW__HEIGHTE);
    createEAttribute(styleViewEClass, STYLE_VIEW__JUSTIFY_CONTENTE);
    createEAttribute(styleViewEClass, STYLE_VIEW__LEFTE);
    createEAttribute(styleViewEClass, STYLE_VIEW__MARGIN);
    createEAttribute(styleViewEClass, STYLE_VIEW__MARGIN_BOTTOME);
    createEAttribute(styleViewEClass, STYLE_VIEW__MARGIN_LEFTE);
    createEAttribute(styleViewEClass, STYLE_VIEW__MARGIN_RIGHTE);
    createEAttribute(styleViewEClass, STYLE_VIEW__MARGIN_TOPE);
    createEAttribute(styleViewEClass, STYLE_VIEW__MARGIN_VERTICALE);
    createEAttribute(styleViewEClass, STYLE_VIEW__PADDINGT);
    createEAttribute(styleViewEClass, STYLE_VIEW__PADDING_BOTTOMT);
    createEAttribute(styleViewEClass, STYLE_VIEW__PADDING_HORIZONTALE);
    createEAttribute(styleViewEClass, STYLE_VIEW__PADDING_RIGHTE);
    createEAttribute(styleViewEClass, STYLE_VIEW__PADDING_TOPE);
    createEAttribute(styleViewEClass, STYLE_VIEW__PADDING_VERTICALE);
    createEAttribute(styleViewEClass, STYLE_VIEW__RIGHTT);
    createEAttribute(styleViewEClass, STYLE_VIEW__WIDTHT);

    styleImageEClass = createEClass(STYLE_IMAGE);
    createEAttribute(styleImageEClass, STYLE_IMAGE__BACKFACE_VISIBILITY);
    createEAttribute(styleImageEClass, STYLE_IMAGE__BACKGROUND_COLORA);
    createEAttribute(styleImageEClass, STYLE_IMAGE__BORDER_BOTTOM_LEFT_RADIUSA);
    createEAttribute(styleImageEClass, STYLE_IMAGE__BORDER_BOTTOM_RIGHT_RADIUSA);
    createEAttribute(styleImageEClass, STYLE_IMAGE__BORDER_COLORA);
    createEAttribute(styleImageEClass, STYLE_IMAGE__BORDER_RADIUSA);
    createEAttribute(styleImageEClass, STYLE_IMAGE__BORDER_TOP_LEFT_RADIUSA);
    createEAttribute(styleImageEClass, STYLE_IMAGE__BORDER_TOP_RIGHT_RADIUSA);
    createEAttribute(styleImageEClass, STYLE_IMAGE__BORDER_WIDTHA);
    createEAttribute(styleImageEClass, STYLE_IMAGE__OPACITYA);
    createEAttribute(styleImageEClass, STYLE_IMAGE__OVERFLOWA);
    createEAttribute(styleImageEClass, STYLE_IMAGE__ALIGN_ITEMST);
    createEAttribute(styleImageEClass, STYLE_IMAGE__ALIGN_SELFT);
    createEAttribute(styleImageEClass, STYLE_IMAGE__BOTTOMT);
    createEAttribute(styleImageEClass, STYLE_IMAGE__FLEXT);
    createEAttribute(styleImageEClass, STYLE_IMAGE__JUSTIFY_CONTENTE);
    createEAttribute(styleImageEClass, STYLE_IMAGE__LEFTE);
    createEAttribute(styleImageEClass, STYLE_IMAGE__MARGIN);
    createEAttribute(styleImageEClass, STYLE_IMAGE__MARGIN_BOTTOME);
    createEAttribute(styleImageEClass, STYLE_IMAGE__MARGIN_LEFTE);
    createEAttribute(styleImageEClass, STYLE_IMAGE__MARGIN_RIGHTE);
    createEAttribute(styleImageEClass, STYLE_IMAGE__MARGIN_TOPE);
    createEAttribute(styleImageEClass, STYLE_IMAGE__MARGIN_VERTICALE);
    createEAttribute(styleImageEClass, STYLE_IMAGE__PADDINGT);
    createEAttribute(styleImageEClass, STYLE_IMAGE__PADDING_BOTTOMT);
    createEAttribute(styleImageEClass, STYLE_IMAGE__PADDING_HORIZONTALE);
    createEAttribute(styleImageEClass, STYLE_IMAGE__PADDING_RIGHTE);
    createEAttribute(styleImageEClass, STYLE_IMAGE__PADDING_TOPE);
    createEAttribute(styleImageEClass, STYLE_IMAGE__PADDING_VERTICALE);
    createEAttribute(styleImageEClass, STYLE_IMAGE__RIGHTT);
    createEAttribute(styleImageEClass, STYLE_IMAGE__WIDTHT);
    createEAttribute(styleImageEClass, STYLE_IMAGE__FLEX_DIRECTIONT);
    createEAttribute(styleImageEClass, STYLE_IMAGE__FLEX_WRAPT);
    createEAttribute(styleImageEClass, STYLE_IMAGE__HEIGHTE);

    styleflexboxEClass = createEClass(STYLEFLEXBOX);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__ALIGN_ITEMS3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__ALIGN_SELF3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__BORDER_BOTTOM_WIDTH3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__BORDER_LEFT_WIDTH3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__BORDER_RIGHT_WIDTH3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__BORDER_TOP_WIDTH3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__BORDER_WIDTH3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__BOTTOM3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__FLEX3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__FLEX_DIRECTION3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__FLEX_WRAP3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__HEIGHT3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__JUSTIFY_CONTENT3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__LEFT3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__MARGIN3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__MARGIN_BOTTOM3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__MARGIN_LEFT3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__MARGIN_RIGHT3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__MARGIN_TOP3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__MARGIN_VERTICAL3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__PENDDING3);
    createEAttribute(styleflexboxEClass, STYLEFLEXBOX__PANDDING_B);

    remplirTableEClass = createEClass(REMPLIR_TABLE);
    createEReference(remplirTableEClass, REMPLIR_TABLE__UTILISER);

    alerteFonctionEClass = createEClass(ALERTE_FONCTION);
    createEAttribute(alerteFonctionEClass, ALERTE_FONCTION__MESSAGE);

    navigateEClass = createEClass(NAVIGATE);
    createEReference(navigateEClass, NAVIGATE__REF);

    vueEClass = createEClass(VUE);

    elementsEClass = createEClass(ELEMENTS);

    composantEClass = createEClass(COMPOSANT);
    createEAttribute(composantEClass, COMPOSANT__NAME);

    formsEClass = createEClass(FORMS);
    createEAttribute(formsEClass, FORMS__NAME);
    createEAttribute(formsEClass, FORMS__LIGNE);
    createEAttribute(formsEClass, FORMS__COLONNE);

    listsEClass = createEClass(LISTS);

    iconsEClass = createEClass(ICONS);
    createEAttribute(iconsEClass, ICONS__NAME);
    createEAttribute(iconsEClass, ICONS__LIGNE);
    createEAttribute(iconsEClass, ICONS__COLONNE);
    createEReference(iconsEClass, ICONS__STYLE);

    listViewEClass = createEClass(LIST_VIEW);
    createEAttribute(listViewEClass, LIST_VIEW__NAME);
    createEReference(listViewEClass, LIST_VIEW__UTILISER);
    createEAttribute(listViewEClass, LIST_VIEW__LIGNE);
    createEAttribute(listViewEClass, LIST_VIEW__COLONNE);
    createEReference(listViewEClass, LIST_VIEW__STYLE);

    radioButtonEClass = createEClass(RADIO_BUTTON);
    createEAttribute(radioButtonEClass, RADIO_BUTTON__NAME);
    createEAttribute(radioButtonEClass, RADIO_BUTTON__LIGNE);
    createEAttribute(radioButtonEClass, RADIO_BUTTON__COLONNE);
    createEReference(radioButtonEClass, RADIO_BUTTON__STYLE);

    checkBoxEClass = createEClass(CHECK_BOX);
    createEAttribute(checkBoxEClass, CHECK_BOX__NAME);
    createEAttribute(checkBoxEClass, CHECK_BOX__LIGNE);
    createEAttribute(checkBoxEClass, CHECK_BOX__COLONNE);
    createEReference(checkBoxEClass, CHECK_BOX__STYLE);

    textEClass = createEClass(TEXT);
    createEAttribute(textEClass, TEXT__CONTENU);
    createEReference(textEClass, TEXT__STYLE);

    inputEClass = createEClass(INPUT);
    createEReference(inputEClass, INPUT__STYLE);

    iconeEClass = createEClass(ICONE);
    createEAttribute(iconeEClass, ICONE__TYPE);

    socialIconEClass = createEClass(SOCIAL_ICON);
    createEAttribute(socialIconEClass, SOCIAL_ICON__TYPE);
    createEAttribute(socialIconEClass, SOCIAL_ICON__BUTTON);
    createEAttribute(socialIconEClass, SOCIAL_ICON__RAISED);
    createEReference(socialIconEClass, SOCIAL_ICON__ONCLIQUE);
    createEReference(socialIconEClass, SOCIAL_ICON__ONLONGCLIQUE);

    tabEClass = createEClass(TAB);
    createEAttribute(tabEClass, TAB__NAME);
    createEAttribute(tabEClass, TAB__TITLE);
    createEAttribute(tabEClass, TAB__TEXT);
    createEReference(tabEClass, TAB__ICON);
    createEReference(tabEClass, TAB__ELEMENTS);
    createEAttribute(tabEClass, TAB__LIGNE);
    createEAttribute(tabEClass, TAB__COLONNE);

    headingEClass = createEClass(HEADING);
    createEAttribute(headingEClass, HEADING__NAME);
    createEAttribute(headingEClass, HEADING__TYPE);
    createEAttribute(headingEClass, HEADING__LIGNE);
    createEAttribute(headingEClass, HEADING__COLONNE);

    containerStyleEClass = createEClass(CONTAINER_STYLE);
    createEAttribute(containerStyleEClass, CONTAINER_STYLE__NAME);

    containerFonctionsEClass = createEClass(CONTAINER_FONCTIONS);
    createEAttribute(containerFonctionsEClass, CONTAINER_FONCTIONS__NAME);

    layoutEClass = createEClass(LAYOUT);
    createEAttribute(layoutEClass, LAYOUT__NAME);
    createEAttribute(layoutEClass, LAYOUT__TITRE);
    createEReference(layoutEClass, LAYOUT__CONTIENT);
    createEReference(layoutEClass, LAYOUT__STYLE);
    createEReference(layoutEClass, LAYOUT__STYLE_B);

    boutonEClass = createEClass(BOUTON);
    createEAttribute(boutonEClass, BOUTON__NAME);
    createEReference(boutonEClass, BOUTON__ICON);
    createEReference(boutonEClass, BOUTON__ONCLIQUE);
    createEReference(boutonEClass, BOUTON__ONLONGCLIQUE);
    createEAttribute(boutonEClass, BOUTON__PROP);
    createEAttribute(boutonEClass, BOUTON__ICON_RIGHT);
    createEAttribute(boutonEClass, BOUTON__LIGNE);
    createEAttribute(boutonEClass, BOUTON__COLONNE);
    createEReference(boutonEClass, BOUTON__STYLE);

    videoEClass = createEClass(VIDEO);
    createEAttribute(videoEClass, VIDEO__URL_V);
    createEAttribute(videoEClass, VIDEO__MUTTE);
    createEAttribute(videoEClass, VIDEO__WIDTHT);
    createEAttribute(videoEClass, VIDEO__HEIGHTR);
    createEAttribute(videoEClass, VIDEO__LIGNE_AUDIO);
    createEAttribute(videoEClass, VIDEO__COLONE_AUDIO);

    audioEClass = createEClass(AUDIO);
    createEAttribute(audioEClass, AUDIO__URL_T);
    createEAttribute(audioEClass, AUDIO__TEXTBOUT);
    createEAttribute(audioEClass, AUDIO__LIGNE_AUDIO);
    createEAttribute(audioEClass, AUDIO__COLONE_AUDIO);
    createEReference(audioEClass, AUDIO__STYLE_AUDIO);

    mapViewEClass = createEClass(MAP_VIEW);
    createEAttribute(mapViewEClass, MAP_VIEW__LATITUDE);
    createEAttribute(mapViewEClass, MAP_VIEW__LONGITUDE);
    createEAttribute(mapViewEClass, MAP_VIEW__LATITUDE_DELTA);
    createEAttribute(mapViewEClass, MAP_VIEW__LONGITUDE_DELTA);
    createEAttribute(mapViewEClass, MAP_VIEW__LIGNE);
    createEAttribute(mapViewEClass, MAP_VIEW__COLONE);

    imageEClass = createEClass(IMAGE);
    createEAttribute(imageEClass, IMAGE__URL);
    createEAttribute(imageEClass, IMAGE__LIGNE);
    createEAttribute(imageEClass, IMAGE__COLONE);
    createEReference(imageEClass, IMAGE__STYLE);

    modelEClass = createEClass(MODEL);

    tableDefinitionEClass = createEClass(TABLE_DEFINITION);
    createEAttribute(tableDefinitionEClass, TABLE_DEFINITION__NAME);
    createEReference(tableDefinitionEClass, TABLE_DEFINITION__CHAMP);

    // Create enums
    oneEEnum = createEEnum(ONE);
    nineEEnum = createEEnum(NINE);
    eignthEEnum = createEEnum(EIGNTH);
    threeEEnum = createEEnum(THREE);
    foorEEnum = createEEnum(FOOR);
    colorsEEnum = createEEnum(COLORS);
    aliITEEnum = createEEnum(ALI_IT);
    alfemEEnum = createEEnum(ALFEM);
    borderstyEEnum = createEEnum(BORDERSTY);
    textTypeEEnum = createEEnum(TEXT_TYPE);
    backnumEEnum = createEEnum(BACKNUM);
    typeHEEnum = createEEnum(TYPE_H);
    iconTypeEEnum = createEEnum(ICON_TYPE);
    sizelistEEnum = createEEnum(SIZELIST);
    socialIconTypeEEnum = createEEnum(SOCIAL_ICON_TYPE);
    flexdEEnum = createEEnum(FLEXD);
    mutEEnum = createEEnum(MUT);
    buttonTypeEEnum = createEEnum(BUTTON_TYPE);
    raisedTypeEEnum = createEEnum(RAISED_TYPE);
    propTypeEEnum = createEEnum(PROP_TYPE);
    iconRightTypeEEnum = createEEnum(ICON_RIGHT_TYPE);
    justifyContentTypeEEnum = createEEnum(JUSTIFY_CONTENT_TYPE);
    entierEEnum = createEEnum(ENTIER);
    lcEEnum = createEEnum(LC);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private boolean isInitialized = false;

  /**
   * Complete the initialization of the package and its meta-model.  This
   * method is guarded to have no affect on any invocation but its first.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void initializePackageContents()
  {
    if (isInitialized) return;
    isInitialized = true;

    // Initialize package
    setName(eNAME);
    setNsPrefix(eNS_PREFIX);
    setNsURI(eNS_URI);

    // Create type parameters

    // Set bounds for type parameters

    // Add supertypes to classes
    fonctionsEClass.getESuperTypes().add(this.getControleur());
    stylesheetEClass.getESuperTypes().add(this.getFonctions());
    fonctionEClass.getESuperTypes().add(this.getFonctions());
    styleTextEClass.getESuperTypes().add(this.getstylesheet());
    styleViewEClass.getESuperTypes().add(this.getstylesheet());
    styleImageEClass.getESuperTypes().add(this.getstylesheet());
    styleflexboxEClass.getESuperTypes().add(this.getstylesheet());
    remplirTableEClass.getESuperTypes().add(this.getfonction());
    alerteFonctionEClass.getESuperTypes().add(this.getfonction());
    navigateEClass.getESuperTypes().add(this.getfonction());
    elementsEClass.getESuperTypes().add(this.getVue());
    composantEClass.getESuperTypes().add(this.getElements());
    formsEClass.getESuperTypes().add(this.getElements());
    listsEClass.getESuperTypes().add(this.getElements());
    iconsEClass.getESuperTypes().add(this.getElements());
    listViewEClass.getESuperTypes().add(this.getlists());
    radioButtonEClass.getESuperTypes().add(this.getElements());
    checkBoxEClass.getESuperTypes().add(this.getElements());
    textEClass.getESuperTypes().add(this.getForms());
    inputEClass.getESuperTypes().add(this.getForms());
    iconeEClass.getESuperTypes().add(this.getIcons());
    socialIconEClass.getESuperTypes().add(this.getIcons());
    tabEClass.getESuperTypes().add(this.getElements());
    headingEClass.getESuperTypes().add(this.getElements());
    containerStyleEClass.getESuperTypes().add(this.getElements());
    containerFonctionsEClass.getESuperTypes().add(this.getElements());
    layoutEClass.getESuperTypes().add(this.getElements());
    boutonEClass.getESuperTypes().add(this.getElements());
    videoEClass.getESuperTypes().add(this.getcomposant());
    audioEClass.getESuperTypes().add(this.getcomposant());
    mapViewEClass.getESuperTypes().add(this.getcomposant());
    imageEClass.getESuperTypes().add(this.getcomposant());
    tableDefinitionEClass.getESuperTypes().add(this.getModel());

    // Initialize classes and features; add operations and parameters
    initEClass(applicationEClass, Application.class, "Application", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getApplication_Name(), ecorePackage.getEString(), "name", null, 0, 1, Application.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getApplication_PackageName(), ecorePackage.getEString(), "packageName", null, 0, 1, Application.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getApplication_FirstLayout(), this.getLayout(), null, "FirstLayout", null, 0, -1, Application.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getApplication_Model(), this.getModel(), null, "model", null, 0, -1, Application.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getApplication_Vue(), this.getVue(), null, "vue", null, 0, -1, Application.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getApplication_Controleur(), this.getControleur(), null, "controleur", null, 0, -1, Application.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(controleurEClass, Controleur.class, "Controleur", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(fonctionsEClass, Fonctions.class, "Fonctions", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getFonctions_Name(), ecorePackage.getEString(), "name", null, 0, 1, Fonctions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(stylesheetEClass, stylesheet.class, "stylesheet", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(fonctionEClass, fonction.class, "fonction", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(styleTextEClass, StyleText.class, "StyleText", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getStyleText_Colore(), this.getColors(), "colore", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_FontFamilyE(), this.getTypeH(), "fontFamilyE", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_FontSizes(), this.getentier(), "fontSizes", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_FontStyles(), this.getThree(), "fontStyles", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_FontWeighte(), this.getFoor(), "fontWeighte", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_LineHeighte(), this.getentier(), "lineHeighte", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_TextAligne(), this.getEignth(), "TextAligne", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_BackfaceVisibilitye(), this.getBacknum(), "backfaceVisibilitye", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_BackgroundColore(), this.getColors(), "backgroundColore", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_BorderBottomColore(), this.getColors(), "borderBottomColore", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_BorderBottomLeftRadiuse(), this.getentier(), "borderBottomLeftRadiuse", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_BorderBottomRightRadiuse(), this.getentier(), "borderBottomRightRadiuse", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_BorderBottomWidthe(), this.getentier(), "borderBottomWidthe", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_BorderColore(), this.getColors(), "borderColore", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_BorderLeftColore(), this.getColors(), "borderLeftColore", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_BorderLeftWidthe(), this.getentier(), "borderLeftWidthe", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_BorderRadiuse(), this.getentier(), "borderRadiuse", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_BorderRightColore(), this.getColors(), "borderRightColore", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_BorderRightWidth(), this.getentier(), "borderRightWidth", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_BorderStyles(), this.getbordersty(), "borderStyles", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_BorderTopColore(), this.getColors(), "borderTopColore", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_BorderTopLeftRadiuse(), this.getentier(), "borderTopLeftRadiuse", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_BorderTopRightRadiuse(), this.getentier(), "borderTopRightRadiuse", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_BorderTopWidthe(), this.getentier(), "borderTopWidthe", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_BorderWidthe(), this.getentier(), "borderWidthe", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleText_Opacitye(), this.getentier(), "opacitye", null, 0, 1, StyleText.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(styleViewEClass, StyleView.class, "StyleView", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getStyleView_BackfaceVisibility2(), this.getBacknum(), "backfaceVisibility2", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_BackgroundColor2(), this.getColors(), "backgroundColor2", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_BorderBottomColor2(), this.getColors(), "borderBottomColor2", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_BorderBottomLeftRadius2(), this.getentier(), "borderBottomLeftRadius2", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_BorderBottomRightRadius2(), this.getentier(), "borderBottomRightRadius2", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_BorderBottomWidth2(), this.getentier(), "borderBottomWidth2", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_BorderColort(), this.getColors(), "borderColort", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_BorderLeftColort(), this.getColors(), "borderLeftColort", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_BorderLeftWidtht(), this.getentier(), "borderLeftWidtht", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_BorderRadiust(), this.getentier(), "borderRadiust", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_BorderRightColort(), this.getColors(), "borderRightColort", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_BorderRightWidtht(), this.getentier(), "borderRightWidtht", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_BorderStylet(), this.getbordersty(), "borderStylet", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_BorderTopColort(), this.getColors(), "borderTopColort", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_BorderTopLeftRadiust(), this.getentier(), "borderTopLeftRadiust", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_BorderTopRightRadiust(), this.getentier(), "borderTopRightRadiust", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_BorderTopWidtht(), this.getentier(), "borderTopWidtht", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_BorderWidtht(), this.getentier(), "borderWidtht", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_Opacityt(), this.getentier(), "opacityt", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_AlignItemst(), this.getaliIT(), "alignItemst", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_AlignSelft(), this.getalfem(), "alignSelft", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_Bottomt(), this.getentier(), "bottomt", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_Flext(), this.getentier(), "flext", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_FlexDirectiont(), this.getflexd(), "flexDirectiont", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_FlexWrapt(), this.getOne(), "flexWrapt", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_Heighte(), this.getentier(), "heighte", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_JustifyContente(), this.getJustifyContentType(), "justifyContente", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_Lefte(), this.getentier(), "lefte", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_Margin(), this.getentier(), "margin", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_MarginBottome(), this.getentier(), "marginBottome", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_MarginLefte(), this.getentier(), "marginLefte", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_MarginRighte(), this.getentier(), "marginRighte", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_MarginTope(), this.getentier(), "marginTope", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_MarginVerticale(), this.getentier(), "marginVerticale", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_Paddingt(), this.getentier(), "paddingt", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_PaddingBottomt(), this.getentier(), "paddingBottomt", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_PaddingHorizontale(), this.getentier(), "paddingHorizontale", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_PaddingRighte(), this.getentier(), "paddingRighte", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_PaddingTope(), this.getentier(), "paddingTope", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_PaddingVerticale(), this.getentier(), "paddingVerticale", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_Rightt(), this.getentier(), "rightt", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleView_Widtht(), this.getentier(), "widtht", null, 0, 1, StyleView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(styleImageEClass, StyleImage.class, "StyleImage", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getStyleImage_BackfaceVisibility(), this.getBacknum(), "backfaceVisibility", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_BackgroundColora(), this.getColors(), "backgroundColora", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_BorderBottomLeftRadiusa(), this.getentier(), "borderBottomLeftRadiusa", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_BorderBottomRightRadiusa(), this.getentier(), "borderBottomRightRadiusa", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_BorderColora(), this.getColors(), "borderColora", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_BorderRadiusa(), this.getentier(), "borderRadiusa", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_BorderTopLeftRadiusa(), this.getentier(), "borderTopLeftRadiusa", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_BorderTopRightRadiusa(), this.getentier(), "borderTopRightRadiusa", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_BorderWidtha(), this.getentier(), "borderWidtha", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_Opacitya(), this.getentier(), "opacitya", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_Overflowa(), this.getentier(), "overflowa", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_AlignItemst(), this.getaliIT(), "alignItemst", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_AlignSelft(), this.getalfem(), "alignSelft", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_Bottomt(), this.getentier(), "bottomt", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_Flext(), this.getentier(), "flext", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_JustifyContente(), this.getJustifyContentType(), "justifyContente", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_Lefte(), this.getentier(), "lefte", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_Margin(), this.getentier(), "margin", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_MarginBottome(), this.getentier(), "marginBottome", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_MarginLefte(), this.getentier(), "marginLefte", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_MarginRighte(), this.getentier(), "marginRighte", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_MarginTope(), this.getentier(), "marginTope", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_MarginVerticale(), this.getentier(), "marginVerticale", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_Paddingt(), this.getentier(), "paddingt", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_PaddingBottomt(), this.getentier(), "paddingBottomt", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_PaddingHorizontale(), this.getentier(), "paddingHorizontale", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_PaddingRighte(), this.getentier(), "paddingRighte", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_PaddingTope(), this.getentier(), "paddingTope", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_PaddingVerticale(), this.getentier(), "paddingVerticale", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_Rightt(), this.getentier(), "rightt", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_Widtht(), this.getentier(), "widtht", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_FlexDirectiont(), this.getflexd(), "flexDirectiont", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_FlexWrapt(), this.getOne(), "flexWrapt", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleImage_Heighte(), this.getentier(), "heighte", null, 0, 1, StyleImage.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(styleflexboxEClass, Styleflexbox.class, "Styleflexbox", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getStyleflexbox_AlignItems3(), this.getaliIT(), "alignItems3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_AlignSelf3(), this.getalfem(), "alignSelf3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_BorderBottomWidth3(), this.getentier(), "borderBottomWidth3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_BorderLeftWidth3(), this.getentier(), "borderLeftWidth3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_BorderRightWidth3(), this.getentier(), "borderRightWidth3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_BorderTopWidth3(), this.getentier(), "borderTopWidth3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_BorderWidth3(), this.getentier(), "borderWidth3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_Bottom3(), this.getentier(), "bottom3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_Flex3(), this.getentier(), "flex3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_FlexDirection3(), this.getflexd(), "flexDirection3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_FlexWrap3(), this.getOne(), "flexWrap3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_Height3(), this.getentier(), "height3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_JustifyContent3(), this.getJustifyContentType(), "justifyContent3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_Left3(), this.getentier(), "left3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_Margin3(), this.getentier(), "margin3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_MarginBottom3(), this.getentier(), "marginBottom3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_MarginLeft3(), this.getentier(), "marginLeft3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_MarginRight3(), this.getentier(), "marginRight3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_MarginTop3(), this.getentier(), "marginTop3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_MarginVertical3(), this.getentier(), "marginVertical3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_Pendding3(), this.getentier(), "pendding3", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getStyleflexbox_PanddingB(), this.getentier(), "panddingB", null, 0, 1, Styleflexbox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(remplirTableEClass, RemplirTable.class, "RemplirTable", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getRemplirTable_Utiliser(), this.getTableDefinition(), null, "utiliser", null, 0, -1, RemplirTable.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(alerteFonctionEClass, AlerteFonction.class, "AlerteFonction", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getAlerteFonction_Message(), ecorePackage.getEString(), "message", null, 0, 1, AlerteFonction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(navigateEClass, Navigate.class, "Navigate", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getNavigate_Ref(), this.getLayout(), null, "ref", null, 0, -1, Navigate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(vueEClass, Vue.class, "Vue", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(elementsEClass, Elements.class, "Elements", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(composantEClass, composant.class, "composant", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getcomposant_Name(), ecorePackage.getEString(), "name", null, 0, 1, composant.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(formsEClass, Forms.class, "Forms", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getForms_Name(), ecorePackage.getEString(), "name", null, 0, 1, Forms.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getForms_Ligne(), this.getLC(), "ligne", null, 0, 1, Forms.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getForms_Colonne(), this.getLC(), "colonne", null, 0, 1, Forms.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(listsEClass, lists.class, "lists", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(iconsEClass, Icons.class, "Icons", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getIcons_Name(), ecorePackage.getEString(), "name", null, 0, 1, Icons.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getIcons_Ligne(), this.getLC(), "ligne", null, 0, 1, Icons.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getIcons_Colonne(), this.getLC(), "colonne", null, 0, 1, Icons.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getIcons_Style(), this.getStyleView(), null, "Style", null, 0, 1, Icons.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(listViewEClass, listView.class, "listView", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getlistView_Name(), ecorePackage.getEString(), "name", null, 0, 1, listView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getlistView_Utiliser(), this.getTableDefinition(), null, "utiliser", null, 0, -1, listView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getlistView_Ligne(), this.getLC(), "ligne", null, 0, 1, listView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getlistView_Colonne(), this.getLC(), "colonne", null, 0, 1, listView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getlistView_Style(), this.getStyleText(), null, "Style", null, 0, 1, listView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(radioButtonEClass, RadioButton.class, "RadioButton", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getRadioButton_Name(), ecorePackage.getEString(), "name", null, 0, 1, RadioButton.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getRadioButton_Ligne(), this.getLC(), "ligne", null, 0, 1, RadioButton.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getRadioButton_Colonne(), this.getLC(), "colonne", null, 0, 1, RadioButton.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getRadioButton_Style(), this.getStyleView(), null, "Style", null, 0, 1, RadioButton.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(checkBoxEClass, CheckBox.class, "CheckBox", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getCheckBox_Name(), ecorePackage.getEString(), "name", null, 0, 1, CheckBox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getCheckBox_Ligne(), this.getLC(), "ligne", null, 0, 1, CheckBox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getCheckBox_Colonne(), this.getLC(), "colonne", null, 0, 1, CheckBox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getCheckBox_Style(), this.getStyleView(), null, "Style", null, 0, 1, CheckBox.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(textEClass, Text.class, "Text", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getText_Contenu(), ecorePackage.getEString(), "contenu", null, 0, 1, Text.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getText_Style(), this.getStyleView(), null, "Style", null, 0, 1, Text.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(inputEClass, Input.class, "Input", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getInput_Style(), this.getStyleText(), null, "Style", null, 0, 1, Input.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(iconeEClass, Icone.class, "Icone", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getIcone_Type(), this.getIconType(), "type", null, 0, 1, Icone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(socialIconEClass, SocialIcon.class, "SocialIcon", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getSocialIcon_Type(), this.getSocialIconType(), "type", null, 0, 1, SocialIcon.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSocialIcon_Button(), this.getbuttonType(), "button", null, 0, 1, SocialIcon.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getSocialIcon_Raised(), this.getraisedType(), "raised", null, 0, 1, SocialIcon.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getSocialIcon_Onclique(), this.getfonction(), null, "onclique", null, 0, 1, SocialIcon.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getSocialIcon_Onlongclique(), this.getfonction(), null, "onlongclique", null, 0, 1, SocialIcon.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(tabEClass, Tab.class, "Tab", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getTab_Name(), ecorePackage.getEString(), "name", null, 0, 1, Tab.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getTab_Title(), ecorePackage.getEString(), "title", null, 0, 1, Tab.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getTab_Text(), this.gettextType(), "text", null, 0, 1, Tab.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getTab_Icon(), this.getIcone(), null, "icon", null, 0, 1, Tab.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getTab_Elements(), this.getElements(), null, "elements", null, 0, -1, Tab.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getTab_Ligne(), this.getLC(), "ligne", null, 0, 1, Tab.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getTab_Colonne(), this.getLC(), "colonne", null, 0, 1, Tab.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(headingEClass, Heading.class, "Heading", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getHeading_Name(), ecorePackage.getEString(), "name", null, 0, 1, Heading.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getHeading_Type(), this.getTypeH(), "type", null, 0, 1, Heading.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getHeading_Ligne(), this.getLC(), "ligne", null, 0, 1, Heading.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getHeading_Colonne(), this.getLC(), "colonne", null, 0, 1, Heading.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(containerStyleEClass, ContainerStyle.class, "ContainerStyle", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getContainerStyle_Name(), ecorePackage.getEString(), "name", null, 0, 1, ContainerStyle.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(containerFonctionsEClass, ContainerFonctions.class, "ContainerFonctions", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getContainerFonctions_Name(), ecorePackage.getEString(), "name", null, 0, 1, ContainerFonctions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(layoutEClass, Layout.class, "Layout", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getLayout_Name(), ecorePackage.getEString(), "name", null, 0, 1, Layout.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getLayout_Titre(), ecorePackage.getEString(), "titre", null, 0, 1, Layout.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getLayout_Contient(), this.getElements(), null, "contient", null, 0, -1, Layout.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getLayout_Style(), this.getStyleView(), null, "Style", null, 0, 1, Layout.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getLayout_StyleB(), this.getStyleView(), null, "StyleB", null, 0, 1, Layout.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(boutonEClass, Bouton.class, "Bouton", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getBouton_Name(), ecorePackage.getEString(), "name", null, 0, 1, Bouton.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getBouton_Icon(), this.getIcone(), null, "icon", null, 0, 1, Bouton.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getBouton_Onclique(), this.getfonction(), null, "onclique", null, 0, -1, Bouton.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getBouton_Onlongclique(), this.getfonction(), null, "onlongclique", null, 0, -1, Bouton.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getBouton_Prop(), this.getPropType(), "Prop", null, 0, 1, Bouton.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getBouton_IconRight(), this.getIconRightType(), "IconRight", null, 0, 1, Bouton.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getBouton_Ligne(), this.getLC(), "ligne", null, 0, 1, Bouton.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getBouton_Colonne(), this.getLC(), "colonne", null, 0, 1, Bouton.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getBouton_Style(), this.getStyleView(), null, "Style", null, 0, 1, Bouton.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(videoEClass, Video.class, "Video", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getVideo_UrlV(), ecorePackage.getEString(), "urlV", null, 0, 1, Video.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getVideo_Mutte(), this.getmut(), "mutte", null, 0, 1, Video.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getVideo_Widtht(), this.getentier(), "widtht", null, 0, 1, Video.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getVideo_Heightr(), this.getentier(), "heightr", null, 0, 1, Video.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getVideo_LigneAudio(), this.getLC(), "ligneAudio", null, 0, 1, Video.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getVideo_ColoneAudio(), this.getLC(), "coloneAudio", null, 0, 1, Video.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(audioEClass, Audio.class, "Audio", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getAudio_UrlT(), ecorePackage.getEString(), "urlT", null, 0, 1, Audio.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getAudio_Textbout(), ecorePackage.getEString(), "Textbout", null, 0, 1, Audio.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getAudio_LigneAudio(), this.getLC(), "ligneAudio", null, 0, 1, Audio.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getAudio_ColoneAudio(), this.getLC(), "coloneAudio", null, 0, 1, Audio.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getAudio_StyleAudio(), this.getStyleView(), null, "StyleAudio", null, 0, 1, Audio.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(mapViewEClass, MapView.class, "MapView", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getMapView_Latitude(), ecorePackage.getEBigDecimal(), "latitude", null, 0, 1, MapView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMapView_Longitude(), ecorePackage.getEBigDecimal(), "longitude", null, 0, 1, MapView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMapView_LatitudeDelta(), ecorePackage.getEBigDecimal(), "latitudeDelta", null, 0, 1, MapView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMapView_LongitudeDelta(), ecorePackage.getEBigDecimal(), "longitudeDelta", null, 0, 1, MapView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMapView_Ligne(), this.getLC(), "ligne", null, 0, 1, MapView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMapView_Colone(), this.getLC(), "colone", null, 0, 1, MapView.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(imageEClass, Image.class, "Image", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getImage_Url(), ecorePackage.getEString(), "Url", null, 0, 1, Image.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getImage_Ligne(), this.getLC(), "ligne", null, 0, 1, Image.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getImage_Colone(), this.getLC(), "colone", null, 0, 1, Image.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getImage_Style(), this.getStyleImage(), null, "style", null, 0, 1, Image.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(modelEClass, Model.class, "Model", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

    initEClass(tableDefinitionEClass, TableDefinition.class, "TableDefinition", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getTableDefinition_Name(), ecorePackage.getEString(), "name", null, 0, 1, TableDefinition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getTableDefinition_Champ(), this.getInput(), null, "champ", null, 0, -1, TableDefinition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    // Initialize enums and add enum literals
    initEEnum(oneEEnum, One.class, "One");
    addEEnumLiteral(oneEEnum, One.WRAP);
    addEEnumLiteral(oneEEnum, One.NOWRAP);

    initEEnum(nineEEnum, Nine.class, "Nine");
    addEEnumLiteral(nineEEnum, Nine.NN);
    addEEnumLiteral(nineEEnum, Nine.UNDERLINE);
    addEEnumLiteral(nineEEnum, Nine.LINETHROUGH);

    initEEnum(eignthEEnum, Eignth.class, "Eignth");
    addEEnumLiteral(eignthEEnum, Eignth.ATO);
    addEEnumLiteral(eignthEEnum, Eignth.LEFT);
    addEEnumLiteral(eignthEEnum, Eignth.RIGHT);
    addEEnumLiteral(eignthEEnum, Eignth.CENTER);
    addEEnumLiteral(eignthEEnum, Eignth.JUSTIFY);

    initEEnum(threeEEnum, Three.class, "Three");
    addEEnumLiteral(threeEEnum, Three.NORMAL);
    addEEnumLiteral(threeEEnum, Three.ITALIC);

    initEEnum(foorEEnum, Foor.class, "Foor");
    addEEnumLiteral(foorEEnum, Foor.NRMAL);
    addEEnumLiteral(foorEEnum, Foor.BOLD);
    addEEnumLiteral(foorEEnum, Foor.A);
    addEEnumLiteral(foorEEnum, Foor.B);
    addEEnumLiteral(foorEEnum, Foor.C);
    addEEnumLiteral(foorEEnum, Foor.D);
    addEEnumLiteral(foorEEnum, Foor.E);
    addEEnumLiteral(foorEEnum, Foor.F);
    addEEnumLiteral(foorEEnum, Foor.G);
    addEEnumLiteral(foorEEnum, Foor.H);
    addEEnumLiteral(foorEEnum, Foor.I);

    initEEnum(colorsEEnum, Colors.class, "Colors");
    addEEnumLiteral(colorsEEnum, Colors.NONE);
    addEEnumLiteral(colorsEEnum, Colors.WHITE);
    addEEnumLiteral(colorsEEnum, Colors.RED);
    addEEnumLiteral(colorsEEnum, Colors.MOCCASIN);
    addEEnumLiteral(colorsEEnum, Colors.GREEN);
    addEEnumLiteral(colorsEEnum, Colors.LIGHTGRAY);
    addEEnumLiteral(colorsEEnum, Colors.ORANGERED);
    addEEnumLiteral(colorsEEnum, Colors.GOLD);
    addEEnumLiteral(colorsEEnum, Colors.FLORALWHITE);
    addEEnumLiteral(colorsEEnum, Colors.DODGERBLUE);
    addEEnumLiteral(colorsEEnum, Colors.DEEPPINK);
    addEEnumLiteral(colorsEEnum, Colors.DARKSALMON);
    addEEnumLiteral(colorsEEnum, Colors.DARKORANGE);
    addEEnumLiteral(colorsEEnum, Colors.DARKMAGENTA);
    addEEnumLiteral(colorsEEnum, Colors.DARKGREEN);
    addEEnumLiteral(colorsEEnum, Colors.DARKGRAY);
    addEEnumLiteral(colorsEEnum, Colors.DARKBLUE);
    addEEnumLiteral(colorsEEnum, Colors.CRIMSON);
    addEEnumLiteral(colorsEEnum, Colors.CHOCOLATE);
    addEEnumLiteral(colorsEEnum, Colors.CHARTREUSE);
    addEEnumLiteral(colorsEEnum, Colors.CADETBLUE);
    addEEnumLiteral(colorsEEnum, Colors.BROWN);
    addEEnumLiteral(colorsEEnum, Colors.BLUEVIOLET);
    addEEnumLiteral(colorsEEnum, Colors.BLUE);
    addEEnumLiteral(colorsEEnum, Colors.BLACK);
    addEEnumLiteral(colorsEEnum, Colors.AQUAMARINE);
    addEEnumLiteral(colorsEEnum, Colors.ALICEBLUE);
    addEEnumLiteral(colorsEEnum, Colors.YELLOW);
    addEEnumLiteral(colorsEEnum, Colors.PEACHPUFF);

    initEEnum(aliITEEnum, aliIT.class, "aliIT");
    addEEnumLiteral(aliITEEnum, aliIT.NONE);
    addEEnumLiteral(aliITEEnum, aliIT.FLEX);
    addEEnumLiteral(aliITEEnum, aliIT.FLEX1);
    addEEnumLiteral(aliITEEnum, aliIT.CNT);
    addEEnumLiteral(aliITEEnum, aliIT.STR);

    initEEnum(alfemEEnum, alfem.class, "alfem");
    addEEnumLiteral(alfemEEnum, alfem.NONE);
    addEEnumLiteral(alfemEEnum, alfem.AUT);
    addEEnumLiteral(alfemEEnum, alfem.FLEX2);
    addEEnumLiteral(alfemEEnum, alfem.FLEX3);
    addEEnumLiteral(alfemEEnum, alfem.CNN);
    addEEnumLiteral(alfemEEnum, alfem.SCH);

    initEEnum(borderstyEEnum, bordersty.class, "bordersty");
    addEEnumLiteral(borderstyEEnum, bordersty.NONE);
    addEEnumLiteral(borderstyEEnum, bordersty.SOLI);
    addEEnumLiteral(borderstyEEnum, bordersty.DOTTE);
    addEEnumLiteral(borderstyEEnum, bordersty.DASHE);

    initEEnum(textTypeEEnum, textType.class, "textType");
    addEEnumLiteral(textTypeEEnum, textType.STRING);
    addEEnumLiteral(textTypeEEnum, textType.INT);

    initEEnum(backnumEEnum, Backnum.class, "Backnum");
    addEEnumLiteral(backnumEEnum, Backnum.NONE);
    addEEnumLiteral(backnumEEnum, Backnum.VISIBL);
    addEEnumLiteral(backnumEEnum, Backnum.HIDDE);

    initEEnum(typeHEEnum, TypeH.class, "TypeH");
    addEEnumLiteral(typeHEEnum, TypeH.H1);
    addEEnumLiteral(typeHEEnum, TypeH.H2);
    addEEnumLiteral(typeHEEnum, TypeH.H3);
    addEEnumLiteral(typeHEEnum, TypeH.H4);
    addEEnumLiteral(typeHEEnum, TypeH.FONT_FAMILY);

    initEEnum(iconTypeEEnum, IconType.class, "IconType");
    addEEnumLiteral(iconTypeEEnum, IconType.OCTICON);
    addEEnumLiteral(iconTypeEEnum, IconType.MATERIAL);
    addEEnumLiteral(iconTypeEEnum, IconType.COMMUNITY);
    addEEnumLiteral(iconTypeEEnum, IconType.ZOCIAL);
    addEEnumLiteral(iconTypeEEnum, IconType.IONICON);
    addEEnumLiteral(iconTypeEEnum, IconType.FOUNDATION);
    addEEnumLiteral(iconTypeEEnum, IconType.EVILICON);
    addEEnumLiteral(iconTypeEEnum, IconType.ENTYPO);
    addEEnumLiteral(iconTypeEEnum, IconType.NONE);

    initEEnum(sizelistEEnum, sizelist.class, "sizelist");
    addEEnumLiteral(sizelistEEnum, sizelist.NONE);
    addEEnumLiteral(sizelistEEnum, sizelist.TAL);
    addEEnumLiteral(sizelistEEnum, sizelist.SMAL);

    initEEnum(socialIconTypeEEnum, SocialIconType.class, "SocialIconType");
    addEEnumLiteral(socialIconTypeEEnum, SocialIconType.NONE);
    addEEnumLiteral(socialIconTypeEEnum, SocialIconType.FACEBOOK);
    addEEnumLiteral(socialIconTypeEEnum, SocialIconType.TWITTER);
    addEEnumLiteral(socialIconTypeEEnum, SocialIconType.PINTEREST);
    addEEnumLiteral(socialIconTypeEEnum, SocialIconType.LINKEDIN);
    addEEnumLiteral(socialIconTypeEEnum, SocialIconType.YOUTUBE);
    addEEnumLiteral(socialIconTypeEEnum, SocialIconType.VIMEO);
    addEEnumLiteral(socialIconTypeEEnum, SocialIconType.TUMBLR);
    addEEnumLiteral(socialIconTypeEEnum, SocialIconType.INSTAGRAM);
    addEEnumLiteral(socialIconTypeEEnum, SocialIconType.QUORA);
    addEEnumLiteral(socialIconTypeEEnum, SocialIconType.FOURSQUARE);
    addEEnumLiteral(socialIconTypeEEnum, SocialIconType.WORDPRESS);
    addEEnumLiteral(socialIconTypeEEnum, SocialIconType.STUMBLEUPON);
    addEEnumLiteral(socialIconTypeEEnum, SocialIconType.GITHUB);
    addEEnumLiteral(socialIconTypeEEnum, SocialIconType.TWITCH);
    addEEnumLiteral(socialIconTypeEEnum, SocialIconType.MEDIUM);
    addEEnumLiteral(socialIconTypeEEnum, SocialIconType.SOUNDCLOUD);
    addEEnumLiteral(socialIconTypeEEnum, SocialIconType.GITLAB);
    addEEnumLiteral(socialIconTypeEEnum, SocialIconType.ANGELLIST);
    addEEnumLiteral(socialIconTypeEEnum, SocialIconType.CODEPEN);

    initEEnum(flexdEEnum, flexd.class, "flexd");
    addEEnumLiteral(flexdEEnum, flexd.NONE);
    addEEnumLiteral(flexdEEnum, flexd.RO);
    addEEnumLiteral(flexdEEnum, flexd.COL);

    initEEnum(mutEEnum, mut.class, "mut");
    addEEnumLiteral(mutEEnum, mut.FALSE);
    addEEnumLiteral(mutEEnum, mut.TRUE);

    initEEnum(buttonTypeEEnum, buttonType.class, "buttonType");
    addEEnumLiteral(buttonTypeEEnum, buttonType.NONE);
    addEEnumLiteral(buttonTypeEEnum, buttonType.TRUE);
    addEEnumLiteral(buttonTypeEEnum, buttonType.FALSE);

    initEEnum(raisedTypeEEnum, raisedType.class, "raisedType");
    addEEnumLiteral(raisedTypeEEnum, raisedType.NONE);
    addEEnumLiteral(raisedTypeEEnum, raisedType.TRUE);
    addEEnumLiteral(raisedTypeEEnum, raisedType.FALSE);

    initEEnum(propTypeEEnum, PropType.class, "PropType");
    addEEnumLiteral(propTypeEEnum, PropType.NONE);
    addEEnumLiteral(propTypeEEnum, PropType.RAISED);
    addEEnumLiteral(propTypeEEnum, PropType.LARGE);

    initEEnum(iconRightTypeEEnum, IconRightType.class, "IconRightType");
    addEEnumLiteral(iconRightTypeEEnum, IconRightType.NONE);
    addEEnumLiteral(iconRightTypeEEnum, IconRightType.TRUE);
    addEEnumLiteral(iconRightTypeEEnum, IconRightType.FALSE);

    initEEnum(justifyContentTypeEEnum, JustifyContentType.class, "JustifyContentType");
    addEEnumLiteral(justifyContentTypeEEnum, JustifyContentType.NONE);
    addEEnumLiteral(justifyContentTypeEEnum, JustifyContentType.CENTER);
    addEEnumLiteral(justifyContentTypeEEnum, JustifyContentType.FL);
    addEEnumLiteral(justifyContentTypeEEnum, JustifyContentType.FLE);
    addEEnumLiteral(justifyContentTypeEEnum, JustifyContentType.SPAC);
    addEEnumLiteral(justifyContentTypeEEnum, JustifyContentType.SPACE);

    initEEnum(entierEEnum, entier.class, "entier");
    addEEnumLiteral(entierEEnum, entier.NONE);
    addEEnumLiteral(entierEEnum, entier.UN);
    addEEnumLiteral(entierEEnum, entier.DEUX);
    addEEnumLiteral(entierEEnum, entier.TROIS);
    addEEnumLiteral(entierEEnum, entier.QUTRE);
    addEEnumLiteral(entierEEnum, entier.CINQ);
    addEEnumLiteral(entierEEnum, entier.SIX);
    addEEnumLiteral(entierEEnum, entier.SEPT);
    addEEnumLiteral(entierEEnum, entier.HUITE);
    addEEnumLiteral(entierEEnum, entier.NF);
    addEEnumLiteral(entierEEnum, entier.DIX);
    addEEnumLiteral(entierEEnum, entier.EN);
    addEEnumLiteral(entierEEnum, entier.DZ);
    addEEnumLiteral(entierEEnum, entier.TR);
    addEEnumLiteral(entierEEnum, entier.QUAT);
    addEEnumLiteral(entierEEnum, entier.QZ);
    addEEnumLiteral(entierEEnum, entier.SZ);
    addEEnumLiteral(entierEEnum, entier.DS);
    addEEnumLiteral(entierEEnum, entier.DH);
    addEEnumLiteral(entierEEnum, entier.DN);
    addEEnumLiteral(entierEEnum, entier.VN);
    addEEnumLiteral(entierEEnum, entier.VI);
    addEEnumLiteral(entierEEnum, entier.VD);
    addEEnumLiteral(entierEEnum, entier.VT);
    addEEnumLiteral(entierEEnum, entier.VQ);
    addEEnumLiteral(entierEEnum, entier.VS);

    initEEnum(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.class, "LC");
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.UN);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.DEUX);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.TROIS);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.QUTRE);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.CINQ);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.SIX);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.SEPT);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.HUITE);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.NF);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.DIX);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.EN);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.DZ);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.TR);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.QUAT);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.QZ);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.SZ);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.DS);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.DH);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.DN);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.VN);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.VI);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.VD);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.VT);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.VQ);
    addEEnumLiteral(lcEEnum, org.xtext.UnivTlemcen.pfe.pfe.LC.VS);

    // Create resource
    createResource(eNS_URI);
  }

} //PfePackageImpl
