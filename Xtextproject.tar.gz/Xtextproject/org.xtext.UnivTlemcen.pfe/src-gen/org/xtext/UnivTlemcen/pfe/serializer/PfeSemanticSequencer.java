package org.xtext.UnivTlemcen.pfe.serializer;

import com.google.inject.Inject;
import com.google.inject.Provider;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.serializer.acceptor.ISemanticSequenceAcceptor;
import org.eclipse.xtext.serializer.acceptor.SequenceFeeder;
import org.eclipse.xtext.serializer.diagnostic.ISemanticSequencerDiagnosticProvider;
import org.eclipse.xtext.serializer.diagnostic.ISerializationDiagnostic.Acceptor;
import org.eclipse.xtext.serializer.sequencer.AbstractDelegatingSemanticSequencer;
import org.eclipse.xtext.serializer.sequencer.GenericSequencer;
import org.eclipse.xtext.serializer.sequencer.ISemanticNodeProvider.INodesForEObjectProvider;
import org.eclipse.xtext.serializer.sequencer.ISemanticSequencer;
import org.eclipse.xtext.serializer.sequencer.ITransientValueService;
import org.eclipse.xtext.serializer.sequencer.ITransientValueService.ValueTransient;
import org.xtext.UnivTlemcen.pfe.pfe.AlerteFonction;
import org.xtext.UnivTlemcen.pfe.pfe.Application;
import org.xtext.UnivTlemcen.pfe.pfe.Audio;
import org.xtext.UnivTlemcen.pfe.pfe.Bouton;
import org.xtext.UnivTlemcen.pfe.pfe.CheckBox;
import org.xtext.UnivTlemcen.pfe.pfe.ContainerFonctions;
import org.xtext.UnivTlemcen.pfe.pfe.ContainerStyle;
import org.xtext.UnivTlemcen.pfe.pfe.Heading;
import org.xtext.UnivTlemcen.pfe.pfe.Icone;
import org.xtext.UnivTlemcen.pfe.pfe.Image;
import org.xtext.UnivTlemcen.pfe.pfe.Input;
import org.xtext.UnivTlemcen.pfe.pfe.Layout;
import org.xtext.UnivTlemcen.pfe.pfe.MapView;
import org.xtext.UnivTlemcen.pfe.pfe.Navigate;
import org.xtext.UnivTlemcen.pfe.pfe.PfePackage;
import org.xtext.UnivTlemcen.pfe.pfe.RadioButton;
import org.xtext.UnivTlemcen.pfe.pfe.RemplirTable;
import org.xtext.UnivTlemcen.pfe.pfe.SocialIcon;
import org.xtext.UnivTlemcen.pfe.pfe.StyleImage;
import org.xtext.UnivTlemcen.pfe.pfe.StyleText;
import org.xtext.UnivTlemcen.pfe.pfe.StyleView;
import org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox;
import org.xtext.UnivTlemcen.pfe.pfe.Tab;
import org.xtext.UnivTlemcen.pfe.pfe.TableDefinition;
import org.xtext.UnivTlemcen.pfe.pfe.Text;
import org.xtext.UnivTlemcen.pfe.pfe.Video;
import org.xtext.UnivTlemcen.pfe.pfe.listView;
import org.xtext.UnivTlemcen.pfe.services.PfeGrammarAccess;

@SuppressWarnings("all")
public class PfeSemanticSequencer extends AbstractDelegatingSemanticSequencer {

	@Inject
	private PfeGrammarAccess grammarAccess;
	
	public void createSequence(EObject context, EObject semanticObject) {
		if(semanticObject.eClass().getEPackage() == PfePackage.eINSTANCE) switch(semanticObject.eClass().getClassifierID()) {
			case PfePackage.ALERTE_FONCTION:
				if(context == grammarAccess.getAlerteFonctionRule() ||
				   context == grammarAccess.getControleurRule() ||
				   context == grammarAccess.getFonctionsRule() ||
				   context == grammarAccess.getFonctionRule()) {
					sequence_AlerteFonction(context, (AlerteFonction) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.APPLICATION:
				if(context == grammarAccess.getApplicationRule()) {
					sequence_Application(context, (Application) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.AUDIO:
				if(context == grammarAccess.getAudioRule() ||
				   context == grammarAccess.getElementsRule() ||
				   context == grammarAccess.getVueRule() ||
				   context == grammarAccess.getComposantRule()) {
					sequence_Audio(context, (Audio) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.BOUTON:
				if(context == grammarAccess.getBoutonRule() ||
				   context == grammarAccess.getElementsRule() ||
				   context == grammarAccess.getVueRule()) {
					sequence_Bouton(context, (Bouton) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.CHECK_BOX:
				if(context == grammarAccess.getCheckBoxRule() ||
				   context == grammarAccess.getElementsRule() ||
				   context == grammarAccess.getVueRule()) {
					sequence_CheckBox(context, (CheckBox) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.CONTAINER_FONCTIONS:
				if(context == grammarAccess.getContainerFonctionsRule() ||
				   context == grammarAccess.getElementsRule() ||
				   context == grammarAccess.getVueRule()) {
					sequence_ContainerFonctions(context, (ContainerFonctions) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.CONTAINER_STYLE:
				if(context == grammarAccess.getContainerStyleRule() ||
				   context == grammarAccess.getElementsRule() ||
				   context == grammarAccess.getVueRule()) {
					sequence_ContainerStyle(context, (ContainerStyle) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.HEADING:
				if(context == grammarAccess.getElementsRule() ||
				   context == grammarAccess.getHeadingRule() ||
				   context == grammarAccess.getVueRule()) {
					sequence_Heading(context, (Heading) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.ICONE:
				if(context == grammarAccess.getElementsRule() ||
				   context == grammarAccess.getIconeRule() ||
				   context == grammarAccess.getIconsRule() ||
				   context == grammarAccess.getVueRule()) {
					sequence_Icone(context, (Icone) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.IMAGE:
				if(context == grammarAccess.getElementsRule() ||
				   context == grammarAccess.getImageRule() ||
				   context == grammarAccess.getVueRule() ||
				   context == grammarAccess.getComposantRule()) {
					sequence_Image(context, (Image) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.INPUT:
				if(context == grammarAccess.getElementsRule() ||
				   context == grammarAccess.getFormsRule() ||
				   context == grammarAccess.getInputRule() ||
				   context == grammarAccess.getVueRule()) {
					sequence_Input(context, (Input) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.LAYOUT:
				if(context == grammarAccess.getElementsRule() ||
				   context == grammarAccess.getLayoutRule() ||
				   context == grammarAccess.getVueRule()) {
					sequence_Layout(context, (Layout) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.MAP_VIEW:
				if(context == grammarAccess.getElementsRule() ||
				   context == grammarAccess.getMapViewRule() ||
				   context == grammarAccess.getVueRule() ||
				   context == grammarAccess.getComposantRule()) {
					sequence_MapView(context, (MapView) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.NAVIGATE:
				if(context == grammarAccess.getControleurRule() ||
				   context == grammarAccess.getFonctionsRule() ||
				   context == grammarAccess.getNavigateRule() ||
				   context == grammarAccess.getFonctionRule()) {
					sequence_Navigate(context, (Navigate) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.RADIO_BUTTON:
				if(context == grammarAccess.getElementsRule() ||
				   context == grammarAccess.getRadioButtonRule() ||
				   context == grammarAccess.getVueRule()) {
					sequence_RadioButton(context, (RadioButton) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.REMPLIR_TABLE:
				if(context == grammarAccess.getControleurRule() ||
				   context == grammarAccess.getFonctionsRule() ||
				   context == grammarAccess.getRemplirTableRule() ||
				   context == grammarAccess.getFonctionRule()) {
					sequence_RemplirTable(context, (RemplirTable) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.SOCIAL_ICON:
				if(context == grammarAccess.getElementsRule() ||
				   context == grammarAccess.getIconsRule() ||
				   context == grammarAccess.getSocialIconRule() ||
				   context == grammarAccess.getVueRule()) {
					sequence_SocialIcon(context, (SocialIcon) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.STYLE_IMAGE:
				if(context == grammarAccess.getControleurRule() ||
				   context == grammarAccess.getFonctionsRule() ||
				   context == grammarAccess.getStyleImageRule() ||
				   context == grammarAccess.getStylesheetRule()) {
					sequence_StyleImage(context, (StyleImage) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.STYLE_TEXT:
				if(context == grammarAccess.getControleurRule() ||
				   context == grammarAccess.getFonctionsRule() ||
				   context == grammarAccess.getStyleTextRule() ||
				   context == grammarAccess.getStylesheetRule()) {
					sequence_StyleText(context, (StyleText) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.STYLE_VIEW:
				if(context == grammarAccess.getControleurRule() ||
				   context == grammarAccess.getFonctionsRule() ||
				   context == grammarAccess.getStyleViewRule() ||
				   context == grammarAccess.getStylesheetRule()) {
					sequence_StyleView(context, (StyleView) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.STYLEFLEXBOX:
				if(context == grammarAccess.getControleurRule() ||
				   context == grammarAccess.getFonctionsRule() ||
				   context == grammarAccess.getStyleflexboxRule() ||
				   context == grammarAccess.getStylesheetRule()) {
					sequence_Styleflexbox(context, (Styleflexbox) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.TAB:
				if(context == grammarAccess.getElementsRule() ||
				   context == grammarAccess.getTabRule() ||
				   context == grammarAccess.getVueRule()) {
					sequence_Tab(context, (Tab) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.TABLE_DEFINITION:
				if(context == grammarAccess.getModelRule() ||
				   context == grammarAccess.getTableRule()) {
					sequence_Table(context, (TableDefinition) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.TEXT:
				if(context == grammarAccess.getElementsRule() ||
				   context == grammarAccess.getFormsRule() ||
				   context == grammarAccess.getTextRule() ||
				   context == grammarAccess.getVueRule()) {
					sequence_Text(context, (Text) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.VIDEO:
				if(context == grammarAccess.getElementsRule() ||
				   context == grammarAccess.getVideoRule() ||
				   context == grammarAccess.getVueRule() ||
				   context == grammarAccess.getComposantRule()) {
					sequence_Video(context, (Video) semanticObject); 
					return; 
				}
				else break;
			case PfePackage.LIST_VIEW:
				if(context == grammarAccess.getElementsRule() ||
				   context == grammarAccess.getVueRule() ||
				   context == grammarAccess.getListViewRule() ||
				   context == grammarAccess.getListsRule()) {
					sequence_listView(context, (listView) semanticObject); 
					return; 
				}
				else break;
			}
		if (errorAcceptor != null) errorAcceptor.accept(diagnosticProvider.createInvalidContextOrTypeDiagnostic(semanticObject, context));
	}
	
	/**
	 * Constraint:
	 *     (name=ID message=ID)
	 */
	protected void sequence_AlerteFonction(EObject context, AlerteFonction semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.FONCTIONS__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.FONCTIONS__NAME));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.ALERTE_FONCTION__MESSAGE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.ALERTE_FONCTION__MESSAGE));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getAlerteFonctionAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.accept(grammarAccess.getAlerteFonctionAccess().getMessageIDTerminalRuleCall_3_2_0(), semanticObject.getMessage());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=STRING 
	 *         packageName=STRING 
	 *         FirstLayout+=[Layout|ID]? 
	 *         model+=Model* 
	 *         vue+=Vue* 
	 *         controleur+=Controleur+
	 *     )
	 */
	protected void sequence_Application(EObject context, Application semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         urlT=STRING 
	 *         Textbout=ID 
	 *         ligneAudio=LC 
	 *         coloneAudio=LC 
	 *         StyleAudio=[StyleView|ID]?
	 *     )
	 */
	protected void sequence_Audio(EObject context, Audio semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         icon=[Icone|ID] 
	 *         onclique+=[fonction|ID] 
	 *         onclique+=[fonction|ID]* 
	 *         onlongclique+=[fonction|ID] 
	 *         onlongclique+=[fonction|ID]* 
	 *         Prop=PropType 
	 *         IconRight=IconRightType 
	 *         ligne=LC 
	 *         colonne=LC 
	 *         Style=[StyleView|ID]?
	 *     )
	 */
	protected void sequence_Bouton(EObject context, Bouton semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID? ligne=LC colonne=LC Style=[StyleView|ID]?)
	 */
	protected void sequence_CheckBox(EObject context, CheckBox semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     name=ID
	 */
	protected void sequence_ContainerFonctions(EObject context, ContainerFonctions semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.CONTAINER_FONCTIONS__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.CONTAINER_FONCTIONS__NAME));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getContainerFonctionsAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     name=ID
	 */
	protected void sequence_ContainerStyle(EObject context, ContainerStyle semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.CONTAINER_STYLE__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.CONTAINER_STYLE__NAME));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getContainerStyleAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID? type=TypeH? ligne=LC colonne=LC)
	 */
	protected void sequence_Heading(EObject context, Heading semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID? type=IconType ligne=LC colonne=LC Style=[StyleView|ID]?)
	 */
	protected void sequence_Icone(EObject context, Icone semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID Url=STRING ligne=LC colone=LC style=[StyleImage|ID]?)
	 */
	protected void sequence_Image(EObject context, Image semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID? ligne=LC colonne=LC Style=[StyleText|ID]?)
	 */
	protected void sequence_Input(EObject context, Input semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         titre=ID 
	 *         contient+=[Elements|ID] 
	 *         contient+=[Elements|ID]* 
	 *         Style=[StyleView|ID]? 
	 *         StyleB=[StyleView|ID]?
	 *     )
	 */
	protected void sequence_Layout(EObject context, Layout semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         latitude=SignedNumber 
	 *         longitude=SignedNumber 
	 *         latitudeDelta=SignedNumber 
	 *         longitudeDelta=SignedNumber 
	 *         ligne=LC 
	 *         colone=LC
	 *     )
	 */
	protected void sequence_MapView(EObject context, MapView semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.COMPOSANT__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.COMPOSANT__NAME));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.MAP_VIEW__LATITUDE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.MAP_VIEW__LATITUDE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.MAP_VIEW__LONGITUDE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.MAP_VIEW__LONGITUDE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.MAP_VIEW__LATITUDE_DELTA) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.MAP_VIEW__LATITUDE_DELTA));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.MAP_VIEW__LONGITUDE_DELTA) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.MAP_VIEW__LONGITUDE_DELTA));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.MAP_VIEW__LIGNE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.MAP_VIEW__LIGNE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.MAP_VIEW__COLONE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.MAP_VIEW__COLONE));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getMapViewAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.accept(grammarAccess.getMapViewAccess().getLatitudeSignedNumberParserRuleCall_2_2_0(), semanticObject.getLatitude());
		feeder.accept(grammarAccess.getMapViewAccess().getLongitudeSignedNumberParserRuleCall_2_6_0(), semanticObject.getLongitude());
		feeder.accept(grammarAccess.getMapViewAccess().getLatitudeDeltaSignedNumberParserRuleCall_2_10_0(), semanticObject.getLatitudeDelta());
		feeder.accept(grammarAccess.getMapViewAccess().getLongitudeDeltaSignedNumberParserRuleCall_2_14_0(), semanticObject.getLongitudeDelta());
		feeder.accept(grammarAccess.getMapViewAccess().getLigneLCEnumRuleCall_2_18_0(), semanticObject.getLigne());
		feeder.accept(grammarAccess.getMapViewAccess().getColoneLCEnumRuleCall_2_22_0(), semanticObject.getColone());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID ref+=[Layout|ID] ref+=[Layout|ID]*)
	 */
	protected void sequence_Navigate(EObject context, Navigate semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID? ligne=LC colonne=LC Style=[StyleView|ID]?)
	 */
	protected void sequence_RadioButton(EObject context, RadioButton semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID utiliser+=[TableDefinition|ID] utiliser+=[TableDefinition|ID]*)
	 */
	protected void sequence_RemplirTable(EObject context, RemplirTable semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID? 
	 *         type=SocialIconType 
	 *         button=buttonType 
	 *         raised=raisedType 
	 *         onclique=[fonction|ID] 
	 *         onlongclique=[fonction|ID] 
	 *         ligne=LC 
	 *         colonne=LC 
	 *         Style=[StyleView|ID]?
	 *     )
	 */
	protected void sequence_SocialIcon(EObject context, SocialIcon semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         backfaceVisibility=Backnum 
	 *         backgroundColora=Colors 
	 *         borderBottomLeftRadiusa=entier 
	 *         borderBottomRightRadiusa=entier 
	 *         borderColora=Colors 
	 *         borderRadiusa=entier 
	 *         borderTopLeftRadiusa=entier 
	 *         borderTopRightRadiusa=entier 
	 *         borderWidtha=entier 
	 *         opacitya=entier 
	 *         overflowa=entier 
	 *         alignItemst=aliIT 
	 *         alignSelft=alfem 
	 *         bottomt=entier 
	 *         flext=entier 
	 *         justifyContente=JustifyContentType 
	 *         lefte=entier 
	 *         margin=entier 
	 *         marginBottome=entier 
	 *         marginLefte=entier 
	 *         marginRighte=entier 
	 *         marginTope=entier 
	 *         marginVerticale=entier 
	 *         paddingt=entier 
	 *         paddingBottomt=entier 
	 *         paddingHorizontale=entier 
	 *         paddingRighte=entier 
	 *         paddingTope=entier 
	 *         paddingVerticale=entier 
	 *         rightt=entier 
	 *         widtht=entier 
	 *         flexDirectiont=flexd 
	 *         flexWrapt=One 
	 *         heighte=entier
	 *     )
	 */
	protected void sequence_StyleImage(EObject context, StyleImage semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.FONCTIONS__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.FONCTIONS__NAME));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__BACKFACE_VISIBILITY) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__BACKFACE_VISIBILITY));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__BACKGROUND_COLORA) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__BACKGROUND_COLORA));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__BORDER_BOTTOM_LEFT_RADIUSA) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__BORDER_BOTTOM_LEFT_RADIUSA));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__BORDER_BOTTOM_RIGHT_RADIUSA) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__BORDER_BOTTOM_RIGHT_RADIUSA));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__BORDER_COLORA) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__BORDER_COLORA));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__BORDER_RADIUSA) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__BORDER_RADIUSA));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__BORDER_TOP_LEFT_RADIUSA) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__BORDER_TOP_LEFT_RADIUSA));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__BORDER_TOP_RIGHT_RADIUSA) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__BORDER_TOP_RIGHT_RADIUSA));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__BORDER_WIDTHA) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__BORDER_WIDTHA));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__OPACITYA) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__OPACITYA));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__OVERFLOWA) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__OVERFLOWA));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__ALIGN_ITEMST) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__ALIGN_ITEMST));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__ALIGN_SELFT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__ALIGN_SELFT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__BOTTOMT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__BOTTOMT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__FLEXT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__FLEXT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__JUSTIFY_CONTENTE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__JUSTIFY_CONTENTE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__LEFTE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__LEFTE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__MARGIN) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__MARGIN));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__MARGIN_BOTTOME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__MARGIN_BOTTOME));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__MARGIN_LEFTE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__MARGIN_LEFTE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__MARGIN_RIGHTE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__MARGIN_RIGHTE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__MARGIN_TOPE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__MARGIN_TOPE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__MARGIN_VERTICALE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__MARGIN_VERTICALE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__PADDINGT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__PADDINGT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__PADDING_BOTTOMT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__PADDING_BOTTOMT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__PADDING_HORIZONTALE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__PADDING_HORIZONTALE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__PADDING_RIGHTE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__PADDING_RIGHTE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__PADDING_TOPE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__PADDING_TOPE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__PADDING_VERTICALE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__PADDING_VERTICALE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__RIGHTT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__RIGHTT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__WIDTHT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__WIDTHT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__FLEX_DIRECTIONT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__FLEX_DIRECTIONT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__FLEX_WRAPT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__FLEX_WRAPT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_IMAGE__HEIGHTE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_IMAGE__HEIGHTE));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getStyleImageAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.accept(grammarAccess.getStyleImageAccess().getBackfaceVisibilityBacknumEnumRuleCall_2_2_0(), semanticObject.getBackfaceVisibility());
		feeder.accept(grammarAccess.getStyleImageAccess().getBackgroundColoraColorsEnumRuleCall_2_6_0(), semanticObject.getBackgroundColora());
		feeder.accept(grammarAccess.getStyleImageAccess().getBorderBottomLeftRadiusaEntierEnumRuleCall_2_10_0(), semanticObject.getBorderBottomLeftRadiusa());
		feeder.accept(grammarAccess.getStyleImageAccess().getBorderBottomRightRadiusaEntierEnumRuleCall_2_14_0(), semanticObject.getBorderBottomRightRadiusa());
		feeder.accept(grammarAccess.getStyleImageAccess().getBorderColoraColorsEnumRuleCall_2_18_0(), semanticObject.getBorderColora());
		feeder.accept(grammarAccess.getStyleImageAccess().getBorderRadiusaEntierEnumRuleCall_2_22_0(), semanticObject.getBorderRadiusa());
		feeder.accept(grammarAccess.getStyleImageAccess().getBorderTopLeftRadiusaEntierEnumRuleCall_2_26_0(), semanticObject.getBorderTopLeftRadiusa());
		feeder.accept(grammarAccess.getStyleImageAccess().getBorderTopRightRadiusaEntierEnumRuleCall_2_30_0(), semanticObject.getBorderTopRightRadiusa());
		feeder.accept(grammarAccess.getStyleImageAccess().getBorderWidthaEntierEnumRuleCall_2_34_0(), semanticObject.getBorderWidtha());
		feeder.accept(grammarAccess.getStyleImageAccess().getOpacityaEntierEnumRuleCall_2_38_0(), semanticObject.getOpacitya());
		feeder.accept(grammarAccess.getStyleImageAccess().getOverflowaEntierEnumRuleCall_2_42_0(), semanticObject.getOverflowa());
		feeder.accept(grammarAccess.getStyleImageAccess().getAlignItemstAliITEnumRuleCall_2_46_0(), semanticObject.getAlignItemst());
		feeder.accept(grammarAccess.getStyleImageAccess().getAlignSelftAlfemEnumRuleCall_2_50_0(), semanticObject.getAlignSelft());
		feeder.accept(grammarAccess.getStyleImageAccess().getBottomtEntierEnumRuleCall_2_54_0(), semanticObject.getBottomt());
		feeder.accept(grammarAccess.getStyleImageAccess().getFlextEntierEnumRuleCall_2_58_0(), semanticObject.getFlext());
		feeder.accept(grammarAccess.getStyleImageAccess().getJustifyContenteJustifyContentTypeEnumRuleCall_2_62_0(), semanticObject.getJustifyContente());
		feeder.accept(grammarAccess.getStyleImageAccess().getLefteEntierEnumRuleCall_2_66_0(), semanticObject.getLefte());
		feeder.accept(grammarAccess.getStyleImageAccess().getMarginEntierEnumRuleCall_2_70_0(), semanticObject.getMargin());
		feeder.accept(grammarAccess.getStyleImageAccess().getMarginBottomeEntierEnumRuleCall_2_74_0(), semanticObject.getMarginBottome());
		feeder.accept(grammarAccess.getStyleImageAccess().getMarginLefteEntierEnumRuleCall_2_78_0(), semanticObject.getMarginLefte());
		feeder.accept(grammarAccess.getStyleImageAccess().getMarginRighteEntierEnumRuleCall_2_82_0(), semanticObject.getMarginRighte());
		feeder.accept(grammarAccess.getStyleImageAccess().getMarginTopeEntierEnumRuleCall_2_86_0(), semanticObject.getMarginTope());
		feeder.accept(grammarAccess.getStyleImageAccess().getMarginVerticaleEntierEnumRuleCall_2_90_0(), semanticObject.getMarginVerticale());
		feeder.accept(grammarAccess.getStyleImageAccess().getPaddingtEntierEnumRuleCall_2_94_0(), semanticObject.getPaddingt());
		feeder.accept(grammarAccess.getStyleImageAccess().getPaddingBottomtEntierEnumRuleCall_2_98_0(), semanticObject.getPaddingBottomt());
		feeder.accept(grammarAccess.getStyleImageAccess().getPaddingHorizontaleEntierEnumRuleCall_2_102_0(), semanticObject.getPaddingHorizontale());
		feeder.accept(grammarAccess.getStyleImageAccess().getPaddingRighteEntierEnumRuleCall_2_106_0(), semanticObject.getPaddingRighte());
		feeder.accept(grammarAccess.getStyleImageAccess().getPaddingTopeEntierEnumRuleCall_2_110_0(), semanticObject.getPaddingTope());
		feeder.accept(grammarAccess.getStyleImageAccess().getPaddingVerticaleEntierEnumRuleCall_2_114_0(), semanticObject.getPaddingVerticale());
		feeder.accept(grammarAccess.getStyleImageAccess().getRighttEntierEnumRuleCall_2_118_0(), semanticObject.getRightt());
		feeder.accept(grammarAccess.getStyleImageAccess().getWidthtEntierEnumRuleCall_2_122_0(), semanticObject.getWidtht());
		feeder.accept(grammarAccess.getStyleImageAccess().getFlexDirectiontFlexdEnumRuleCall_2_126_0(), semanticObject.getFlexDirectiont());
		feeder.accept(grammarAccess.getStyleImageAccess().getFlexWraptOneEnumRuleCall_2_130_0(), semanticObject.getFlexWrapt());
		feeder.accept(grammarAccess.getStyleImageAccess().getHeighteEntierEnumRuleCall_2_134_0(), semanticObject.getHeighte());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         colore=Colors 
	 *         fontFamilyE=TypeH 
	 *         fontSizes=entier 
	 *         fontStyles=Three 
	 *         fontWeighte=Foor 
	 *         lineHeighte=entier 
	 *         TextAligne=Eignth 
	 *         backfaceVisibilitye=Backnum 
	 *         backgroundColore=Colors 
	 *         borderBottomColore=Colors 
	 *         borderBottomLeftRadiuse=entier 
	 *         borderBottomRightRadiuse=entier 
	 *         borderBottomWidthe=entier 
	 *         borderColore=Colors 
	 *         borderLeftColore=Colors 
	 *         borderLeftWidthe=entier 
	 *         borderRadiuse=entier 
	 *         borderRightColore=Colors 
	 *         borderRightWidth=entier 
	 *         borderStyles=bordersty 
	 *         borderTopColore=Colors 
	 *         borderTopLeftRadiuse=entier 
	 *         borderTopRightRadiuse=entier 
	 *         borderTopWidthe=entier 
	 *         borderWidthe=entier 
	 *         opacitye=entier
	 *     )
	 */
	protected void sequence_StyleText(EObject context, StyleText semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.FONCTIONS__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.FONCTIONS__NAME));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__COLORE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__COLORE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__FONT_FAMILY_E) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__FONT_FAMILY_E));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__FONT_SIZES) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__FONT_SIZES));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__FONT_STYLES) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__FONT_STYLES));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__FONT_WEIGHTE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__FONT_WEIGHTE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__LINE_HEIGHTE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__LINE_HEIGHTE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__TEXT_ALIGNE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__TEXT_ALIGNE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__BACKFACE_VISIBILITYE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__BACKFACE_VISIBILITYE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__BACKGROUND_COLORE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__BACKGROUND_COLORE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_BOTTOM_COLORE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_BOTTOM_COLORE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_BOTTOM_LEFT_RADIUSE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_BOTTOM_LEFT_RADIUSE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_BOTTOM_RIGHT_RADIUSE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_BOTTOM_RIGHT_RADIUSE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_BOTTOM_WIDTHE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_BOTTOM_WIDTHE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_COLORE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_COLORE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_LEFT_COLORE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_LEFT_COLORE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_LEFT_WIDTHE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_LEFT_WIDTHE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_RADIUSE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_RADIUSE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_RIGHT_COLORE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_RIGHT_COLORE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_RIGHT_WIDTH) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_RIGHT_WIDTH));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_STYLES) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_STYLES));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_TOP_COLORE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_TOP_COLORE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_TOP_LEFT_RADIUSE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_TOP_LEFT_RADIUSE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_TOP_RIGHT_RADIUSE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_TOP_RIGHT_RADIUSE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_TOP_WIDTHE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_TOP_WIDTHE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_WIDTHE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__BORDER_WIDTHE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_TEXT__OPACITYE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_TEXT__OPACITYE));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getStyleTextAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.accept(grammarAccess.getStyleTextAccess().getColoreColorsEnumRuleCall_2_2_0(), semanticObject.getColore());
		feeder.accept(grammarAccess.getStyleTextAccess().getFontFamilyETypeHEnumRuleCall_2_6_0(), semanticObject.getFontFamilyE());
		feeder.accept(grammarAccess.getStyleTextAccess().getFontSizesEntierEnumRuleCall_2_10_0(), semanticObject.getFontSizes());
		feeder.accept(grammarAccess.getStyleTextAccess().getFontStylesThreeEnumRuleCall_2_14_0(), semanticObject.getFontStyles());
		feeder.accept(grammarAccess.getStyleTextAccess().getFontWeighteFoorEnumRuleCall_2_18_0(), semanticObject.getFontWeighte());
		feeder.accept(grammarAccess.getStyleTextAccess().getLineHeighteEntierEnumRuleCall_2_22_0(), semanticObject.getLineHeighte());
		feeder.accept(grammarAccess.getStyleTextAccess().getTextAligneEignthEnumRuleCall_2_26_0(), semanticObject.getTextAligne());
		feeder.accept(grammarAccess.getStyleTextAccess().getBackfaceVisibilityeBacknumEnumRuleCall_2_30_0(), semanticObject.getBackfaceVisibilitye());
		feeder.accept(grammarAccess.getStyleTextAccess().getBackgroundColoreColorsEnumRuleCall_2_34_0(), semanticObject.getBackgroundColore());
		feeder.accept(grammarAccess.getStyleTextAccess().getBorderBottomColoreColorsEnumRuleCall_2_38_0(), semanticObject.getBorderBottomColore());
		feeder.accept(grammarAccess.getStyleTextAccess().getBorderBottomLeftRadiuseEntierEnumRuleCall_2_42_0(), semanticObject.getBorderBottomLeftRadiuse());
		feeder.accept(grammarAccess.getStyleTextAccess().getBorderBottomRightRadiuseEntierEnumRuleCall_2_46_0(), semanticObject.getBorderBottomRightRadiuse());
		feeder.accept(grammarAccess.getStyleTextAccess().getBorderBottomWidtheEntierEnumRuleCall_2_50_0(), semanticObject.getBorderBottomWidthe());
		feeder.accept(grammarAccess.getStyleTextAccess().getBorderColoreColorsEnumRuleCall_2_54_0(), semanticObject.getBorderColore());
		feeder.accept(grammarAccess.getStyleTextAccess().getBorderLeftColoreColorsEnumRuleCall_2_58_0(), semanticObject.getBorderLeftColore());
		feeder.accept(grammarAccess.getStyleTextAccess().getBorderLeftWidtheEntierEnumRuleCall_2_62_0(), semanticObject.getBorderLeftWidthe());
		feeder.accept(grammarAccess.getStyleTextAccess().getBorderRadiuseEntierEnumRuleCall_2_66_0(), semanticObject.getBorderRadiuse());
		feeder.accept(grammarAccess.getStyleTextAccess().getBorderRightColoreColorsEnumRuleCall_2_70_0(), semanticObject.getBorderRightColore());
		feeder.accept(grammarAccess.getStyleTextAccess().getBorderRightWidthEntierEnumRuleCall_2_74_0(), semanticObject.getBorderRightWidth());
		feeder.accept(grammarAccess.getStyleTextAccess().getBorderStylesBorderstyEnumRuleCall_2_78_0(), semanticObject.getBorderStyles());
		feeder.accept(grammarAccess.getStyleTextAccess().getBorderTopColoreColorsEnumRuleCall_2_82_0(), semanticObject.getBorderTopColore());
		feeder.accept(grammarAccess.getStyleTextAccess().getBorderTopLeftRadiuseEntierEnumRuleCall_2_86_0(), semanticObject.getBorderTopLeftRadiuse());
		feeder.accept(grammarAccess.getStyleTextAccess().getBorderTopRightRadiuseEntierEnumRuleCall_2_90_0(), semanticObject.getBorderTopRightRadiuse());
		feeder.accept(grammarAccess.getStyleTextAccess().getBorderTopWidtheEntierEnumRuleCall_2_94_0(), semanticObject.getBorderTopWidthe());
		feeder.accept(grammarAccess.getStyleTextAccess().getBorderWidtheEntierEnumRuleCall_2_98_0(), semanticObject.getBorderWidthe());
		feeder.accept(grammarAccess.getStyleTextAccess().getOpacityeEntierEnumRuleCall_2_102_0(), semanticObject.getOpacitye());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         backfaceVisibility2=Backnum 
	 *         backgroundColor2=Colors 
	 *         borderBottomColor2=Colors 
	 *         borderBottomLeftRadius2=entier 
	 *         borderBottomRightRadius2=entier 
	 *         borderBottomWidth2=entier 
	 *         borderColort=Colors 
	 *         borderLeftColort=Colors 
	 *         borderLeftWidtht=entier 
	 *         borderRadiust=entier 
	 *         borderRightColort=Colors 
	 *         borderRightWidtht=entier 
	 *         borderStylet=bordersty 
	 *         borderTopColort=Colors 
	 *         borderTopLeftRadiust=entier 
	 *         borderTopRightRadiust=entier 
	 *         borderTopWidtht=entier 
	 *         borderWidtht=entier 
	 *         opacityt=entier 
	 *         alignItemst=aliIT 
	 *         alignSelft=alfem 
	 *         bottomt=entier 
	 *         flext=entier 
	 *         flexDirectiont=flexd 
	 *         flexWrapt=One 
	 *         heighte=entier 
	 *         justifyContente=JustifyContentType 
	 *         lefte=entier 
	 *         margin=entier 
	 *         marginBottome=entier 
	 *         marginLefte=entier 
	 *         marginRighte=entier 
	 *         marginTope=entier 
	 *         marginVerticale=entier 
	 *         paddingt=entier 
	 *         paddingBottomt=entier 
	 *         paddingHorizontale=entier 
	 *         paddingRighte=entier 
	 *         paddingTope=entier 
	 *         paddingVerticale=entier 
	 *         rightt=entier 
	 *         widtht=entier
	 *     )
	 */
	protected void sequence_StyleView(EObject context, StyleView semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.FONCTIONS__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.FONCTIONS__NAME));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__BACKFACE_VISIBILITY2) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__BACKFACE_VISIBILITY2));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__BACKGROUND_COLOR2) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__BACKGROUND_COLOR2));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_BOTTOM_COLOR2) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_BOTTOM_COLOR2));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_BOTTOM_LEFT_RADIUS2) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_BOTTOM_LEFT_RADIUS2));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_BOTTOM_RIGHT_RADIUS2) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_BOTTOM_RIGHT_RADIUS2));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_BOTTOM_WIDTH2) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_BOTTOM_WIDTH2));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_COLORT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_COLORT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_LEFT_COLORT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_LEFT_COLORT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_LEFT_WIDTHT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_LEFT_WIDTHT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_RADIUST) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_RADIUST));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_RIGHT_COLORT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_RIGHT_COLORT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_RIGHT_WIDTHT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_RIGHT_WIDTHT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_STYLET) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_STYLET));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_TOP_COLORT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_TOP_COLORT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_TOP_LEFT_RADIUST) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_TOP_LEFT_RADIUST));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_TOP_RIGHT_RADIUST) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_TOP_RIGHT_RADIUST));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_TOP_WIDTHT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_TOP_WIDTHT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_WIDTHT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__BORDER_WIDTHT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__OPACITYT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__OPACITYT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__ALIGN_ITEMST) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__ALIGN_ITEMST));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__ALIGN_SELFT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__ALIGN_SELFT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__BOTTOMT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__BOTTOMT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__FLEXT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__FLEXT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__FLEX_DIRECTIONT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__FLEX_DIRECTIONT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__FLEX_WRAPT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__FLEX_WRAPT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__HEIGHTE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__HEIGHTE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__JUSTIFY_CONTENTE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__JUSTIFY_CONTENTE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__LEFTE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__LEFTE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__MARGIN) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__MARGIN));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__MARGIN_BOTTOME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__MARGIN_BOTTOME));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__MARGIN_LEFTE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__MARGIN_LEFTE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__MARGIN_RIGHTE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__MARGIN_RIGHTE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__MARGIN_TOPE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__MARGIN_TOPE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__MARGIN_VERTICALE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__MARGIN_VERTICALE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__PADDINGT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__PADDINGT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__PADDING_BOTTOMT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__PADDING_BOTTOMT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__PADDING_HORIZONTALE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__PADDING_HORIZONTALE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__PADDING_RIGHTE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__PADDING_RIGHTE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__PADDING_TOPE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__PADDING_TOPE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__PADDING_VERTICALE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__PADDING_VERTICALE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__RIGHTT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__RIGHTT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLE_VIEW__WIDTHT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLE_VIEW__WIDTHT));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getStyleViewAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.accept(grammarAccess.getStyleViewAccess().getBackfaceVisibility2BacknumEnumRuleCall_2_2_0(), semanticObject.getBackfaceVisibility2());
		feeder.accept(grammarAccess.getStyleViewAccess().getBackgroundColor2ColorsEnumRuleCall_2_6_0(), semanticObject.getBackgroundColor2());
		feeder.accept(grammarAccess.getStyleViewAccess().getBorderBottomColor2ColorsEnumRuleCall_2_10_0(), semanticObject.getBorderBottomColor2());
		feeder.accept(grammarAccess.getStyleViewAccess().getBorderBottomLeftRadius2EntierEnumRuleCall_2_14_0(), semanticObject.getBorderBottomLeftRadius2());
		feeder.accept(grammarAccess.getStyleViewAccess().getBorderBottomRightRadius2EntierEnumRuleCall_2_18_0(), semanticObject.getBorderBottomRightRadius2());
		feeder.accept(grammarAccess.getStyleViewAccess().getBorderBottomWidth2EntierEnumRuleCall_2_22_0(), semanticObject.getBorderBottomWidth2());
		feeder.accept(grammarAccess.getStyleViewAccess().getBorderColortColorsEnumRuleCall_2_26_0(), semanticObject.getBorderColort());
		feeder.accept(grammarAccess.getStyleViewAccess().getBorderLeftColortColorsEnumRuleCall_2_30_0(), semanticObject.getBorderLeftColort());
		feeder.accept(grammarAccess.getStyleViewAccess().getBorderLeftWidthtEntierEnumRuleCall_2_34_0(), semanticObject.getBorderLeftWidtht());
		feeder.accept(grammarAccess.getStyleViewAccess().getBorderRadiustEntierEnumRuleCall_2_38_0(), semanticObject.getBorderRadiust());
		feeder.accept(grammarAccess.getStyleViewAccess().getBorderRightColortColorsEnumRuleCall_2_42_0(), semanticObject.getBorderRightColort());
		feeder.accept(grammarAccess.getStyleViewAccess().getBorderRightWidthtEntierEnumRuleCall_2_46_0(), semanticObject.getBorderRightWidtht());
		feeder.accept(grammarAccess.getStyleViewAccess().getBorderStyletBorderstyEnumRuleCall_2_50_0(), semanticObject.getBorderStylet());
		feeder.accept(grammarAccess.getStyleViewAccess().getBorderTopColortColorsEnumRuleCall_2_54_0(), semanticObject.getBorderTopColort());
		feeder.accept(grammarAccess.getStyleViewAccess().getBorderTopLeftRadiustEntierEnumRuleCall_2_58_0(), semanticObject.getBorderTopLeftRadiust());
		feeder.accept(grammarAccess.getStyleViewAccess().getBorderTopRightRadiustEntierEnumRuleCall_2_62_0(), semanticObject.getBorderTopRightRadiust());
		feeder.accept(grammarAccess.getStyleViewAccess().getBorderTopWidthtEntierEnumRuleCall_2_66_0(), semanticObject.getBorderTopWidtht());
		feeder.accept(grammarAccess.getStyleViewAccess().getBorderWidthtEntierEnumRuleCall_2_70_0(), semanticObject.getBorderWidtht());
		feeder.accept(grammarAccess.getStyleViewAccess().getOpacitytEntierEnumRuleCall_2_74_0(), semanticObject.getOpacityt());
		feeder.accept(grammarAccess.getStyleViewAccess().getAlignItemstAliITEnumRuleCall_2_78_0(), semanticObject.getAlignItemst());
		feeder.accept(grammarAccess.getStyleViewAccess().getAlignSelftAlfemEnumRuleCall_2_82_0(), semanticObject.getAlignSelft());
		feeder.accept(grammarAccess.getStyleViewAccess().getBottomtEntierEnumRuleCall_2_86_0(), semanticObject.getBottomt());
		feeder.accept(grammarAccess.getStyleViewAccess().getFlextEntierEnumRuleCall_2_90_0(), semanticObject.getFlext());
		feeder.accept(grammarAccess.getStyleViewAccess().getFlexDirectiontFlexdEnumRuleCall_2_94_0(), semanticObject.getFlexDirectiont());
		feeder.accept(grammarAccess.getStyleViewAccess().getFlexWraptOneEnumRuleCall_2_98_0(), semanticObject.getFlexWrapt());
		feeder.accept(grammarAccess.getStyleViewAccess().getHeighteEntierEnumRuleCall_2_102_0(), semanticObject.getHeighte());
		feeder.accept(grammarAccess.getStyleViewAccess().getJustifyContenteJustifyContentTypeEnumRuleCall_2_106_0(), semanticObject.getJustifyContente());
		feeder.accept(grammarAccess.getStyleViewAccess().getLefteEntierEnumRuleCall_2_110_0(), semanticObject.getLefte());
		feeder.accept(grammarAccess.getStyleViewAccess().getMarginEntierEnumRuleCall_2_114_0(), semanticObject.getMargin());
		feeder.accept(grammarAccess.getStyleViewAccess().getMarginBottomeEntierEnumRuleCall_2_118_0(), semanticObject.getMarginBottome());
		feeder.accept(grammarAccess.getStyleViewAccess().getMarginLefteEntierEnumRuleCall_2_122_0(), semanticObject.getMarginLefte());
		feeder.accept(grammarAccess.getStyleViewAccess().getMarginRighteEntierEnumRuleCall_2_126_0(), semanticObject.getMarginRighte());
		feeder.accept(grammarAccess.getStyleViewAccess().getMarginTopeEntierEnumRuleCall_2_130_0(), semanticObject.getMarginTope());
		feeder.accept(grammarAccess.getStyleViewAccess().getMarginVerticaleEntierEnumRuleCall_2_134_0(), semanticObject.getMarginVerticale());
		feeder.accept(grammarAccess.getStyleViewAccess().getPaddingtEntierEnumRuleCall_2_138_0(), semanticObject.getPaddingt());
		feeder.accept(grammarAccess.getStyleViewAccess().getPaddingBottomtEntierEnumRuleCall_2_142_0(), semanticObject.getPaddingBottomt());
		feeder.accept(grammarAccess.getStyleViewAccess().getPaddingHorizontaleEntierEnumRuleCall_2_146_0(), semanticObject.getPaddingHorizontale());
		feeder.accept(grammarAccess.getStyleViewAccess().getPaddingRighteEntierEnumRuleCall_2_150_0(), semanticObject.getPaddingRighte());
		feeder.accept(grammarAccess.getStyleViewAccess().getPaddingTopeEntierEnumRuleCall_2_154_0(), semanticObject.getPaddingTope());
		feeder.accept(grammarAccess.getStyleViewAccess().getPaddingVerticaleEntierEnumRuleCall_2_158_0(), semanticObject.getPaddingVerticale());
		feeder.accept(grammarAccess.getStyleViewAccess().getRighttEntierEnumRuleCall_2_162_0(), semanticObject.getRightt());
		feeder.accept(grammarAccess.getStyleViewAccess().getWidthtEntierEnumRuleCall_2_166_0(), semanticObject.getWidtht());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         alignItems3=aliIT 
	 *         alignSelf3=alfem 
	 *         borderBottomWidth3=entier 
	 *         borderLeftWidth3=entier 
	 *         borderRightWidth3=entier 
	 *         borderTopWidth3=entier 
	 *         borderWidth3=entier 
	 *         bottom3=entier 
	 *         flex3=entier 
	 *         flexDirection3=flexd 
	 *         flexWrap3=One 
	 *         height3=entier 
	 *         justifyContent3=JustifyContentType 
	 *         left3=entier 
	 *         margin3=entier 
	 *         marginBottom3=entier 
	 *         marginLeft3=entier 
	 *         marginRight3=entier 
	 *         marginTop3=entier 
	 *         marginVertical3=entier 
	 *         pendding3=entier 
	 *         panddingB=entier
	 *     )
	 */
	protected void sequence_Styleflexbox(EObject context, Styleflexbox semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.FONCTIONS__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.FONCTIONS__NAME));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__ALIGN_ITEMS3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__ALIGN_ITEMS3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__ALIGN_SELF3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__ALIGN_SELF3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__BORDER_BOTTOM_WIDTH3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__BORDER_BOTTOM_WIDTH3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__BORDER_LEFT_WIDTH3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__BORDER_LEFT_WIDTH3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__BORDER_RIGHT_WIDTH3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__BORDER_RIGHT_WIDTH3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__BORDER_TOP_WIDTH3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__BORDER_TOP_WIDTH3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__BORDER_WIDTH3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__BORDER_WIDTH3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__BOTTOM3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__BOTTOM3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__FLEX3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__FLEX3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__FLEX_DIRECTION3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__FLEX_DIRECTION3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__FLEX_WRAP3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__FLEX_WRAP3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__HEIGHT3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__HEIGHT3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__JUSTIFY_CONTENT3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__JUSTIFY_CONTENT3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__LEFT3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__LEFT3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__MARGIN3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__MARGIN3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__MARGIN_BOTTOM3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__MARGIN_BOTTOM3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__MARGIN_LEFT3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__MARGIN_LEFT3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__MARGIN_RIGHT3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__MARGIN_RIGHT3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__MARGIN_TOP3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__MARGIN_TOP3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__MARGIN_VERTICAL3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__MARGIN_VERTICAL3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__PENDDING3) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__PENDDING3));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.STYLEFLEXBOX__PANDDING_B) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.STYLEFLEXBOX__PANDDING_B));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getStyleflexboxAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getAlignItems3AliITEnumRuleCall_2_2_0(), semanticObject.getAlignItems3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getAlignSelf3AlfemEnumRuleCall_2_6_0(), semanticObject.getAlignSelf3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getBorderBottomWidth3EntierEnumRuleCall_2_10_0(), semanticObject.getBorderBottomWidth3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getBorderLeftWidth3EntierEnumRuleCall_2_14_0(), semanticObject.getBorderLeftWidth3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getBorderRightWidth3EntierEnumRuleCall_2_18_0(), semanticObject.getBorderRightWidth3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getBorderTopWidth3EntierEnumRuleCall_2_22_0(), semanticObject.getBorderTopWidth3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getBorderWidth3EntierEnumRuleCall_2_26_0(), semanticObject.getBorderWidth3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getBottom3EntierEnumRuleCall_2_30_0(), semanticObject.getBottom3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getFlex3EntierEnumRuleCall_2_34_0(), semanticObject.getFlex3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getFlexDirection3FlexdEnumRuleCall_2_38_0(), semanticObject.getFlexDirection3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getFlexWrap3OneEnumRuleCall_2_42_0(), semanticObject.getFlexWrap3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getHeight3EntierEnumRuleCall_2_46_0(), semanticObject.getHeight3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getJustifyContent3JustifyContentTypeEnumRuleCall_2_50_0(), semanticObject.getJustifyContent3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getLeft3EntierEnumRuleCall_2_54_0(), semanticObject.getLeft3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getMargin3EntierEnumRuleCall_2_58_0(), semanticObject.getMargin3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getMarginBottom3EntierEnumRuleCall_2_62_0(), semanticObject.getMarginBottom3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getMarginLeft3EntierEnumRuleCall_2_66_0(), semanticObject.getMarginLeft3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getMarginRight3EntierEnumRuleCall_2_70_0(), semanticObject.getMarginRight3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getMarginTop3EntierEnumRuleCall_2_74_0(), semanticObject.getMarginTop3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getMarginVertical3EntierEnumRuleCall_2_78_0(), semanticObject.getMarginVertical3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getPendding3EntierEnumRuleCall_2_82_0(), semanticObject.getPendding3());
		feeder.accept(grammarAccess.getStyleflexboxAccess().getPanddingBEntierEnumRuleCall_2_86_0(), semanticObject.getPanddingB());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID? 
	 *         title=ID 
	 *         text=textType 
	 *         icon=Icone 
	 *         elements+=Elements 
	 *         ligne=LC 
	 *         colonne=LC
	 *     )
	 */
	protected void sequence_Tab(EObject context, Tab semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID champ+=[Input|ID] champ+=[Input|ID]*)
	 */
	protected void sequence_Table(EObject context, TableDefinition semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID? contenu=ID ligne=LC colonne=LC Style=[StyleView|ID]?)
	 */
	protected void sequence_Text(EObject context, Text semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         urlV=STRING 
	 *         mutte=mut 
	 *         widtht=entier 
	 *         heightr=entier 
	 *         ligneAudio=LC 
	 *         coloneAudio=LC
	 *     )
	 */
	protected void sequence_Video(EObject context, Video semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.COMPOSANT__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.COMPOSANT__NAME));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.VIDEO__URL_V) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.VIDEO__URL_V));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.VIDEO__MUTTE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.VIDEO__MUTTE));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.VIDEO__WIDTHT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.VIDEO__WIDTHT));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.VIDEO__HEIGHTR) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.VIDEO__HEIGHTR));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.VIDEO__LIGNE_AUDIO) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.VIDEO__LIGNE_AUDIO));
			if(transientValues.isValueTransient(semanticObject, PfePackage.Literals.VIDEO__COLONE_AUDIO) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, PfePackage.Literals.VIDEO__COLONE_AUDIO));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getVideoAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.accept(grammarAccess.getVideoAccess().getUrlVSTRINGTerminalRuleCall_2_2_0(), semanticObject.getUrlV());
		feeder.accept(grammarAccess.getVideoAccess().getMutteMutEnumRuleCall_2_6_0(), semanticObject.getMutte());
		feeder.accept(grammarAccess.getVideoAccess().getWidthtEntierEnumRuleCall_2_10_0(), semanticObject.getWidtht());
		feeder.accept(grammarAccess.getVideoAccess().getHeightrEntierEnumRuleCall_2_14_0(), semanticObject.getHeightr());
		feeder.accept(grammarAccess.getVideoAccess().getLigneAudioLCEnumRuleCall_2_18_0(), semanticObject.getLigneAudio());
		feeder.accept(grammarAccess.getVideoAccess().getColoneAudioLCEnumRuleCall_2_22_0(), semanticObject.getColoneAudio());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID? 
	 *         utiliser+=[TableDefinition|ID] 
	 *         utiliser+=[TableDefinition|ID]* 
	 *         ligne=LC 
	 *         colonne=LC 
	 *         Style=[StyleText|ID]?
	 *     )
	 */
	protected void sequence_listView(EObject context, listView semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
}
