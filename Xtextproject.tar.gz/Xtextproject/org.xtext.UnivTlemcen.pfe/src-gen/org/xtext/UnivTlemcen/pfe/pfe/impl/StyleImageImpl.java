/**
 */
package org.xtext.UnivTlemcen.pfe.pfe.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.xtext.UnivTlemcen.pfe.pfe.Backnum;
import org.xtext.UnivTlemcen.pfe.pfe.Colors;
import org.xtext.UnivTlemcen.pfe.pfe.JustifyContentType;
import org.xtext.UnivTlemcen.pfe.pfe.One;
import org.xtext.UnivTlemcen.pfe.pfe.PfePackage;
import org.xtext.UnivTlemcen.pfe.pfe.StyleImage;
import org.xtext.UnivTlemcen.pfe.pfe.alfem;
import org.xtext.UnivTlemcen.pfe.pfe.aliIT;
import org.xtext.UnivTlemcen.pfe.pfe.entier;
import org.xtext.UnivTlemcen.pfe.pfe.flexd;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Style Image</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getBackfaceVisibility <em>Backface Visibility</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getBackgroundColora <em>Background Colora</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getBorderBottomLeftRadiusa <em>Border Bottom Left Radiusa</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getBorderBottomRightRadiusa <em>Border Bottom Right Radiusa</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getBorderColora <em>Border Colora</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getBorderRadiusa <em>Border Radiusa</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getBorderTopLeftRadiusa <em>Border Top Left Radiusa</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getBorderTopRightRadiusa <em>Border Top Right Radiusa</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getBorderWidtha <em>Border Widtha</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getOpacitya <em>Opacitya</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getOverflowa <em>Overflowa</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getAlignItemst <em>Align Itemst</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getAlignSelft <em>Align Selft</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getBottomt <em>Bottomt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getFlext <em>Flext</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getJustifyContente <em>Justify Contente</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getLefte <em>Lefte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getMargin <em>Margin</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getMarginBottome <em>Margin Bottome</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getMarginLefte <em>Margin Lefte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getMarginRighte <em>Margin Righte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getMarginTope <em>Margin Tope</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getMarginVerticale <em>Margin Verticale</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getPaddingt <em>Paddingt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getPaddingBottomt <em>Padding Bottomt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getPaddingHorizontale <em>Padding Horizontale</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getPaddingRighte <em>Padding Righte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getPaddingTope <em>Padding Tope</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getPaddingVerticale <em>Padding Verticale</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getRightt <em>Rightt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getWidtht <em>Widtht</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getFlexDirectiont <em>Flex Directiont</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getFlexWrapt <em>Flex Wrapt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl#getHeighte <em>Heighte</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class StyleImageImpl extends stylesheetImpl implements StyleImage
{
  /**
   * The default value of the '{@link #getBackfaceVisibility() <em>Backface Visibility</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBackfaceVisibility()
   * @generated
   * @ordered
   */
  protected static final Backnum BACKFACE_VISIBILITY_EDEFAULT = Backnum.NONE;

  /**
   * The cached value of the '{@link #getBackfaceVisibility() <em>Backface Visibility</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBackfaceVisibility()
   * @generated
   * @ordered
   */
  protected Backnum backfaceVisibility = BACKFACE_VISIBILITY_EDEFAULT;

  /**
   * The default value of the '{@link #getBackgroundColora() <em>Background Colora</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBackgroundColora()
   * @generated
   * @ordered
   */
  protected static final Colors BACKGROUND_COLORA_EDEFAULT = Colors.NONE;

  /**
   * The cached value of the '{@link #getBackgroundColora() <em>Background Colora</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBackgroundColora()
   * @generated
   * @ordered
   */
  protected Colors backgroundColora = BACKGROUND_COLORA_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderBottomLeftRadiusa() <em>Border Bottom Left Radiusa</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomLeftRadiusa()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_BOTTOM_LEFT_RADIUSA_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderBottomLeftRadiusa() <em>Border Bottom Left Radiusa</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomLeftRadiusa()
   * @generated
   * @ordered
   */
  protected entier borderBottomLeftRadiusa = BORDER_BOTTOM_LEFT_RADIUSA_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderBottomRightRadiusa() <em>Border Bottom Right Radiusa</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomRightRadiusa()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_BOTTOM_RIGHT_RADIUSA_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderBottomRightRadiusa() <em>Border Bottom Right Radiusa</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomRightRadiusa()
   * @generated
   * @ordered
   */
  protected entier borderBottomRightRadiusa = BORDER_BOTTOM_RIGHT_RADIUSA_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderColora() <em>Border Colora</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderColora()
   * @generated
   * @ordered
   */
  protected static final Colors BORDER_COLORA_EDEFAULT = Colors.NONE;

  /**
   * The cached value of the '{@link #getBorderColora() <em>Border Colora</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderColora()
   * @generated
   * @ordered
   */
  protected Colors borderColora = BORDER_COLORA_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderRadiusa() <em>Border Radiusa</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderRadiusa()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_RADIUSA_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderRadiusa() <em>Border Radiusa</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderRadiusa()
   * @generated
   * @ordered
   */
  protected entier borderRadiusa = BORDER_RADIUSA_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderTopLeftRadiusa() <em>Border Top Left Radiusa</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopLeftRadiusa()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_TOP_LEFT_RADIUSA_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderTopLeftRadiusa() <em>Border Top Left Radiusa</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopLeftRadiusa()
   * @generated
   * @ordered
   */
  protected entier borderTopLeftRadiusa = BORDER_TOP_LEFT_RADIUSA_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderTopRightRadiusa() <em>Border Top Right Radiusa</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopRightRadiusa()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_TOP_RIGHT_RADIUSA_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderTopRightRadiusa() <em>Border Top Right Radiusa</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopRightRadiusa()
   * @generated
   * @ordered
   */
  protected entier borderTopRightRadiusa = BORDER_TOP_RIGHT_RADIUSA_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderWidtha() <em>Border Widtha</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderWidtha()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_WIDTHA_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderWidtha() <em>Border Widtha</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderWidtha()
   * @generated
   * @ordered
   */
  protected entier borderWidtha = BORDER_WIDTHA_EDEFAULT;

  /**
   * The default value of the '{@link #getOpacitya() <em>Opacitya</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOpacitya()
   * @generated
   * @ordered
   */
  protected static final entier OPACITYA_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getOpacitya() <em>Opacitya</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOpacitya()
   * @generated
   * @ordered
   */
  protected entier opacitya = OPACITYA_EDEFAULT;

  /**
   * The default value of the '{@link #getOverflowa() <em>Overflowa</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOverflowa()
   * @generated
   * @ordered
   */
  protected static final entier OVERFLOWA_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getOverflowa() <em>Overflowa</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOverflowa()
   * @generated
   * @ordered
   */
  protected entier overflowa = OVERFLOWA_EDEFAULT;

  /**
   * The default value of the '{@link #getAlignItemst() <em>Align Itemst</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAlignItemst()
   * @generated
   * @ordered
   */
  protected static final aliIT ALIGN_ITEMST_EDEFAULT = aliIT.NONE;

  /**
   * The cached value of the '{@link #getAlignItemst() <em>Align Itemst</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAlignItemst()
   * @generated
   * @ordered
   */
  protected aliIT alignItemst = ALIGN_ITEMST_EDEFAULT;

  /**
   * The default value of the '{@link #getAlignSelft() <em>Align Selft</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAlignSelft()
   * @generated
   * @ordered
   */
  protected static final alfem ALIGN_SELFT_EDEFAULT = alfem.NONE;

  /**
   * The cached value of the '{@link #getAlignSelft() <em>Align Selft</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAlignSelft()
   * @generated
   * @ordered
   */
  protected alfem alignSelft = ALIGN_SELFT_EDEFAULT;

  /**
   * The default value of the '{@link #getBottomt() <em>Bottomt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBottomt()
   * @generated
   * @ordered
   */
  protected static final entier BOTTOMT_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBottomt() <em>Bottomt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBottomt()
   * @generated
   * @ordered
   */
  protected entier bottomt = BOTTOMT_EDEFAULT;

  /**
   * The default value of the '{@link #getFlext() <em>Flext</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFlext()
   * @generated
   * @ordered
   */
  protected static final entier FLEXT_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getFlext() <em>Flext</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFlext()
   * @generated
   * @ordered
   */
  protected entier flext = FLEXT_EDEFAULT;

  /**
   * The default value of the '{@link #getJustifyContente() <em>Justify Contente</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getJustifyContente()
   * @generated
   * @ordered
   */
  protected static final JustifyContentType JUSTIFY_CONTENTE_EDEFAULT = JustifyContentType.NONE;

  /**
   * The cached value of the '{@link #getJustifyContente() <em>Justify Contente</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getJustifyContente()
   * @generated
   * @ordered
   */
  protected JustifyContentType justifyContente = JUSTIFY_CONTENTE_EDEFAULT;

  /**
   * The default value of the '{@link #getLefte() <em>Lefte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLefte()
   * @generated
   * @ordered
   */
  protected static final entier LEFTE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getLefte() <em>Lefte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLefte()
   * @generated
   * @ordered
   */
  protected entier lefte = LEFTE_EDEFAULT;

  /**
   * The default value of the '{@link #getMargin() <em>Margin</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMargin()
   * @generated
   * @ordered
   */
  protected static final entier MARGIN_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getMargin() <em>Margin</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMargin()
   * @generated
   * @ordered
   */
  protected entier margin = MARGIN_EDEFAULT;

  /**
   * The default value of the '{@link #getMarginBottome() <em>Margin Bottome</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginBottome()
   * @generated
   * @ordered
   */
  protected static final entier MARGIN_BOTTOME_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getMarginBottome() <em>Margin Bottome</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginBottome()
   * @generated
   * @ordered
   */
  protected entier marginBottome = MARGIN_BOTTOME_EDEFAULT;

  /**
   * The default value of the '{@link #getMarginLefte() <em>Margin Lefte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginLefte()
   * @generated
   * @ordered
   */
  protected static final entier MARGIN_LEFTE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getMarginLefte() <em>Margin Lefte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginLefte()
   * @generated
   * @ordered
   */
  protected entier marginLefte = MARGIN_LEFTE_EDEFAULT;

  /**
   * The default value of the '{@link #getMarginRighte() <em>Margin Righte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginRighte()
   * @generated
   * @ordered
   */
  protected static final entier MARGIN_RIGHTE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getMarginRighte() <em>Margin Righte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginRighte()
   * @generated
   * @ordered
   */
  protected entier marginRighte = MARGIN_RIGHTE_EDEFAULT;

  /**
   * The default value of the '{@link #getMarginTope() <em>Margin Tope</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginTope()
   * @generated
   * @ordered
   */
  protected static final entier MARGIN_TOPE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getMarginTope() <em>Margin Tope</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginTope()
   * @generated
   * @ordered
   */
  protected entier marginTope = MARGIN_TOPE_EDEFAULT;

  /**
   * The default value of the '{@link #getMarginVerticale() <em>Margin Verticale</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginVerticale()
   * @generated
   * @ordered
   */
  protected static final entier MARGIN_VERTICALE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getMarginVerticale() <em>Margin Verticale</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginVerticale()
   * @generated
   * @ordered
   */
  protected entier marginVerticale = MARGIN_VERTICALE_EDEFAULT;

  /**
   * The default value of the '{@link #getPaddingt() <em>Paddingt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingt()
   * @generated
   * @ordered
   */
  protected static final entier PADDINGT_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getPaddingt() <em>Paddingt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingt()
   * @generated
   * @ordered
   */
  protected entier paddingt = PADDINGT_EDEFAULT;

  /**
   * The default value of the '{@link #getPaddingBottomt() <em>Padding Bottomt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingBottomt()
   * @generated
   * @ordered
   */
  protected static final entier PADDING_BOTTOMT_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getPaddingBottomt() <em>Padding Bottomt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingBottomt()
   * @generated
   * @ordered
   */
  protected entier paddingBottomt = PADDING_BOTTOMT_EDEFAULT;

  /**
   * The default value of the '{@link #getPaddingHorizontale() <em>Padding Horizontale</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingHorizontale()
   * @generated
   * @ordered
   */
  protected static final entier PADDING_HORIZONTALE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getPaddingHorizontale() <em>Padding Horizontale</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingHorizontale()
   * @generated
   * @ordered
   */
  protected entier paddingHorizontale = PADDING_HORIZONTALE_EDEFAULT;

  /**
   * The default value of the '{@link #getPaddingRighte() <em>Padding Righte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingRighte()
   * @generated
   * @ordered
   */
  protected static final entier PADDING_RIGHTE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getPaddingRighte() <em>Padding Righte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingRighte()
   * @generated
   * @ordered
   */
  protected entier paddingRighte = PADDING_RIGHTE_EDEFAULT;

  /**
   * The default value of the '{@link #getPaddingTope() <em>Padding Tope</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingTope()
   * @generated
   * @ordered
   */
  protected static final entier PADDING_TOPE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getPaddingTope() <em>Padding Tope</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingTope()
   * @generated
   * @ordered
   */
  protected entier paddingTope = PADDING_TOPE_EDEFAULT;

  /**
   * The default value of the '{@link #getPaddingVerticale() <em>Padding Verticale</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingVerticale()
   * @generated
   * @ordered
   */
  protected static final entier PADDING_VERTICALE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getPaddingVerticale() <em>Padding Verticale</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingVerticale()
   * @generated
   * @ordered
   */
  protected entier paddingVerticale = PADDING_VERTICALE_EDEFAULT;

  /**
   * The default value of the '{@link #getRightt() <em>Rightt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getRightt()
   * @generated
   * @ordered
   */
  protected static final entier RIGHTT_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getRightt() <em>Rightt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getRightt()
   * @generated
   * @ordered
   */
  protected entier rightt = RIGHTT_EDEFAULT;

  /**
   * The default value of the '{@link #getWidtht() <em>Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getWidtht()
   * @generated
   * @ordered
   */
  protected static final entier WIDTHT_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getWidtht() <em>Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getWidtht()
   * @generated
   * @ordered
   */
  protected entier widtht = WIDTHT_EDEFAULT;

  /**
   * The default value of the '{@link #getFlexDirectiont() <em>Flex Directiont</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFlexDirectiont()
   * @generated
   * @ordered
   */
  protected static final flexd FLEX_DIRECTIONT_EDEFAULT = flexd.NONE;

  /**
   * The cached value of the '{@link #getFlexDirectiont() <em>Flex Directiont</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFlexDirectiont()
   * @generated
   * @ordered
   */
  protected flexd flexDirectiont = FLEX_DIRECTIONT_EDEFAULT;

  /**
   * The default value of the '{@link #getFlexWrapt() <em>Flex Wrapt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFlexWrapt()
   * @generated
   * @ordered
   */
  protected static final One FLEX_WRAPT_EDEFAULT = One.WRAP;

  /**
   * The cached value of the '{@link #getFlexWrapt() <em>Flex Wrapt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFlexWrapt()
   * @generated
   * @ordered
   */
  protected One flexWrapt = FLEX_WRAPT_EDEFAULT;

  /**
   * The default value of the '{@link #getHeighte() <em>Heighte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHeighte()
   * @generated
   * @ordered
   */
  protected static final entier HEIGHTE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getHeighte() <em>Heighte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHeighte()
   * @generated
   * @ordered
   */
  protected entier heighte = HEIGHTE_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected StyleImageImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return PfePackage.Literals.STYLE_IMAGE;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Backnum getBackfaceVisibility()
  {
    return backfaceVisibility;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBackfaceVisibility(Backnum newBackfaceVisibility)
  {
    Backnum oldBackfaceVisibility = backfaceVisibility;
    backfaceVisibility = newBackfaceVisibility == null ? BACKFACE_VISIBILITY_EDEFAULT : newBackfaceVisibility;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__BACKFACE_VISIBILITY, oldBackfaceVisibility, backfaceVisibility));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Colors getBackgroundColora()
  {
    return backgroundColora;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBackgroundColora(Colors newBackgroundColora)
  {
    Colors oldBackgroundColora = backgroundColora;
    backgroundColora = newBackgroundColora == null ? BACKGROUND_COLORA_EDEFAULT : newBackgroundColora;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__BACKGROUND_COLORA, oldBackgroundColora, backgroundColora));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderBottomLeftRadiusa()
  {
    return borderBottomLeftRadiusa;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderBottomLeftRadiusa(entier newBorderBottomLeftRadiusa)
  {
    entier oldBorderBottomLeftRadiusa = borderBottomLeftRadiusa;
    borderBottomLeftRadiusa = newBorderBottomLeftRadiusa == null ? BORDER_BOTTOM_LEFT_RADIUSA_EDEFAULT : newBorderBottomLeftRadiusa;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__BORDER_BOTTOM_LEFT_RADIUSA, oldBorderBottomLeftRadiusa, borderBottomLeftRadiusa));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderBottomRightRadiusa()
  {
    return borderBottomRightRadiusa;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderBottomRightRadiusa(entier newBorderBottomRightRadiusa)
  {
    entier oldBorderBottomRightRadiusa = borderBottomRightRadiusa;
    borderBottomRightRadiusa = newBorderBottomRightRadiusa == null ? BORDER_BOTTOM_RIGHT_RADIUSA_EDEFAULT : newBorderBottomRightRadiusa;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__BORDER_BOTTOM_RIGHT_RADIUSA, oldBorderBottomRightRadiusa, borderBottomRightRadiusa));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Colors getBorderColora()
  {
    return borderColora;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderColora(Colors newBorderColora)
  {
    Colors oldBorderColora = borderColora;
    borderColora = newBorderColora == null ? BORDER_COLORA_EDEFAULT : newBorderColora;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__BORDER_COLORA, oldBorderColora, borderColora));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderRadiusa()
  {
    return borderRadiusa;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderRadiusa(entier newBorderRadiusa)
  {
    entier oldBorderRadiusa = borderRadiusa;
    borderRadiusa = newBorderRadiusa == null ? BORDER_RADIUSA_EDEFAULT : newBorderRadiusa;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__BORDER_RADIUSA, oldBorderRadiusa, borderRadiusa));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderTopLeftRadiusa()
  {
    return borderTopLeftRadiusa;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderTopLeftRadiusa(entier newBorderTopLeftRadiusa)
  {
    entier oldBorderTopLeftRadiusa = borderTopLeftRadiusa;
    borderTopLeftRadiusa = newBorderTopLeftRadiusa == null ? BORDER_TOP_LEFT_RADIUSA_EDEFAULT : newBorderTopLeftRadiusa;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__BORDER_TOP_LEFT_RADIUSA, oldBorderTopLeftRadiusa, borderTopLeftRadiusa));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderTopRightRadiusa()
  {
    return borderTopRightRadiusa;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderTopRightRadiusa(entier newBorderTopRightRadiusa)
  {
    entier oldBorderTopRightRadiusa = borderTopRightRadiusa;
    borderTopRightRadiusa = newBorderTopRightRadiusa == null ? BORDER_TOP_RIGHT_RADIUSA_EDEFAULT : newBorderTopRightRadiusa;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__BORDER_TOP_RIGHT_RADIUSA, oldBorderTopRightRadiusa, borderTopRightRadiusa));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderWidtha()
  {
    return borderWidtha;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderWidtha(entier newBorderWidtha)
  {
    entier oldBorderWidtha = borderWidtha;
    borderWidtha = newBorderWidtha == null ? BORDER_WIDTHA_EDEFAULT : newBorderWidtha;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__BORDER_WIDTHA, oldBorderWidtha, borderWidtha));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getOpacitya()
  {
    return opacitya;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setOpacitya(entier newOpacitya)
  {
    entier oldOpacitya = opacitya;
    opacitya = newOpacitya == null ? OPACITYA_EDEFAULT : newOpacitya;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__OPACITYA, oldOpacitya, opacitya));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getOverflowa()
  {
    return overflowa;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setOverflowa(entier newOverflowa)
  {
    entier oldOverflowa = overflowa;
    overflowa = newOverflowa == null ? OVERFLOWA_EDEFAULT : newOverflowa;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__OVERFLOWA, oldOverflowa, overflowa));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public aliIT getAlignItemst()
  {
    return alignItemst;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAlignItemst(aliIT newAlignItemst)
  {
    aliIT oldAlignItemst = alignItemst;
    alignItemst = newAlignItemst == null ? ALIGN_ITEMST_EDEFAULT : newAlignItemst;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__ALIGN_ITEMST, oldAlignItemst, alignItemst));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public alfem getAlignSelft()
  {
    return alignSelft;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAlignSelft(alfem newAlignSelft)
  {
    alfem oldAlignSelft = alignSelft;
    alignSelft = newAlignSelft == null ? ALIGN_SELFT_EDEFAULT : newAlignSelft;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__ALIGN_SELFT, oldAlignSelft, alignSelft));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBottomt()
  {
    return bottomt;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBottomt(entier newBottomt)
  {
    entier oldBottomt = bottomt;
    bottomt = newBottomt == null ? BOTTOMT_EDEFAULT : newBottomt;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__BOTTOMT, oldBottomt, bottomt));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getFlext()
  {
    return flext;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFlext(entier newFlext)
  {
    entier oldFlext = flext;
    flext = newFlext == null ? FLEXT_EDEFAULT : newFlext;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__FLEXT, oldFlext, flext));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public JustifyContentType getJustifyContente()
  {
    return justifyContente;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setJustifyContente(JustifyContentType newJustifyContente)
  {
    JustifyContentType oldJustifyContente = justifyContente;
    justifyContente = newJustifyContente == null ? JUSTIFY_CONTENTE_EDEFAULT : newJustifyContente;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__JUSTIFY_CONTENTE, oldJustifyContente, justifyContente));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getLefte()
  {
    return lefte;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLefte(entier newLefte)
  {
    entier oldLefte = lefte;
    lefte = newLefte == null ? LEFTE_EDEFAULT : newLefte;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__LEFTE, oldLefte, lefte));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getMargin()
  {
    return margin;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMargin(entier newMargin)
  {
    entier oldMargin = margin;
    margin = newMargin == null ? MARGIN_EDEFAULT : newMargin;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__MARGIN, oldMargin, margin));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getMarginBottome()
  {
    return marginBottome;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMarginBottome(entier newMarginBottome)
  {
    entier oldMarginBottome = marginBottome;
    marginBottome = newMarginBottome == null ? MARGIN_BOTTOME_EDEFAULT : newMarginBottome;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__MARGIN_BOTTOME, oldMarginBottome, marginBottome));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getMarginLefte()
  {
    return marginLefte;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMarginLefte(entier newMarginLefte)
  {
    entier oldMarginLefte = marginLefte;
    marginLefte = newMarginLefte == null ? MARGIN_LEFTE_EDEFAULT : newMarginLefte;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__MARGIN_LEFTE, oldMarginLefte, marginLefte));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getMarginRighte()
  {
    return marginRighte;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMarginRighte(entier newMarginRighte)
  {
    entier oldMarginRighte = marginRighte;
    marginRighte = newMarginRighte == null ? MARGIN_RIGHTE_EDEFAULT : newMarginRighte;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__MARGIN_RIGHTE, oldMarginRighte, marginRighte));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getMarginTope()
  {
    return marginTope;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMarginTope(entier newMarginTope)
  {
    entier oldMarginTope = marginTope;
    marginTope = newMarginTope == null ? MARGIN_TOPE_EDEFAULT : newMarginTope;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__MARGIN_TOPE, oldMarginTope, marginTope));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getMarginVerticale()
  {
    return marginVerticale;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMarginVerticale(entier newMarginVerticale)
  {
    entier oldMarginVerticale = marginVerticale;
    marginVerticale = newMarginVerticale == null ? MARGIN_VERTICALE_EDEFAULT : newMarginVerticale;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__MARGIN_VERTICALE, oldMarginVerticale, marginVerticale));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getPaddingt()
  {
    return paddingt;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPaddingt(entier newPaddingt)
  {
    entier oldPaddingt = paddingt;
    paddingt = newPaddingt == null ? PADDINGT_EDEFAULT : newPaddingt;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__PADDINGT, oldPaddingt, paddingt));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getPaddingBottomt()
  {
    return paddingBottomt;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPaddingBottomt(entier newPaddingBottomt)
  {
    entier oldPaddingBottomt = paddingBottomt;
    paddingBottomt = newPaddingBottomt == null ? PADDING_BOTTOMT_EDEFAULT : newPaddingBottomt;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__PADDING_BOTTOMT, oldPaddingBottomt, paddingBottomt));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getPaddingHorizontale()
  {
    return paddingHorizontale;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPaddingHorizontale(entier newPaddingHorizontale)
  {
    entier oldPaddingHorizontale = paddingHorizontale;
    paddingHorizontale = newPaddingHorizontale == null ? PADDING_HORIZONTALE_EDEFAULT : newPaddingHorizontale;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__PADDING_HORIZONTALE, oldPaddingHorizontale, paddingHorizontale));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getPaddingRighte()
  {
    return paddingRighte;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPaddingRighte(entier newPaddingRighte)
  {
    entier oldPaddingRighte = paddingRighte;
    paddingRighte = newPaddingRighte == null ? PADDING_RIGHTE_EDEFAULT : newPaddingRighte;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__PADDING_RIGHTE, oldPaddingRighte, paddingRighte));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getPaddingTope()
  {
    return paddingTope;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPaddingTope(entier newPaddingTope)
  {
    entier oldPaddingTope = paddingTope;
    paddingTope = newPaddingTope == null ? PADDING_TOPE_EDEFAULT : newPaddingTope;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__PADDING_TOPE, oldPaddingTope, paddingTope));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getPaddingVerticale()
  {
    return paddingVerticale;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPaddingVerticale(entier newPaddingVerticale)
  {
    entier oldPaddingVerticale = paddingVerticale;
    paddingVerticale = newPaddingVerticale == null ? PADDING_VERTICALE_EDEFAULT : newPaddingVerticale;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__PADDING_VERTICALE, oldPaddingVerticale, paddingVerticale));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getRightt()
  {
    return rightt;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setRightt(entier newRightt)
  {
    entier oldRightt = rightt;
    rightt = newRightt == null ? RIGHTT_EDEFAULT : newRightt;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__RIGHTT, oldRightt, rightt));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getWidtht()
  {
    return widtht;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setWidtht(entier newWidtht)
  {
    entier oldWidtht = widtht;
    widtht = newWidtht == null ? WIDTHT_EDEFAULT : newWidtht;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__WIDTHT, oldWidtht, widtht));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public flexd getFlexDirectiont()
  {
    return flexDirectiont;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFlexDirectiont(flexd newFlexDirectiont)
  {
    flexd oldFlexDirectiont = flexDirectiont;
    flexDirectiont = newFlexDirectiont == null ? FLEX_DIRECTIONT_EDEFAULT : newFlexDirectiont;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__FLEX_DIRECTIONT, oldFlexDirectiont, flexDirectiont));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public One getFlexWrapt()
  {
    return flexWrapt;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFlexWrapt(One newFlexWrapt)
  {
    One oldFlexWrapt = flexWrapt;
    flexWrapt = newFlexWrapt == null ? FLEX_WRAPT_EDEFAULT : newFlexWrapt;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__FLEX_WRAPT, oldFlexWrapt, flexWrapt));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getHeighte()
  {
    return heighte;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setHeighte(entier newHeighte)
  {
    entier oldHeighte = heighte;
    heighte = newHeighte == null ? HEIGHTE_EDEFAULT : newHeighte;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_IMAGE__HEIGHTE, oldHeighte, heighte));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case PfePackage.STYLE_IMAGE__BACKFACE_VISIBILITY:
        return getBackfaceVisibility();
      case PfePackage.STYLE_IMAGE__BACKGROUND_COLORA:
        return getBackgroundColora();
      case PfePackage.STYLE_IMAGE__BORDER_BOTTOM_LEFT_RADIUSA:
        return getBorderBottomLeftRadiusa();
      case PfePackage.STYLE_IMAGE__BORDER_BOTTOM_RIGHT_RADIUSA:
        return getBorderBottomRightRadiusa();
      case PfePackage.STYLE_IMAGE__BORDER_COLORA:
        return getBorderColora();
      case PfePackage.STYLE_IMAGE__BORDER_RADIUSA:
        return getBorderRadiusa();
      case PfePackage.STYLE_IMAGE__BORDER_TOP_LEFT_RADIUSA:
        return getBorderTopLeftRadiusa();
      case PfePackage.STYLE_IMAGE__BORDER_TOP_RIGHT_RADIUSA:
        return getBorderTopRightRadiusa();
      case PfePackage.STYLE_IMAGE__BORDER_WIDTHA:
        return getBorderWidtha();
      case PfePackage.STYLE_IMAGE__OPACITYA:
        return getOpacitya();
      case PfePackage.STYLE_IMAGE__OVERFLOWA:
        return getOverflowa();
      case PfePackage.STYLE_IMAGE__ALIGN_ITEMST:
        return getAlignItemst();
      case PfePackage.STYLE_IMAGE__ALIGN_SELFT:
        return getAlignSelft();
      case PfePackage.STYLE_IMAGE__BOTTOMT:
        return getBottomt();
      case PfePackage.STYLE_IMAGE__FLEXT:
        return getFlext();
      case PfePackage.STYLE_IMAGE__JUSTIFY_CONTENTE:
        return getJustifyContente();
      case PfePackage.STYLE_IMAGE__LEFTE:
        return getLefte();
      case PfePackage.STYLE_IMAGE__MARGIN:
        return getMargin();
      case PfePackage.STYLE_IMAGE__MARGIN_BOTTOME:
        return getMarginBottome();
      case PfePackage.STYLE_IMAGE__MARGIN_LEFTE:
        return getMarginLefte();
      case PfePackage.STYLE_IMAGE__MARGIN_RIGHTE:
        return getMarginRighte();
      case PfePackage.STYLE_IMAGE__MARGIN_TOPE:
        return getMarginTope();
      case PfePackage.STYLE_IMAGE__MARGIN_VERTICALE:
        return getMarginVerticale();
      case PfePackage.STYLE_IMAGE__PADDINGT:
        return getPaddingt();
      case PfePackage.STYLE_IMAGE__PADDING_BOTTOMT:
        return getPaddingBottomt();
      case PfePackage.STYLE_IMAGE__PADDING_HORIZONTALE:
        return getPaddingHorizontale();
      case PfePackage.STYLE_IMAGE__PADDING_RIGHTE:
        return getPaddingRighte();
      case PfePackage.STYLE_IMAGE__PADDING_TOPE:
        return getPaddingTope();
      case PfePackage.STYLE_IMAGE__PADDING_VERTICALE:
        return getPaddingVerticale();
      case PfePackage.STYLE_IMAGE__RIGHTT:
        return getRightt();
      case PfePackage.STYLE_IMAGE__WIDTHT:
        return getWidtht();
      case PfePackage.STYLE_IMAGE__FLEX_DIRECTIONT:
        return getFlexDirectiont();
      case PfePackage.STYLE_IMAGE__FLEX_WRAPT:
        return getFlexWrapt();
      case PfePackage.STYLE_IMAGE__HEIGHTE:
        return getHeighte();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case PfePackage.STYLE_IMAGE__BACKFACE_VISIBILITY:
        setBackfaceVisibility((Backnum)newValue);
        return;
      case PfePackage.STYLE_IMAGE__BACKGROUND_COLORA:
        setBackgroundColora((Colors)newValue);
        return;
      case PfePackage.STYLE_IMAGE__BORDER_BOTTOM_LEFT_RADIUSA:
        setBorderBottomLeftRadiusa((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__BORDER_BOTTOM_RIGHT_RADIUSA:
        setBorderBottomRightRadiusa((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__BORDER_COLORA:
        setBorderColora((Colors)newValue);
        return;
      case PfePackage.STYLE_IMAGE__BORDER_RADIUSA:
        setBorderRadiusa((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__BORDER_TOP_LEFT_RADIUSA:
        setBorderTopLeftRadiusa((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__BORDER_TOP_RIGHT_RADIUSA:
        setBorderTopRightRadiusa((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__BORDER_WIDTHA:
        setBorderWidtha((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__OPACITYA:
        setOpacitya((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__OVERFLOWA:
        setOverflowa((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__ALIGN_ITEMST:
        setAlignItemst((aliIT)newValue);
        return;
      case PfePackage.STYLE_IMAGE__ALIGN_SELFT:
        setAlignSelft((alfem)newValue);
        return;
      case PfePackage.STYLE_IMAGE__BOTTOMT:
        setBottomt((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__FLEXT:
        setFlext((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__JUSTIFY_CONTENTE:
        setJustifyContente((JustifyContentType)newValue);
        return;
      case PfePackage.STYLE_IMAGE__LEFTE:
        setLefte((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__MARGIN:
        setMargin((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__MARGIN_BOTTOME:
        setMarginBottome((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__MARGIN_LEFTE:
        setMarginLefte((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__MARGIN_RIGHTE:
        setMarginRighte((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__MARGIN_TOPE:
        setMarginTope((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__MARGIN_VERTICALE:
        setMarginVerticale((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__PADDINGT:
        setPaddingt((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__PADDING_BOTTOMT:
        setPaddingBottomt((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__PADDING_HORIZONTALE:
        setPaddingHorizontale((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__PADDING_RIGHTE:
        setPaddingRighte((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__PADDING_TOPE:
        setPaddingTope((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__PADDING_VERTICALE:
        setPaddingVerticale((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__RIGHTT:
        setRightt((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__WIDTHT:
        setWidtht((entier)newValue);
        return;
      case PfePackage.STYLE_IMAGE__FLEX_DIRECTIONT:
        setFlexDirectiont((flexd)newValue);
        return;
      case PfePackage.STYLE_IMAGE__FLEX_WRAPT:
        setFlexWrapt((One)newValue);
        return;
      case PfePackage.STYLE_IMAGE__HEIGHTE:
        setHeighte((entier)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.STYLE_IMAGE__BACKFACE_VISIBILITY:
        setBackfaceVisibility(BACKFACE_VISIBILITY_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__BACKGROUND_COLORA:
        setBackgroundColora(BACKGROUND_COLORA_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__BORDER_BOTTOM_LEFT_RADIUSA:
        setBorderBottomLeftRadiusa(BORDER_BOTTOM_LEFT_RADIUSA_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__BORDER_BOTTOM_RIGHT_RADIUSA:
        setBorderBottomRightRadiusa(BORDER_BOTTOM_RIGHT_RADIUSA_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__BORDER_COLORA:
        setBorderColora(BORDER_COLORA_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__BORDER_RADIUSA:
        setBorderRadiusa(BORDER_RADIUSA_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__BORDER_TOP_LEFT_RADIUSA:
        setBorderTopLeftRadiusa(BORDER_TOP_LEFT_RADIUSA_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__BORDER_TOP_RIGHT_RADIUSA:
        setBorderTopRightRadiusa(BORDER_TOP_RIGHT_RADIUSA_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__BORDER_WIDTHA:
        setBorderWidtha(BORDER_WIDTHA_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__OPACITYA:
        setOpacitya(OPACITYA_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__OVERFLOWA:
        setOverflowa(OVERFLOWA_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__ALIGN_ITEMST:
        setAlignItemst(ALIGN_ITEMST_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__ALIGN_SELFT:
        setAlignSelft(ALIGN_SELFT_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__BOTTOMT:
        setBottomt(BOTTOMT_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__FLEXT:
        setFlext(FLEXT_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__JUSTIFY_CONTENTE:
        setJustifyContente(JUSTIFY_CONTENTE_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__LEFTE:
        setLefte(LEFTE_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__MARGIN:
        setMargin(MARGIN_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__MARGIN_BOTTOME:
        setMarginBottome(MARGIN_BOTTOME_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__MARGIN_LEFTE:
        setMarginLefte(MARGIN_LEFTE_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__MARGIN_RIGHTE:
        setMarginRighte(MARGIN_RIGHTE_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__MARGIN_TOPE:
        setMarginTope(MARGIN_TOPE_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__MARGIN_VERTICALE:
        setMarginVerticale(MARGIN_VERTICALE_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__PADDINGT:
        setPaddingt(PADDINGT_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__PADDING_BOTTOMT:
        setPaddingBottomt(PADDING_BOTTOMT_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__PADDING_HORIZONTALE:
        setPaddingHorizontale(PADDING_HORIZONTALE_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__PADDING_RIGHTE:
        setPaddingRighte(PADDING_RIGHTE_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__PADDING_TOPE:
        setPaddingTope(PADDING_TOPE_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__PADDING_VERTICALE:
        setPaddingVerticale(PADDING_VERTICALE_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__RIGHTT:
        setRightt(RIGHTT_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__WIDTHT:
        setWidtht(WIDTHT_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__FLEX_DIRECTIONT:
        setFlexDirectiont(FLEX_DIRECTIONT_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__FLEX_WRAPT:
        setFlexWrapt(FLEX_WRAPT_EDEFAULT);
        return;
      case PfePackage.STYLE_IMAGE__HEIGHTE:
        setHeighte(HEIGHTE_EDEFAULT);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.STYLE_IMAGE__BACKFACE_VISIBILITY:
        return backfaceVisibility != BACKFACE_VISIBILITY_EDEFAULT;
      case PfePackage.STYLE_IMAGE__BACKGROUND_COLORA:
        return backgroundColora != BACKGROUND_COLORA_EDEFAULT;
      case PfePackage.STYLE_IMAGE__BORDER_BOTTOM_LEFT_RADIUSA:
        return borderBottomLeftRadiusa != BORDER_BOTTOM_LEFT_RADIUSA_EDEFAULT;
      case PfePackage.STYLE_IMAGE__BORDER_BOTTOM_RIGHT_RADIUSA:
        return borderBottomRightRadiusa != BORDER_BOTTOM_RIGHT_RADIUSA_EDEFAULT;
      case PfePackage.STYLE_IMAGE__BORDER_COLORA:
        return borderColora != BORDER_COLORA_EDEFAULT;
      case PfePackage.STYLE_IMAGE__BORDER_RADIUSA:
        return borderRadiusa != BORDER_RADIUSA_EDEFAULT;
      case PfePackage.STYLE_IMAGE__BORDER_TOP_LEFT_RADIUSA:
        return borderTopLeftRadiusa != BORDER_TOP_LEFT_RADIUSA_EDEFAULT;
      case PfePackage.STYLE_IMAGE__BORDER_TOP_RIGHT_RADIUSA:
        return borderTopRightRadiusa != BORDER_TOP_RIGHT_RADIUSA_EDEFAULT;
      case PfePackage.STYLE_IMAGE__BORDER_WIDTHA:
        return borderWidtha != BORDER_WIDTHA_EDEFAULT;
      case PfePackage.STYLE_IMAGE__OPACITYA:
        return opacitya != OPACITYA_EDEFAULT;
      case PfePackage.STYLE_IMAGE__OVERFLOWA:
        return overflowa != OVERFLOWA_EDEFAULT;
      case PfePackage.STYLE_IMAGE__ALIGN_ITEMST:
        return alignItemst != ALIGN_ITEMST_EDEFAULT;
      case PfePackage.STYLE_IMAGE__ALIGN_SELFT:
        return alignSelft != ALIGN_SELFT_EDEFAULT;
      case PfePackage.STYLE_IMAGE__BOTTOMT:
        return bottomt != BOTTOMT_EDEFAULT;
      case PfePackage.STYLE_IMAGE__FLEXT:
        return flext != FLEXT_EDEFAULT;
      case PfePackage.STYLE_IMAGE__JUSTIFY_CONTENTE:
        return justifyContente != JUSTIFY_CONTENTE_EDEFAULT;
      case PfePackage.STYLE_IMAGE__LEFTE:
        return lefte != LEFTE_EDEFAULT;
      case PfePackage.STYLE_IMAGE__MARGIN:
        return margin != MARGIN_EDEFAULT;
      case PfePackage.STYLE_IMAGE__MARGIN_BOTTOME:
        return marginBottome != MARGIN_BOTTOME_EDEFAULT;
      case PfePackage.STYLE_IMAGE__MARGIN_LEFTE:
        return marginLefte != MARGIN_LEFTE_EDEFAULT;
      case PfePackage.STYLE_IMAGE__MARGIN_RIGHTE:
        return marginRighte != MARGIN_RIGHTE_EDEFAULT;
      case PfePackage.STYLE_IMAGE__MARGIN_TOPE:
        return marginTope != MARGIN_TOPE_EDEFAULT;
      case PfePackage.STYLE_IMAGE__MARGIN_VERTICALE:
        return marginVerticale != MARGIN_VERTICALE_EDEFAULT;
      case PfePackage.STYLE_IMAGE__PADDINGT:
        return paddingt != PADDINGT_EDEFAULT;
      case PfePackage.STYLE_IMAGE__PADDING_BOTTOMT:
        return paddingBottomt != PADDING_BOTTOMT_EDEFAULT;
      case PfePackage.STYLE_IMAGE__PADDING_HORIZONTALE:
        return paddingHorizontale != PADDING_HORIZONTALE_EDEFAULT;
      case PfePackage.STYLE_IMAGE__PADDING_RIGHTE:
        return paddingRighte != PADDING_RIGHTE_EDEFAULT;
      case PfePackage.STYLE_IMAGE__PADDING_TOPE:
        return paddingTope != PADDING_TOPE_EDEFAULT;
      case PfePackage.STYLE_IMAGE__PADDING_VERTICALE:
        return paddingVerticale != PADDING_VERTICALE_EDEFAULT;
      case PfePackage.STYLE_IMAGE__RIGHTT:
        return rightt != RIGHTT_EDEFAULT;
      case PfePackage.STYLE_IMAGE__WIDTHT:
        return widtht != WIDTHT_EDEFAULT;
      case PfePackage.STYLE_IMAGE__FLEX_DIRECTIONT:
        return flexDirectiont != FLEX_DIRECTIONT_EDEFAULT;
      case PfePackage.STYLE_IMAGE__FLEX_WRAPT:
        return flexWrapt != FLEX_WRAPT_EDEFAULT;
      case PfePackage.STYLE_IMAGE__HEIGHTE:
        return heighte != HEIGHTE_EDEFAULT;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (backfaceVisibility: ");
    result.append(backfaceVisibility);
    result.append(", backgroundColora: ");
    result.append(backgroundColora);
    result.append(", borderBottomLeftRadiusa: ");
    result.append(borderBottomLeftRadiusa);
    result.append(", borderBottomRightRadiusa: ");
    result.append(borderBottomRightRadiusa);
    result.append(", borderColora: ");
    result.append(borderColora);
    result.append(", borderRadiusa: ");
    result.append(borderRadiusa);
    result.append(", borderTopLeftRadiusa: ");
    result.append(borderTopLeftRadiusa);
    result.append(", borderTopRightRadiusa: ");
    result.append(borderTopRightRadiusa);
    result.append(", borderWidtha: ");
    result.append(borderWidtha);
    result.append(", opacitya: ");
    result.append(opacitya);
    result.append(", overflowa: ");
    result.append(overflowa);
    result.append(", alignItemst: ");
    result.append(alignItemst);
    result.append(", alignSelft: ");
    result.append(alignSelft);
    result.append(", bottomt: ");
    result.append(bottomt);
    result.append(", flext: ");
    result.append(flext);
    result.append(", justifyContente: ");
    result.append(justifyContente);
    result.append(", lefte: ");
    result.append(lefte);
    result.append(", margin: ");
    result.append(margin);
    result.append(", marginBottome: ");
    result.append(marginBottome);
    result.append(", marginLefte: ");
    result.append(marginLefte);
    result.append(", marginRighte: ");
    result.append(marginRighte);
    result.append(", marginTope: ");
    result.append(marginTope);
    result.append(", marginVerticale: ");
    result.append(marginVerticale);
    result.append(", paddingt: ");
    result.append(paddingt);
    result.append(", paddingBottomt: ");
    result.append(paddingBottomt);
    result.append(", paddingHorizontale: ");
    result.append(paddingHorizontale);
    result.append(", paddingRighte: ");
    result.append(paddingRighte);
    result.append(", paddingTope: ");
    result.append(paddingTope);
    result.append(", paddingVerticale: ");
    result.append(paddingVerticale);
    result.append(", rightt: ");
    result.append(rightt);
    result.append(", widtht: ");
    result.append(widtht);
    result.append(", flexDirectiont: ");
    result.append(flexDirectiont);
    result.append(", flexWrapt: ");
    result.append(flexWrapt);
    result.append(", heighte: ");
    result.append(heighte);
    result.append(')');
    return result.toString();
  }

} //StyleImageImpl
