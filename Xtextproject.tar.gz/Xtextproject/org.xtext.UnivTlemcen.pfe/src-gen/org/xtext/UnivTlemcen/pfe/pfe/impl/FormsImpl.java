/**
 */
package org.xtext.UnivTlemcen.pfe.pfe.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.xtext.UnivTlemcen.pfe.pfe.Forms;
import org.xtext.UnivTlemcen.pfe.pfe.LC;
import org.xtext.UnivTlemcen.pfe.pfe.PfePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Forms</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.FormsImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.FormsImpl#getLigne <em>Ligne</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.FormsImpl#getColonne <em>Colonne</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class FormsImpl extends ElementsImpl implements Forms
{
  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The default value of the '{@link #getLigne() <em>Ligne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLigne()
   * @generated
   * @ordered
   */
  protected static final LC LIGNE_EDEFAULT = LC.UN;

  /**
   * The cached value of the '{@link #getLigne() <em>Ligne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLigne()
   * @generated
   * @ordered
   */
  protected LC ligne = LIGNE_EDEFAULT;

  /**
   * The default value of the '{@link #getColonne() <em>Colonne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getColonne()
   * @generated
   * @ordered
   */
  protected static final LC COLONNE_EDEFAULT = LC.UN;

  /**
   * The cached value of the '{@link #getColonne() <em>Colonne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getColonne()
   * @generated
   * @ordered
   */
  protected LC colonne = COLONNE_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected FormsImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return PfePackage.Literals.FORMS;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName)
  {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.FORMS__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LC getLigne()
  {
    return ligne;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLigne(LC newLigne)
  {
    LC oldLigne = ligne;
    ligne = newLigne == null ? LIGNE_EDEFAULT : newLigne;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.FORMS__LIGNE, oldLigne, ligne));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LC getColonne()
  {
    return colonne;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setColonne(LC newColonne)
  {
    LC oldColonne = colonne;
    colonne = newColonne == null ? COLONNE_EDEFAULT : newColonne;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.FORMS__COLONNE, oldColonne, colonne));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case PfePackage.FORMS__NAME:
        return getName();
      case PfePackage.FORMS__LIGNE:
        return getLigne();
      case PfePackage.FORMS__COLONNE:
        return getColonne();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case PfePackage.FORMS__NAME:
        setName((String)newValue);
        return;
      case PfePackage.FORMS__LIGNE:
        setLigne((LC)newValue);
        return;
      case PfePackage.FORMS__COLONNE:
        setColonne((LC)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.FORMS__NAME:
        setName(NAME_EDEFAULT);
        return;
      case PfePackage.FORMS__LIGNE:
        setLigne(LIGNE_EDEFAULT);
        return;
      case PfePackage.FORMS__COLONNE:
        setColonne(COLONNE_EDEFAULT);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.FORMS__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case PfePackage.FORMS__LIGNE:
        return ligne != LIGNE_EDEFAULT;
      case PfePackage.FORMS__COLONNE:
        return colonne != COLONNE_EDEFAULT;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (name: ");
    result.append(name);
    result.append(", ligne: ");
    result.append(ligne);
    result.append(", colonne: ");
    result.append(colonne);
    result.append(')');
    return result.toString();
  }

} //FormsImpl
