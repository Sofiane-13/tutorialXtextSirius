/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Vue</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getVue()
 * @model
 * @generated
 */
public interface Vue extends EObject
{
} // Vue
