/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Style Image</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBackfaceVisibility <em>Backface Visibility</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBackgroundColora <em>Background Colora</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderBottomLeftRadiusa <em>Border Bottom Left Radiusa</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderBottomRightRadiusa <em>Border Bottom Right Radiusa</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderColora <em>Border Colora</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderRadiusa <em>Border Radiusa</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderTopLeftRadiusa <em>Border Top Left Radiusa</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderTopRightRadiusa <em>Border Top Right Radiusa</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderWidtha <em>Border Widtha</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getOpacitya <em>Opacitya</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getOverflowa <em>Overflowa</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getAlignItemst <em>Align Itemst</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getAlignSelft <em>Align Selft</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBottomt <em>Bottomt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getFlext <em>Flext</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getJustifyContente <em>Justify Contente</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getLefte <em>Lefte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMargin <em>Margin</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMarginBottome <em>Margin Bottome</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMarginLefte <em>Margin Lefte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMarginRighte <em>Margin Righte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMarginTope <em>Margin Tope</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMarginVerticale <em>Margin Verticale</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingt <em>Paddingt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingBottomt <em>Padding Bottomt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingHorizontale <em>Padding Horizontale</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingRighte <em>Padding Righte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingTope <em>Padding Tope</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingVerticale <em>Padding Verticale</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getRightt <em>Rightt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getWidtht <em>Widtht</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getFlexDirectiont <em>Flex Directiont</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getFlexWrapt <em>Flex Wrapt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getHeighte <em>Heighte</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage()
 * @model
 * @generated
 */
public interface StyleImage extends stylesheet
{
  /**
   * Returns the value of the '<em><b>Backface Visibility</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Backnum}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Backface Visibility</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Backface Visibility</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Backnum
   * @see #setBackfaceVisibility(Backnum)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_BackfaceVisibility()
   * @model
   * @generated
   */
  Backnum getBackfaceVisibility();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBackfaceVisibility <em>Backface Visibility</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Backface Visibility</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Backnum
   * @see #getBackfaceVisibility()
   * @generated
   */
  void setBackfaceVisibility(Backnum value);

  /**
   * Returns the value of the '<em><b>Background Colora</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Colors}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Background Colora</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Background Colora</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #setBackgroundColora(Colors)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_BackgroundColora()
   * @model
   * @generated
   */
  Colors getBackgroundColora();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBackgroundColora <em>Background Colora</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Background Colora</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #getBackgroundColora()
   * @generated
   */
  void setBackgroundColora(Colors value);

  /**
   * Returns the value of the '<em><b>Border Bottom Left Radiusa</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Bottom Left Radiusa</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Bottom Left Radiusa</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderBottomLeftRadiusa(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_BorderBottomLeftRadiusa()
   * @model
   * @generated
   */
  entier getBorderBottomLeftRadiusa();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderBottomLeftRadiusa <em>Border Bottom Left Radiusa</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Bottom Left Radiusa</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderBottomLeftRadiusa()
   * @generated
   */
  void setBorderBottomLeftRadiusa(entier value);

  /**
   * Returns the value of the '<em><b>Border Bottom Right Radiusa</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Bottom Right Radiusa</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Bottom Right Radiusa</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderBottomRightRadiusa(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_BorderBottomRightRadiusa()
   * @model
   * @generated
   */
  entier getBorderBottomRightRadiusa();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderBottomRightRadiusa <em>Border Bottom Right Radiusa</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Bottom Right Radiusa</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderBottomRightRadiusa()
   * @generated
   */
  void setBorderBottomRightRadiusa(entier value);

  /**
   * Returns the value of the '<em><b>Border Colora</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Colors}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Colora</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Colora</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #setBorderColora(Colors)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_BorderColora()
   * @model
   * @generated
   */
  Colors getBorderColora();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderColora <em>Border Colora</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Colora</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #getBorderColora()
   * @generated
   */
  void setBorderColora(Colors value);

  /**
   * Returns the value of the '<em><b>Border Radiusa</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Radiusa</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Radiusa</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderRadiusa(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_BorderRadiusa()
   * @model
   * @generated
   */
  entier getBorderRadiusa();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderRadiusa <em>Border Radiusa</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Radiusa</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderRadiusa()
   * @generated
   */
  void setBorderRadiusa(entier value);

  /**
   * Returns the value of the '<em><b>Border Top Left Radiusa</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Top Left Radiusa</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Top Left Radiusa</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderTopLeftRadiusa(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_BorderTopLeftRadiusa()
   * @model
   * @generated
   */
  entier getBorderTopLeftRadiusa();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderTopLeftRadiusa <em>Border Top Left Radiusa</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Top Left Radiusa</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderTopLeftRadiusa()
   * @generated
   */
  void setBorderTopLeftRadiusa(entier value);

  /**
   * Returns the value of the '<em><b>Border Top Right Radiusa</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Top Right Radiusa</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Top Right Radiusa</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderTopRightRadiusa(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_BorderTopRightRadiusa()
   * @model
   * @generated
   */
  entier getBorderTopRightRadiusa();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderTopRightRadiusa <em>Border Top Right Radiusa</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Top Right Radiusa</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderTopRightRadiusa()
   * @generated
   */
  void setBorderTopRightRadiusa(entier value);

  /**
   * Returns the value of the '<em><b>Border Widtha</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Widtha</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Widtha</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderWidtha(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_BorderWidtha()
   * @model
   * @generated
   */
  entier getBorderWidtha();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderWidtha <em>Border Widtha</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Widtha</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderWidtha()
   * @generated
   */
  void setBorderWidtha(entier value);

  /**
   * Returns the value of the '<em><b>Opacitya</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Opacitya</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Opacitya</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setOpacitya(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_Opacitya()
   * @model
   * @generated
   */
  entier getOpacitya();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getOpacitya <em>Opacitya</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Opacitya</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getOpacitya()
   * @generated
   */
  void setOpacitya(entier value);

  /**
   * Returns the value of the '<em><b>Overflowa</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Overflowa</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Overflowa</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setOverflowa(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_Overflowa()
   * @model
   * @generated
   */
  entier getOverflowa();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getOverflowa <em>Overflowa</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Overflowa</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getOverflowa()
   * @generated
   */
  void setOverflowa(entier value);

  /**
   * Returns the value of the '<em><b>Align Itemst</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.aliIT}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Align Itemst</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Align Itemst</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.aliIT
   * @see #setAlignItemst(aliIT)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_AlignItemst()
   * @model
   * @generated
   */
  aliIT getAlignItemst();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getAlignItemst <em>Align Itemst</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Align Itemst</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.aliIT
   * @see #getAlignItemst()
   * @generated
   */
  void setAlignItemst(aliIT value);

  /**
   * Returns the value of the '<em><b>Align Selft</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.alfem}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Align Selft</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Align Selft</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.alfem
   * @see #setAlignSelft(alfem)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_AlignSelft()
   * @model
   * @generated
   */
  alfem getAlignSelft();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getAlignSelft <em>Align Selft</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Align Selft</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.alfem
   * @see #getAlignSelft()
   * @generated
   */
  void setAlignSelft(alfem value);

  /**
   * Returns the value of the '<em><b>Bottomt</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Bottomt</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Bottomt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBottomt(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_Bottomt()
   * @model
   * @generated
   */
  entier getBottomt();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBottomt <em>Bottomt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Bottomt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBottomt()
   * @generated
   */
  void setBottomt(entier value);

  /**
   * Returns the value of the '<em><b>Flext</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Flext</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Flext</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setFlext(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_Flext()
   * @model
   * @generated
   */
  entier getFlext();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getFlext <em>Flext</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Flext</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getFlext()
   * @generated
   */
  void setFlext(entier value);

  /**
   * Returns the value of the '<em><b>Justify Contente</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.JustifyContentType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Justify Contente</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Justify Contente</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.JustifyContentType
   * @see #setJustifyContente(JustifyContentType)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_JustifyContente()
   * @model
   * @generated
   */
  JustifyContentType getJustifyContente();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getJustifyContente <em>Justify Contente</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Justify Contente</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.JustifyContentType
   * @see #getJustifyContente()
   * @generated
   */
  void setJustifyContente(JustifyContentType value);

  /**
   * Returns the value of the '<em><b>Lefte</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Lefte</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Lefte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setLefte(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_Lefte()
   * @model
   * @generated
   */
  entier getLefte();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getLefte <em>Lefte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Lefte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getLefte()
   * @generated
   */
  void setLefte(entier value);

  /**
   * Returns the value of the '<em><b>Margin</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Margin</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Margin</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setMargin(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_Margin()
   * @model
   * @generated
   */
  entier getMargin();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMargin <em>Margin</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Margin</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getMargin()
   * @generated
   */
  void setMargin(entier value);

  /**
   * Returns the value of the '<em><b>Margin Bottome</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Margin Bottome</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Margin Bottome</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setMarginBottome(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_MarginBottome()
   * @model
   * @generated
   */
  entier getMarginBottome();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMarginBottome <em>Margin Bottome</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Margin Bottome</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getMarginBottome()
   * @generated
   */
  void setMarginBottome(entier value);

  /**
   * Returns the value of the '<em><b>Margin Lefte</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Margin Lefte</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Margin Lefte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setMarginLefte(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_MarginLefte()
   * @model
   * @generated
   */
  entier getMarginLefte();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMarginLefte <em>Margin Lefte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Margin Lefte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getMarginLefte()
   * @generated
   */
  void setMarginLefte(entier value);

  /**
   * Returns the value of the '<em><b>Margin Righte</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Margin Righte</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Margin Righte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setMarginRighte(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_MarginRighte()
   * @model
   * @generated
   */
  entier getMarginRighte();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMarginRighte <em>Margin Righte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Margin Righte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getMarginRighte()
   * @generated
   */
  void setMarginRighte(entier value);

  /**
   * Returns the value of the '<em><b>Margin Tope</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Margin Tope</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Margin Tope</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setMarginTope(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_MarginTope()
   * @model
   * @generated
   */
  entier getMarginTope();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMarginTope <em>Margin Tope</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Margin Tope</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getMarginTope()
   * @generated
   */
  void setMarginTope(entier value);

  /**
   * Returns the value of the '<em><b>Margin Verticale</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Margin Verticale</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Margin Verticale</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setMarginVerticale(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_MarginVerticale()
   * @model
   * @generated
   */
  entier getMarginVerticale();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMarginVerticale <em>Margin Verticale</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Margin Verticale</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getMarginVerticale()
   * @generated
   */
  void setMarginVerticale(entier value);

  /**
   * Returns the value of the '<em><b>Paddingt</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Paddingt</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Paddingt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setPaddingt(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_Paddingt()
   * @model
   * @generated
   */
  entier getPaddingt();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingt <em>Paddingt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Paddingt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getPaddingt()
   * @generated
   */
  void setPaddingt(entier value);

  /**
   * Returns the value of the '<em><b>Padding Bottomt</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Padding Bottomt</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Padding Bottomt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setPaddingBottomt(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_PaddingBottomt()
   * @model
   * @generated
   */
  entier getPaddingBottomt();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingBottomt <em>Padding Bottomt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Padding Bottomt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getPaddingBottomt()
   * @generated
   */
  void setPaddingBottomt(entier value);

  /**
   * Returns the value of the '<em><b>Padding Horizontale</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Padding Horizontale</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Padding Horizontale</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setPaddingHorizontale(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_PaddingHorizontale()
   * @model
   * @generated
   */
  entier getPaddingHorizontale();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingHorizontale <em>Padding Horizontale</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Padding Horizontale</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getPaddingHorizontale()
   * @generated
   */
  void setPaddingHorizontale(entier value);

  /**
   * Returns the value of the '<em><b>Padding Righte</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Padding Righte</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Padding Righte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setPaddingRighte(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_PaddingRighte()
   * @model
   * @generated
   */
  entier getPaddingRighte();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingRighte <em>Padding Righte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Padding Righte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getPaddingRighte()
   * @generated
   */
  void setPaddingRighte(entier value);

  /**
   * Returns the value of the '<em><b>Padding Tope</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Padding Tope</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Padding Tope</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setPaddingTope(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_PaddingTope()
   * @model
   * @generated
   */
  entier getPaddingTope();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingTope <em>Padding Tope</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Padding Tope</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getPaddingTope()
   * @generated
   */
  void setPaddingTope(entier value);

  /**
   * Returns the value of the '<em><b>Padding Verticale</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Padding Verticale</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Padding Verticale</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setPaddingVerticale(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_PaddingVerticale()
   * @model
   * @generated
   */
  entier getPaddingVerticale();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingVerticale <em>Padding Verticale</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Padding Verticale</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getPaddingVerticale()
   * @generated
   */
  void setPaddingVerticale(entier value);

  /**
   * Returns the value of the '<em><b>Rightt</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Rightt</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Rightt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setRightt(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_Rightt()
   * @model
   * @generated
   */
  entier getRightt();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getRightt <em>Rightt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Rightt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getRightt()
   * @generated
   */
  void setRightt(entier value);

  /**
   * Returns the value of the '<em><b>Widtht</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Widtht</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Widtht</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setWidtht(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_Widtht()
   * @model
   * @generated
   */
  entier getWidtht();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getWidtht <em>Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Widtht</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getWidtht()
   * @generated
   */
  void setWidtht(entier value);

  /**
   * Returns the value of the '<em><b>Flex Directiont</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.flexd}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Flex Directiont</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Flex Directiont</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.flexd
   * @see #setFlexDirectiont(flexd)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_FlexDirectiont()
   * @model
   * @generated
   */
  flexd getFlexDirectiont();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getFlexDirectiont <em>Flex Directiont</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Flex Directiont</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.flexd
   * @see #getFlexDirectiont()
   * @generated
   */
  void setFlexDirectiont(flexd value);

  /**
   * Returns the value of the '<em><b>Flex Wrapt</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.One}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Flex Wrapt</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Flex Wrapt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.One
   * @see #setFlexWrapt(One)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_FlexWrapt()
   * @model
   * @generated
   */
  One getFlexWrapt();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getFlexWrapt <em>Flex Wrapt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Flex Wrapt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.One
   * @see #getFlexWrapt()
   * @generated
   */
  void setFlexWrapt(One value);

  /**
   * Returns the value of the '<em><b>Heighte</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Heighte</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Heighte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setHeighte(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleImage_Heighte()
   * @model
   * @generated
   */
  entier getHeighte();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getHeighte <em>Heighte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Heighte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getHeighte()
   * @generated
   */
  void setHeighte(entier value);

} // StyleImage
