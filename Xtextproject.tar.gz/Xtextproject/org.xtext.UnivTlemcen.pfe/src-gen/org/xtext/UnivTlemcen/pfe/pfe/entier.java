/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>entier</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getentier()
 * @model
 * @generated
 */
public enum entier implements Enumerator
{
  /**
   * The '<em><b>None</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #NONE_VALUE
   * @generated
   * @ordered
   */
  NONE(0, "none", "none"),

  /**
   * The '<em><b>Un</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #UN_VALUE
   * @generated
   * @ordered
   */
  UN(1, "Un", "1"),

  /**
   * The '<em><b>Deux</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #DEUX_VALUE
   * @generated
   * @ordered
   */
  DEUX(2, "deux", "2"),

  /**
   * The '<em><b>Trois</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #TROIS_VALUE
   * @generated
   * @ordered
   */
  TROIS(3, "trois", "3"),

  /**
   * The '<em><b>Qutre</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #QUTRE_VALUE
   * @generated
   * @ordered
   */
  QUTRE(4, "qutre", "4"),

  /**
   * The '<em><b>Cinq</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #CINQ_VALUE
   * @generated
   * @ordered
   */
  CINQ(5, "cinq", "5"),

  /**
   * The '<em><b>Six</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #SIX_VALUE
   * @generated
   * @ordered
   */
  SIX(6, "six", "6"),

  /**
   * The '<em><b>Sept</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #SEPT_VALUE
   * @generated
   * @ordered
   */
  SEPT(7, "sept", "7"),

  /**
   * The '<em><b>Huite</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #HUITE_VALUE
   * @generated
   * @ordered
   */
  HUITE(8, "Huite", "8"),

  /**
   * The '<em><b>Nf</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #NF_VALUE
   * @generated
   * @ordered
   */
  NF(9, "nf", "9"),

  /**
   * The '<em><b>Dix</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #DIX_VALUE
   * @generated
   * @ordered
   */
  DIX(10, "dix", "10"),

  /**
   * The '<em><b>En</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #EN_VALUE
   * @generated
   * @ordered
   */
  EN(11, "En", "11"),

  /**
   * The '<em><b>Dz</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #DZ_VALUE
   * @generated
   * @ordered
   */
  DZ(12, "dz", "12"),

  /**
   * The '<em><b>Tr</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #TR_VALUE
   * @generated
   * @ordered
   */
  TR(13, "Tr", "13"),

  /**
   * The '<em><b>Quat</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #QUAT_VALUE
   * @generated
   * @ordered
   */
  QUAT(14, "Quat", "14"),

  /**
   * The '<em><b>QZ</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #QZ_VALUE
   * @generated
   * @ordered
   */
  QZ(15, "QZ", "15"),

  /**
   * The '<em><b>Sz</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #SZ_VALUE
   * @generated
   * @ordered
   */
  SZ(16, "sz", "16"),

  /**
   * The '<em><b>Ds</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #DS_VALUE
   * @generated
   * @ordered
   */
  DS(17, "ds", "17"),

  /**
   * The '<em><b>Dh</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #DH_VALUE
   * @generated
   * @ordered
   */
  DH(18, "dh", "18"),

  /**
   * The '<em><b>Dn</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #DN_VALUE
   * @generated
   * @ordered
   */
  DN(19, "dn", "19"),

  /**
   * The '<em><b>Vn</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #VN_VALUE
   * @generated
   * @ordered
   */
  VN(20, "Vn", "20"),

  /**
   * The '<em><b>Vi</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #VI_VALUE
   * @generated
   * @ordered
   */
  VI(21, "Vi", "21"),

  /**
   * The '<em><b>Vd</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #VD_VALUE
   * @generated
   * @ordered
   */
  VD(22, "vd", "22"),

  /**
   * The '<em><b>Vt</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #VT_VALUE
   * @generated
   * @ordered
   */
  VT(23, "vt", "23"),

  /**
   * The '<em><b>Vq</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #VQ_VALUE
   * @generated
   * @ordered
   */
  VQ(24, "vq", "24"),

  /**
   * The '<em><b>Vs</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #VS_VALUE
   * @generated
   * @ordered
   */
  VS(25, "vs", "25");

  /**
   * The '<em><b>None</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>None</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #NONE
   * @model name="none"
   * @generated
   * @ordered
   */
  public static final int NONE_VALUE = 0;

  /**
   * The '<em><b>Un</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Un</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #UN
   * @model name="Un" literal="1"
   * @generated
   * @ordered
   */
  public static final int UN_VALUE = 1;

  /**
   * The '<em><b>Deux</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Deux</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #DEUX
   * @model name="deux" literal="2"
   * @generated
   * @ordered
   */
  public static final int DEUX_VALUE = 2;

  /**
   * The '<em><b>Trois</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Trois</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #TROIS
   * @model name="trois" literal="3"
   * @generated
   * @ordered
   */
  public static final int TROIS_VALUE = 3;

  /**
   * The '<em><b>Qutre</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Qutre</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #QUTRE
   * @model name="qutre" literal="4"
   * @generated
   * @ordered
   */
  public static final int QUTRE_VALUE = 4;

  /**
   * The '<em><b>Cinq</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Cinq</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #CINQ
   * @model name="cinq" literal="5"
   * @generated
   * @ordered
   */
  public static final int CINQ_VALUE = 5;

  /**
   * The '<em><b>Six</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Six</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #SIX
   * @model name="six" literal="6"
   * @generated
   * @ordered
   */
  public static final int SIX_VALUE = 6;

  /**
   * The '<em><b>Sept</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Sept</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #SEPT
   * @model name="sept" literal="7"
   * @generated
   * @ordered
   */
  public static final int SEPT_VALUE = 7;

  /**
   * The '<em><b>Huite</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Huite</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #HUITE
   * @model name="Huite" literal="8"
   * @generated
   * @ordered
   */
  public static final int HUITE_VALUE = 8;

  /**
   * The '<em><b>Nf</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Nf</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #NF
   * @model name="nf" literal="9"
   * @generated
   * @ordered
   */
  public static final int NF_VALUE = 9;

  /**
   * The '<em><b>Dix</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Dix</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #DIX
   * @model name="dix" literal="10"
   * @generated
   * @ordered
   */
  public static final int DIX_VALUE = 10;

  /**
   * The '<em><b>En</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>En</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #EN
   * @model name="En" literal="11"
   * @generated
   * @ordered
   */
  public static final int EN_VALUE = 11;

  /**
   * The '<em><b>Dz</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Dz</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #DZ
   * @model name="dz" literal="12"
   * @generated
   * @ordered
   */
  public static final int DZ_VALUE = 12;

  /**
   * The '<em><b>Tr</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Tr</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #TR
   * @model name="Tr" literal="13"
   * @generated
   * @ordered
   */
  public static final int TR_VALUE = 13;

  /**
   * The '<em><b>Quat</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Quat</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #QUAT
   * @model name="Quat" literal="14"
   * @generated
   * @ordered
   */
  public static final int QUAT_VALUE = 14;

  /**
   * The '<em><b>QZ</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>QZ</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #QZ
   * @model literal="15"
   * @generated
   * @ordered
   */
  public static final int QZ_VALUE = 15;

  /**
   * The '<em><b>Sz</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Sz</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #SZ
   * @model name="sz" literal="16"
   * @generated
   * @ordered
   */
  public static final int SZ_VALUE = 16;

  /**
   * The '<em><b>Ds</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Ds</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #DS
   * @model name="ds" literal="17"
   * @generated
   * @ordered
   */
  public static final int DS_VALUE = 17;

  /**
   * The '<em><b>Dh</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Dh</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #DH
   * @model name="dh" literal="18"
   * @generated
   * @ordered
   */
  public static final int DH_VALUE = 18;

  /**
   * The '<em><b>Dn</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Dn</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #DN
   * @model name="dn" literal="19"
   * @generated
   * @ordered
   */
  public static final int DN_VALUE = 19;

  /**
   * The '<em><b>Vn</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Vn</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #VN
   * @model name="Vn" literal="20"
   * @generated
   * @ordered
   */
  public static final int VN_VALUE = 20;

  /**
   * The '<em><b>Vi</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Vi</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #VI
   * @model name="Vi" literal="21"
   * @generated
   * @ordered
   */
  public static final int VI_VALUE = 21;

  /**
   * The '<em><b>Vd</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Vd</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #VD
   * @model name="vd" literal="22"
   * @generated
   * @ordered
   */
  public static final int VD_VALUE = 22;

  /**
   * The '<em><b>Vt</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Vt</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #VT
   * @model name="vt" literal="23"
   * @generated
   * @ordered
   */
  public static final int VT_VALUE = 23;

  /**
   * The '<em><b>Vq</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Vq</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #VQ
   * @model name="vq" literal="24"
   * @generated
   * @ordered
   */
  public static final int VQ_VALUE = 24;

  /**
   * The '<em><b>Vs</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Vs</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #VS
   * @model name="vs" literal="25"
   * @generated
   * @ordered
   */
  public static final int VS_VALUE = 25;

  /**
   * An array of all the '<em><b>entier</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static final entier[] VALUES_ARRAY =
    new entier[]
    {
      NONE,
      UN,
      DEUX,
      TROIS,
      QUTRE,
      CINQ,
      SIX,
      SEPT,
      HUITE,
      NF,
      DIX,
      EN,
      DZ,
      TR,
      QUAT,
      QZ,
      SZ,
      DS,
      DH,
      DN,
      VN,
      VI,
      VD,
      VT,
      VQ,
      VS,
    };

  /**
   * A public read-only list of all the '<em><b>entier</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static final List<entier> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

  /**
   * Returns the '<em><b>entier</b></em>' literal with the specified literal value.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static entier get(String literal)
  {
    for (int i = 0; i < VALUES_ARRAY.length; ++i)
    {
      entier result = VALUES_ARRAY[i];
      if (result.toString().equals(literal))
      {
        return result;
      }
    }
    return null;
  }

  /**
   * Returns the '<em><b>entier</b></em>' literal with the specified name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static entier getByName(String name)
  {
    for (int i = 0; i < VALUES_ARRAY.length; ++i)
    {
      entier result = VALUES_ARRAY[i];
      if (result.getName().equals(name))
      {
        return result;
      }
    }
    return null;
  }

  /**
   * Returns the '<em><b>entier</b></em>' literal with the specified integer value.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static entier get(int value)
  {
    switch (value)
    {
      case NONE_VALUE: return NONE;
      case UN_VALUE: return UN;
      case DEUX_VALUE: return DEUX;
      case TROIS_VALUE: return TROIS;
      case QUTRE_VALUE: return QUTRE;
      case CINQ_VALUE: return CINQ;
      case SIX_VALUE: return SIX;
      case SEPT_VALUE: return SEPT;
      case HUITE_VALUE: return HUITE;
      case NF_VALUE: return NF;
      case DIX_VALUE: return DIX;
      case EN_VALUE: return EN;
      case DZ_VALUE: return DZ;
      case TR_VALUE: return TR;
      case QUAT_VALUE: return QUAT;
      case QZ_VALUE: return QZ;
      case SZ_VALUE: return SZ;
      case DS_VALUE: return DS;
      case DH_VALUE: return DH;
      case DN_VALUE: return DN;
      case VN_VALUE: return VN;
      case VI_VALUE: return VI;
      case VD_VALUE: return VD;
      case VT_VALUE: return VT;
      case VQ_VALUE: return VQ;
      case VS_VALUE: return VS;
    }
    return null;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final int value;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final String name;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final String literal;

  /**
   * Only this class can construct instances.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private entier(int value, String name, String literal)
  {
    this.value = value;
    this.name = name;
    this.literal = literal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public int getValue()
  {
    return value;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getLiteral()
  {
    return literal;
  }

  /**
   * Returns the literal value of the enumerator, which is its string representation.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    return literal;
  }
  
} //entier
