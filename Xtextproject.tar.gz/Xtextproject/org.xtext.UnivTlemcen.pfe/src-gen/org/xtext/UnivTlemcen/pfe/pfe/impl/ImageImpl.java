/**
 */
package org.xtext.UnivTlemcen.pfe.pfe.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.xtext.UnivTlemcen.pfe.pfe.Image;
import org.xtext.UnivTlemcen.pfe.pfe.LC;
import org.xtext.UnivTlemcen.pfe.pfe.PfePackage;
import org.xtext.UnivTlemcen.pfe.pfe.StyleImage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Image</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ImageImpl#getUrl <em>Url</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ImageImpl#getLigne <em>Ligne</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ImageImpl#getColone <em>Colone</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ImageImpl#getStyle <em>Style</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ImageImpl extends composantImpl implements Image
{
  /**
   * The default value of the '{@link #getUrl() <em>Url</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUrl()
   * @generated
   * @ordered
   */
  protected static final String URL_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getUrl() <em>Url</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getUrl()
   * @generated
   * @ordered
   */
  protected String url = URL_EDEFAULT;

  /**
   * The default value of the '{@link #getLigne() <em>Ligne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLigne()
   * @generated
   * @ordered
   */
  protected static final LC LIGNE_EDEFAULT = LC.UN;

  /**
   * The cached value of the '{@link #getLigne() <em>Ligne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLigne()
   * @generated
   * @ordered
   */
  protected LC ligne = LIGNE_EDEFAULT;

  /**
   * The default value of the '{@link #getColone() <em>Colone</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getColone()
   * @generated
   * @ordered
   */
  protected static final LC COLONE_EDEFAULT = LC.UN;

  /**
   * The cached value of the '{@link #getColone() <em>Colone</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getColone()
   * @generated
   * @ordered
   */
  protected LC colone = COLONE_EDEFAULT;

  /**
   * The cached value of the '{@link #getStyle() <em>Style</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getStyle()
   * @generated
   * @ordered
   */
  protected StyleImage style;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ImageImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return PfePackage.Literals.IMAGE;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getUrl()
  {
    return url;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setUrl(String newUrl)
  {
    String oldUrl = url;
    url = newUrl;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.IMAGE__URL, oldUrl, url));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LC getLigne()
  {
    return ligne;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLigne(LC newLigne)
  {
    LC oldLigne = ligne;
    ligne = newLigne == null ? LIGNE_EDEFAULT : newLigne;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.IMAGE__LIGNE, oldLigne, ligne));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public LC getColone()
  {
    return colone;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setColone(LC newColone)
  {
    LC oldColone = colone;
    colone = newColone == null ? COLONE_EDEFAULT : newColone;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.IMAGE__COLONE, oldColone, colone));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public StyleImage getStyle()
  {
    if (style != null && style.eIsProxy())
    {
      InternalEObject oldStyle = (InternalEObject)style;
      style = (StyleImage)eResolveProxy(oldStyle);
      if (style != oldStyle)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, PfePackage.IMAGE__STYLE, oldStyle, style));
      }
    }
    return style;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public StyleImage basicGetStyle()
  {
    return style;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setStyle(StyleImage newStyle)
  {
    StyleImage oldStyle = style;
    style = newStyle;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.IMAGE__STYLE, oldStyle, style));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case PfePackage.IMAGE__URL:
        return getUrl();
      case PfePackage.IMAGE__LIGNE:
        return getLigne();
      case PfePackage.IMAGE__COLONE:
        return getColone();
      case PfePackage.IMAGE__STYLE:
        if (resolve) return getStyle();
        return basicGetStyle();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case PfePackage.IMAGE__URL:
        setUrl((String)newValue);
        return;
      case PfePackage.IMAGE__LIGNE:
        setLigne((LC)newValue);
        return;
      case PfePackage.IMAGE__COLONE:
        setColone((LC)newValue);
        return;
      case PfePackage.IMAGE__STYLE:
        setStyle((StyleImage)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.IMAGE__URL:
        setUrl(URL_EDEFAULT);
        return;
      case PfePackage.IMAGE__LIGNE:
        setLigne(LIGNE_EDEFAULT);
        return;
      case PfePackage.IMAGE__COLONE:
        setColone(COLONE_EDEFAULT);
        return;
      case PfePackage.IMAGE__STYLE:
        setStyle((StyleImage)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.IMAGE__URL:
        return URL_EDEFAULT == null ? url != null : !URL_EDEFAULT.equals(url);
      case PfePackage.IMAGE__LIGNE:
        return ligne != LIGNE_EDEFAULT;
      case PfePackage.IMAGE__COLONE:
        return colone != COLONE_EDEFAULT;
      case PfePackage.IMAGE__STYLE:
        return style != null;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (Url: ");
    result.append(url);
    result.append(", ligne: ");
    result.append(ligne);
    result.append(", colone: ");
    result.append(colone);
    result.append(')');
    return result.toString();
  }

} //ImageImpl
