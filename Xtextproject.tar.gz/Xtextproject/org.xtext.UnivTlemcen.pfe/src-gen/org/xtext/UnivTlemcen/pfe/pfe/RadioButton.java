/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Radio Button</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.RadioButton#getName <em>Name</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.RadioButton#getLigne <em>Ligne</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.RadioButton#getColonne <em>Colonne</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.RadioButton#getStyle <em>Style</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getRadioButton()
 * @model
 * @generated
 */
public interface RadioButton extends Elements
{
  /**
   * Returns the value of the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' attribute.
   * @see #setName(String)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getRadioButton_Name()
   * @model
   * @generated
   */
  String getName();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.RadioButton#getName <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name</em>' attribute.
   * @see #getName()
   * @generated
   */
  void setName(String value);

  /**
   * Returns the value of the '<em><b>Ligne</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.LC}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Ligne</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Ligne</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #setLigne(LC)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getRadioButton_Ligne()
   * @model
   * @generated
   */
  LC getLigne();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.RadioButton#getLigne <em>Ligne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Ligne</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #getLigne()
   * @generated
   */
  void setLigne(LC value);

  /**
   * Returns the value of the '<em><b>Colonne</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.LC}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Colonne</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Colonne</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #setColonne(LC)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getRadioButton_Colonne()
   * @model
   * @generated
   */
  LC getColonne();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.RadioButton#getColonne <em>Colonne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Colonne</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #getColonne()
   * @generated
   */
  void setColonne(LC value);

  /**
   * Returns the value of the '<em><b>Style</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Style</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Style</em>' reference.
   * @see #setStyle(StyleView)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getRadioButton_Style()
   * @model
   * @generated
   */
  StyleView getStyle();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.RadioButton#getStyle <em>Style</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Style</em>' reference.
   * @see #getStyle()
   * @generated
   */
  void setStyle(StyleView value);

} // RadioButton
