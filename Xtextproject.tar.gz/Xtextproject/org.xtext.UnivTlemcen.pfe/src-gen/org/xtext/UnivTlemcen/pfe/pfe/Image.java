/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Image</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Image#getUrl <em>Url</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Image#getLigne <em>Ligne</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Image#getColone <em>Colone</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Image#getStyle <em>Style</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getImage()
 * @model
 * @generated
 */
public interface Image extends composant
{
  /**
   * Returns the value of the '<em><b>Url</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Url</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Url</em>' attribute.
   * @see #setUrl(String)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getImage_Url()
   * @model
   * @generated
   */
  String getUrl();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Image#getUrl <em>Url</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Url</em>' attribute.
   * @see #getUrl()
   * @generated
   */
  void setUrl(String value);

  /**
   * Returns the value of the '<em><b>Ligne</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.LC}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Ligne</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Ligne</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #setLigne(LC)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getImage_Ligne()
   * @model
   * @generated
   */
  LC getLigne();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Image#getLigne <em>Ligne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Ligne</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #getLigne()
   * @generated
   */
  void setLigne(LC value);

  /**
   * Returns the value of the '<em><b>Colone</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.LC}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Colone</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Colone</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #setColone(LC)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getImage_Colone()
   * @model
   * @generated
   */
  LC getColone();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Image#getColone <em>Colone</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Colone</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #getColone()
   * @generated
   */
  void setColone(LC value);

  /**
   * Returns the value of the '<em><b>Style</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Style</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Style</em>' reference.
   * @see #setStyle(StyleImage)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getImage_Style()
   * @model
   * @generated
   */
  StyleImage getStyle();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Image#getStyle <em>Style</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Style</em>' reference.
   * @see #getStyle()
   * @generated
   */
  void setStyle(StyleImage value);

} // Image
