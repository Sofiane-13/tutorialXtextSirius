/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Social Icon Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getSocialIconType()
 * @model
 * @generated
 */
public enum SocialIconType implements Enumerator
{
  /**
   * The '<em><b>None</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #NONE_VALUE
   * @generated
   * @ordered
   */
  NONE(0, "none", "none"),

  /**
   * The '<em><b>Facebook</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #FACEBOOK_VALUE
   * @generated
   * @ordered
   */
  FACEBOOK(1, "facebook", "facebook"),

  /**
   * The '<em><b>Twitter</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #TWITTER_VALUE
   * @generated
   * @ordered
   */
  TWITTER(2, "twitter", "twitter"),

  /**
   * The '<em><b>Pinterest</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #PINTEREST_VALUE
   * @generated
   * @ordered
   */
  PINTEREST(3, "pinterest", "pinterest"),

  /**
   * The '<em><b>Linkedin</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #LINKEDIN_VALUE
   * @generated
   * @ordered
   */
  LINKEDIN(4, "linkedin", "linkedin"),

  /**
   * The '<em><b>Youtube</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #YOUTUBE_VALUE
   * @generated
   * @ordered
   */
  YOUTUBE(5, "youtube", "youtube"),

  /**
   * The '<em><b>Vimeo</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #VIMEO_VALUE
   * @generated
   * @ordered
   */
  VIMEO(6, "vimeo", "vimeo"),

  /**
   * The '<em><b>Tumblr</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #TUMBLR_VALUE
   * @generated
   * @ordered
   */
  TUMBLR(7, "tumblr", "tumblr"),

  /**
   * The '<em><b>Instagram</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #INSTAGRAM_VALUE
   * @generated
   * @ordered
   */
  INSTAGRAM(8, "instagram", "instagram"),

  /**
   * The '<em><b>Quora</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #QUORA_VALUE
   * @generated
   * @ordered
   */
  QUORA(9, "quora", "quora"),

  /**
   * The '<em><b>Foursquare</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #FOURSQUARE_VALUE
   * @generated
   * @ordered
   */
  FOURSQUARE(10, "foursquare", "foursquare"),

  /**
   * The '<em><b>Wordpress</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #WORDPRESS_VALUE
   * @generated
   * @ordered
   */
  WORDPRESS(11, "wordpress", "wordpress"),

  /**
   * The '<em><b>Stumbleupon</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #STUMBLEUPON_VALUE
   * @generated
   * @ordered
   */
  STUMBLEUPON(12, "stumbleupon", "stumbleupon"),

  /**
   * The '<em><b>Github</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #GITHUB_VALUE
   * @generated
   * @ordered
   */
  GITHUB(13, "github", "github"),

  /**
   * The '<em><b>Twitch</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #TWITCH_VALUE
   * @generated
   * @ordered
   */
  TWITCH(14, "twitch", " twitch"),

  /**
   * The '<em><b>Medium</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #MEDIUM_VALUE
   * @generated
   * @ordered
   */
  MEDIUM(15, "medium", "medium"),

  /**
   * The '<em><b>Soundcloud</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #SOUNDCLOUD_VALUE
   * @generated
   * @ordered
   */
  SOUNDCLOUD(16, "soundcloud", "soundcloud"),

  /**
   * The '<em><b>Gitlab</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #GITLAB_VALUE
   * @generated
   * @ordered
   */
  GITLAB(17, "gitlab", "gitlab"),

  /**
   * The '<em><b>Angellist</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #ANGELLIST_VALUE
   * @generated
   * @ordered
   */
  ANGELLIST(18, "angellist", "angellist"),

  /**
   * The '<em><b>Codepen</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #CODEPEN_VALUE
   * @generated
   * @ordered
   */
  CODEPEN(19, "codepen", "codepen");

  /**
   * The '<em><b>None</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>None</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #NONE
   * @model name="none"
   * @generated
   * @ordered
   */
  public static final int NONE_VALUE = 0;

  /**
   * The '<em><b>Facebook</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Facebook</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #FACEBOOK
   * @model name="facebook"
   * @generated
   * @ordered
   */
  public static final int FACEBOOK_VALUE = 1;

  /**
   * The '<em><b>Twitter</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Twitter</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #TWITTER
   * @model name="twitter"
   * @generated
   * @ordered
   */
  public static final int TWITTER_VALUE = 2;

  /**
   * The '<em><b>Pinterest</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Pinterest</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #PINTEREST
   * @model name="pinterest"
   * @generated
   * @ordered
   */
  public static final int PINTEREST_VALUE = 3;

  /**
   * The '<em><b>Linkedin</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Linkedin</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #LINKEDIN
   * @model name="linkedin"
   * @generated
   * @ordered
   */
  public static final int LINKEDIN_VALUE = 4;

  /**
   * The '<em><b>Youtube</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Youtube</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #YOUTUBE
   * @model name="youtube"
   * @generated
   * @ordered
   */
  public static final int YOUTUBE_VALUE = 5;

  /**
   * The '<em><b>Vimeo</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Vimeo</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #VIMEO
   * @model name="vimeo"
   * @generated
   * @ordered
   */
  public static final int VIMEO_VALUE = 6;

  /**
   * The '<em><b>Tumblr</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Tumblr</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #TUMBLR
   * @model name="tumblr"
   * @generated
   * @ordered
   */
  public static final int TUMBLR_VALUE = 7;

  /**
   * The '<em><b>Instagram</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Instagram</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #INSTAGRAM
   * @model name="instagram"
   * @generated
   * @ordered
   */
  public static final int INSTAGRAM_VALUE = 8;

  /**
   * The '<em><b>Quora</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Quora</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #QUORA
   * @model name="quora"
   * @generated
   * @ordered
   */
  public static final int QUORA_VALUE = 9;

  /**
   * The '<em><b>Foursquare</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Foursquare</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #FOURSQUARE
   * @model name="foursquare"
   * @generated
   * @ordered
   */
  public static final int FOURSQUARE_VALUE = 10;

  /**
   * The '<em><b>Wordpress</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Wordpress</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #WORDPRESS
   * @model name="wordpress"
   * @generated
   * @ordered
   */
  public static final int WORDPRESS_VALUE = 11;

  /**
   * The '<em><b>Stumbleupon</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Stumbleupon</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #STUMBLEUPON
   * @model name="stumbleupon"
   * @generated
   * @ordered
   */
  public static final int STUMBLEUPON_VALUE = 12;

  /**
   * The '<em><b>Github</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Github</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #GITHUB
   * @model name="github"
   * @generated
   * @ordered
   */
  public static final int GITHUB_VALUE = 13;

  /**
   * The '<em><b>Twitch</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Twitch</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #TWITCH
   * @model name="twitch" literal=" twitch"
   * @generated
   * @ordered
   */
  public static final int TWITCH_VALUE = 14;

  /**
   * The '<em><b>Medium</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Medium</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #MEDIUM
   * @model name="medium"
   * @generated
   * @ordered
   */
  public static final int MEDIUM_VALUE = 15;

  /**
   * The '<em><b>Soundcloud</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Soundcloud</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #SOUNDCLOUD
   * @model name="soundcloud"
   * @generated
   * @ordered
   */
  public static final int SOUNDCLOUD_VALUE = 16;

  /**
   * The '<em><b>Gitlab</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Gitlab</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #GITLAB
   * @model name="gitlab"
   * @generated
   * @ordered
   */
  public static final int GITLAB_VALUE = 17;

  /**
   * The '<em><b>Angellist</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Angellist</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #ANGELLIST
   * @model name="angellist"
   * @generated
   * @ordered
   */
  public static final int ANGELLIST_VALUE = 18;

  /**
   * The '<em><b>Codepen</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Codepen</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #CODEPEN
   * @model name="codepen"
   * @generated
   * @ordered
   */
  public static final int CODEPEN_VALUE = 19;

  /**
   * An array of all the '<em><b>Social Icon Type</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static final SocialIconType[] VALUES_ARRAY =
    new SocialIconType[]
    {
      NONE,
      FACEBOOK,
      TWITTER,
      PINTEREST,
      LINKEDIN,
      YOUTUBE,
      VIMEO,
      TUMBLR,
      INSTAGRAM,
      QUORA,
      FOURSQUARE,
      WORDPRESS,
      STUMBLEUPON,
      GITHUB,
      TWITCH,
      MEDIUM,
      SOUNDCLOUD,
      GITLAB,
      ANGELLIST,
      CODEPEN,
    };

  /**
   * A public read-only list of all the '<em><b>Social Icon Type</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static final List<SocialIconType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

  /**
   * Returns the '<em><b>Social Icon Type</b></em>' literal with the specified literal value.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static SocialIconType get(String literal)
  {
    for (int i = 0; i < VALUES_ARRAY.length; ++i)
    {
      SocialIconType result = VALUES_ARRAY[i];
      if (result.toString().equals(literal))
      {
        return result;
      }
    }
    return null;
  }

  /**
   * Returns the '<em><b>Social Icon Type</b></em>' literal with the specified name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static SocialIconType getByName(String name)
  {
    for (int i = 0; i < VALUES_ARRAY.length; ++i)
    {
      SocialIconType result = VALUES_ARRAY[i];
      if (result.getName().equals(name))
      {
        return result;
      }
    }
    return null;
  }

  /**
   * Returns the '<em><b>Social Icon Type</b></em>' literal with the specified integer value.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static SocialIconType get(int value)
  {
    switch (value)
    {
      case NONE_VALUE: return NONE;
      case FACEBOOK_VALUE: return FACEBOOK;
      case TWITTER_VALUE: return TWITTER;
      case PINTEREST_VALUE: return PINTEREST;
      case LINKEDIN_VALUE: return LINKEDIN;
      case YOUTUBE_VALUE: return YOUTUBE;
      case VIMEO_VALUE: return VIMEO;
      case TUMBLR_VALUE: return TUMBLR;
      case INSTAGRAM_VALUE: return INSTAGRAM;
      case QUORA_VALUE: return QUORA;
      case FOURSQUARE_VALUE: return FOURSQUARE;
      case WORDPRESS_VALUE: return WORDPRESS;
      case STUMBLEUPON_VALUE: return STUMBLEUPON;
      case GITHUB_VALUE: return GITHUB;
      case TWITCH_VALUE: return TWITCH;
      case MEDIUM_VALUE: return MEDIUM;
      case SOUNDCLOUD_VALUE: return SOUNDCLOUD;
      case GITLAB_VALUE: return GITLAB;
      case ANGELLIST_VALUE: return ANGELLIST;
      case CODEPEN_VALUE: return CODEPEN;
    }
    return null;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final int value;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final String name;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final String literal;

  /**
   * Only this class can construct instances.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private SocialIconType(int value, String name, String literal)
  {
    this.value = value;
    this.name = name;
    this.literal = literal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public int getValue()
  {
    return value;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getLiteral()
  {
    return literal;
  }

  /**
   * Returns the literal value of the enumerator, which is its string representation.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    return literal;
  }
  
} //SocialIconType
