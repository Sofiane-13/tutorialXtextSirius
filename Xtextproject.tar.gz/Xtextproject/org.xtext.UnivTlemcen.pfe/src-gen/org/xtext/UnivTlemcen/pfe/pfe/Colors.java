/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Colors</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getColors()
 * @model
 * @generated
 */
public enum Colors implements Enumerator
{
  /**
   * The '<em><b>None</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #NONE_VALUE
   * @generated
   * @ordered
   */
  NONE(0, "none", "none"),

  /**
   * The '<em><b>White</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #WHITE_VALUE
   * @generated
   * @ordered
   */
  WHITE(1, "white", "#ffffff"),

  /**
   * The '<em><b>Red</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #RED_VALUE
   * @generated
   * @ordered
   */
  RED(2, "red", "#ff0000"),

  /**
   * The '<em><b>Moccasin</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #MOCCASIN_VALUE
   * @generated
   * @ordered
   */
  MOCCASIN(3, "moccasin", "#ffe4b5"),

  /**
   * The '<em><b>Green</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #GREEN_VALUE
   * @generated
   * @ordered
   */
  GREEN(4, "green", "#008000"),

  /**
   * The '<em><b>Lightgray</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #LIGHTGRAY_VALUE
   * @generated
   * @ordered
   */
  LIGHTGRAY(5, "lightgray", "#d3d3d3"),

  /**
   * The '<em><b>Orangered</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #ORANGERED_VALUE
   * @generated
   * @ordered
   */
  ORANGERED(6, "orangered", "#ff4500"),

  /**
   * The '<em><b>Gold</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #GOLD_VALUE
   * @generated
   * @ordered
   */
  GOLD(7, "gold", "#ffd700"),

  /**
   * The '<em><b>Floralwhite</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #FLORALWHITE_VALUE
   * @generated
   * @ordered
   */
  FLORALWHITE(8, "floralwhite", "#fffaf0"),

  /**
   * The '<em><b>Dodgerblue</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #DODGERBLUE_VALUE
   * @generated
   * @ordered
   */
  DODGERBLUE(9, "dodgerblue", "#1e90ff"),

  /**
   * The '<em><b>Deeppink</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #DEEPPINK_VALUE
   * @generated
   * @ordered
   */
  DEEPPINK(10, "deeppink", "#ff1493"),

  /**
   * The '<em><b>Darksalmon</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #DARKSALMON_VALUE
   * @generated
   * @ordered
   */
  DARKSALMON(11, "darksalmon", "#e9967a"),

  /**
   * The '<em><b>Darkorange</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #DARKORANGE_VALUE
   * @generated
   * @ordered
   */
  DARKORANGE(12, "darkorange", "#ff8c00"),

  /**
   * The '<em><b>Darkmagenta</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #DARKMAGENTA_VALUE
   * @generated
   * @ordered
   */
  DARKMAGENTA(13, "darkmagenta", "#8b008b"),

  /**
   * The '<em><b>Darkgreen</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #DARKGREEN_VALUE
   * @generated
   * @ordered
   */
  DARKGREEN(14, "darkgreen", "#006400"),

  /**
   * The '<em><b>Darkgray</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #DARKGRAY_VALUE
   * @generated
   * @ordered
   */
  DARKGRAY(15, "darkgray", "#a9a9a9"),

  /**
   * The '<em><b>Darkblue</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #DARKBLUE_VALUE
   * @generated
   * @ordered
   */
  DARKBLUE(16, "darkblue", "#00008b"),

  /**
   * The '<em><b>Crimson</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #CRIMSON_VALUE
   * @generated
   * @ordered
   */
  CRIMSON(17, "crimson", "#dc143c"),

  /**
   * The '<em><b>Chocolate</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #CHOCOLATE_VALUE
   * @generated
   * @ordered
   */
  CHOCOLATE(18, "chocolate", "#d2691e"),

  /**
   * The '<em><b>Chartreuse</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #CHARTREUSE_VALUE
   * @generated
   * @ordered
   */
  CHARTREUSE(19, "chartreuse", "#7fff00"),

  /**
   * The '<em><b>Cadetblue</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #CADETBLUE_VALUE
   * @generated
   * @ordered
   */
  CADETBLUE(20, "cadetblue", "#5f9ea0"),

  /**
   * The '<em><b>Brown</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #BROWN_VALUE
   * @generated
   * @ordered
   */
  BROWN(21, "brown", "#a52a2a"),

  /**
   * The '<em><b>Blueviolet</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #BLUEVIOLET_VALUE
   * @generated
   * @ordered
   */
  BLUEVIOLET(22, "blueviolet", "#8a2be2"),

  /**
   * The '<em><b>Blue</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #BLUE_VALUE
   * @generated
   * @ordered
   */
  BLUE(23, "blue", "#0000ff"),

  /**
   * The '<em><b>Black</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #BLACK_VALUE
   * @generated
   * @ordered
   */
  BLACK(24, "black", "#000000"),

  /**
   * The '<em><b>Aquamarine</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #AQUAMARINE_VALUE
   * @generated
   * @ordered
   */
  AQUAMARINE(25, "aquamarine", "#7fffd4"),

  /**
   * The '<em><b>Aliceblue</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #ALICEBLUE_VALUE
   * @generated
   * @ordered
   */
  ALICEBLUE(26, "aliceblue", "#f0f8ff"),

  /**
   * The '<em><b>Yellow</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #YELLOW_VALUE
   * @generated
   * @ordered
   */
  YELLOW(27, "yellow", "#ffff00"),

  /**
   * The '<em><b>Peachpuff</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #PEACHPUFF_VALUE
   * @generated
   * @ordered
   */
  PEACHPUFF(28, "peachpuff", "#ffdab9");

  /**
   * The '<em><b>None</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>None</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #NONE
   * @model name="none"
   * @generated
   * @ordered
   */
  public static final int NONE_VALUE = 0;

  /**
   * The '<em><b>White</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>White</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #WHITE
   * @model name="white" literal="#ffffff"
   * @generated
   * @ordered
   */
  public static final int WHITE_VALUE = 1;

  /**
   * The '<em><b>Red</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Red</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #RED
   * @model name="red" literal="#ff0000"
   * @generated
   * @ordered
   */
  public static final int RED_VALUE = 2;

  /**
   * The '<em><b>Moccasin</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Moccasin</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #MOCCASIN
   * @model name="moccasin" literal="#ffe4b5"
   * @generated
   * @ordered
   */
  public static final int MOCCASIN_VALUE = 3;

  /**
   * The '<em><b>Green</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Green</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #GREEN
   * @model name="green" literal="#008000"
   * @generated
   * @ordered
   */
  public static final int GREEN_VALUE = 4;

  /**
   * The '<em><b>Lightgray</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Lightgray</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #LIGHTGRAY
   * @model name="lightgray" literal="#d3d3d3"
   * @generated
   * @ordered
   */
  public static final int LIGHTGRAY_VALUE = 5;

  /**
   * The '<em><b>Orangered</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Orangered</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #ORANGERED
   * @model name="orangered" literal="#ff4500"
   * @generated
   * @ordered
   */
  public static final int ORANGERED_VALUE = 6;

  /**
   * The '<em><b>Gold</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Gold</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #GOLD
   * @model name="gold" literal="#ffd700"
   * @generated
   * @ordered
   */
  public static final int GOLD_VALUE = 7;

  /**
   * The '<em><b>Floralwhite</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Floralwhite</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #FLORALWHITE
   * @model name="floralwhite" literal="#fffaf0"
   * @generated
   * @ordered
   */
  public static final int FLORALWHITE_VALUE = 8;

  /**
   * The '<em><b>Dodgerblue</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Dodgerblue</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #DODGERBLUE
   * @model name="dodgerblue" literal="#1e90ff"
   * @generated
   * @ordered
   */
  public static final int DODGERBLUE_VALUE = 9;

  /**
   * The '<em><b>Deeppink</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Deeppink</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #DEEPPINK
   * @model name="deeppink" literal="#ff1493"
   * @generated
   * @ordered
   */
  public static final int DEEPPINK_VALUE = 10;

  /**
   * The '<em><b>Darksalmon</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Darksalmon</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #DARKSALMON
   * @model name="darksalmon" literal="#e9967a"
   * @generated
   * @ordered
   */
  public static final int DARKSALMON_VALUE = 11;

  /**
   * The '<em><b>Darkorange</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Darkorange</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #DARKORANGE
   * @model name="darkorange" literal="#ff8c00"
   * @generated
   * @ordered
   */
  public static final int DARKORANGE_VALUE = 12;

  /**
   * The '<em><b>Darkmagenta</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Darkmagenta</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #DARKMAGENTA
   * @model name="darkmagenta" literal="#8b008b"
   * @generated
   * @ordered
   */
  public static final int DARKMAGENTA_VALUE = 13;

  /**
   * The '<em><b>Darkgreen</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Darkgreen</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #DARKGREEN
   * @model name="darkgreen" literal="#006400"
   * @generated
   * @ordered
   */
  public static final int DARKGREEN_VALUE = 14;

  /**
   * The '<em><b>Darkgray</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Darkgray</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #DARKGRAY
   * @model name="darkgray" literal="#a9a9a9"
   * @generated
   * @ordered
   */
  public static final int DARKGRAY_VALUE = 15;

  /**
   * The '<em><b>Darkblue</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Darkblue</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #DARKBLUE
   * @model name="darkblue" literal="#00008b"
   * @generated
   * @ordered
   */
  public static final int DARKBLUE_VALUE = 16;

  /**
   * The '<em><b>Crimson</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Crimson</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #CRIMSON
   * @model name="crimson" literal="#dc143c"
   * @generated
   * @ordered
   */
  public static final int CRIMSON_VALUE = 17;

  /**
   * The '<em><b>Chocolate</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Chocolate</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #CHOCOLATE
   * @model name="chocolate" literal="#d2691e"
   * @generated
   * @ordered
   */
  public static final int CHOCOLATE_VALUE = 18;

  /**
   * The '<em><b>Chartreuse</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Chartreuse</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #CHARTREUSE
   * @model name="chartreuse" literal="#7fff00"
   * @generated
   * @ordered
   */
  public static final int CHARTREUSE_VALUE = 19;

  /**
   * The '<em><b>Cadetblue</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Cadetblue</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #CADETBLUE
   * @model name="cadetblue" literal="#5f9ea0"
   * @generated
   * @ordered
   */
  public static final int CADETBLUE_VALUE = 20;

  /**
   * The '<em><b>Brown</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Brown</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #BROWN
   * @model name="brown" literal="#a52a2a"
   * @generated
   * @ordered
   */
  public static final int BROWN_VALUE = 21;

  /**
   * The '<em><b>Blueviolet</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Blueviolet</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #BLUEVIOLET
   * @model name="blueviolet" literal="#8a2be2"
   * @generated
   * @ordered
   */
  public static final int BLUEVIOLET_VALUE = 22;

  /**
   * The '<em><b>Blue</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Blue</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #BLUE
   * @model name="blue" literal="#0000ff"
   * @generated
   * @ordered
   */
  public static final int BLUE_VALUE = 23;

  /**
   * The '<em><b>Black</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Black</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #BLACK
   * @model name="black" literal="#000000"
   * @generated
   * @ordered
   */
  public static final int BLACK_VALUE = 24;

  /**
   * The '<em><b>Aquamarine</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Aquamarine</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #AQUAMARINE
   * @model name="aquamarine" literal="#7fffd4"
   * @generated
   * @ordered
   */
  public static final int AQUAMARINE_VALUE = 25;

  /**
   * The '<em><b>Aliceblue</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Aliceblue</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #ALICEBLUE
   * @model name="aliceblue" literal="#f0f8ff"
   * @generated
   * @ordered
   */
  public static final int ALICEBLUE_VALUE = 26;

  /**
   * The '<em><b>Yellow</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Yellow</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #YELLOW
   * @model name="yellow" literal="#ffff00"
   * @generated
   * @ordered
   */
  public static final int YELLOW_VALUE = 27;

  /**
   * The '<em><b>Peachpuff</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Peachpuff</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #PEACHPUFF
   * @model name="peachpuff" literal="#ffdab9"
   * @generated
   * @ordered
   */
  public static final int PEACHPUFF_VALUE = 28;

  /**
   * An array of all the '<em><b>Colors</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static final Colors[] VALUES_ARRAY =
    new Colors[]
    {
      NONE,
      WHITE,
      RED,
      MOCCASIN,
      GREEN,
      LIGHTGRAY,
      ORANGERED,
      GOLD,
      FLORALWHITE,
      DODGERBLUE,
      DEEPPINK,
      DARKSALMON,
      DARKORANGE,
      DARKMAGENTA,
      DARKGREEN,
      DARKGRAY,
      DARKBLUE,
      CRIMSON,
      CHOCOLATE,
      CHARTREUSE,
      CADETBLUE,
      BROWN,
      BLUEVIOLET,
      BLUE,
      BLACK,
      AQUAMARINE,
      ALICEBLUE,
      YELLOW,
      PEACHPUFF,
    };

  /**
   * A public read-only list of all the '<em><b>Colors</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static final List<Colors> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

  /**
   * Returns the '<em><b>Colors</b></em>' literal with the specified literal value.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static Colors get(String literal)
  {
    for (int i = 0; i < VALUES_ARRAY.length; ++i)
    {
      Colors result = VALUES_ARRAY[i];
      if (result.toString().equals(literal))
      {
        return result;
      }
    }
    return null;
  }

  /**
   * Returns the '<em><b>Colors</b></em>' literal with the specified name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static Colors getByName(String name)
  {
    for (int i = 0; i < VALUES_ARRAY.length; ++i)
    {
      Colors result = VALUES_ARRAY[i];
      if (result.getName().equals(name))
      {
        return result;
      }
    }
    return null;
  }

  /**
   * Returns the '<em><b>Colors</b></em>' literal with the specified integer value.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static Colors get(int value)
  {
    switch (value)
    {
      case NONE_VALUE: return NONE;
      case WHITE_VALUE: return WHITE;
      case RED_VALUE: return RED;
      case MOCCASIN_VALUE: return MOCCASIN;
      case GREEN_VALUE: return GREEN;
      case LIGHTGRAY_VALUE: return LIGHTGRAY;
      case ORANGERED_VALUE: return ORANGERED;
      case GOLD_VALUE: return GOLD;
      case FLORALWHITE_VALUE: return FLORALWHITE;
      case DODGERBLUE_VALUE: return DODGERBLUE;
      case DEEPPINK_VALUE: return DEEPPINK;
      case DARKSALMON_VALUE: return DARKSALMON;
      case DARKORANGE_VALUE: return DARKORANGE;
      case DARKMAGENTA_VALUE: return DARKMAGENTA;
      case DARKGREEN_VALUE: return DARKGREEN;
      case DARKGRAY_VALUE: return DARKGRAY;
      case DARKBLUE_VALUE: return DARKBLUE;
      case CRIMSON_VALUE: return CRIMSON;
      case CHOCOLATE_VALUE: return CHOCOLATE;
      case CHARTREUSE_VALUE: return CHARTREUSE;
      case CADETBLUE_VALUE: return CADETBLUE;
      case BROWN_VALUE: return BROWN;
      case BLUEVIOLET_VALUE: return BLUEVIOLET;
      case BLUE_VALUE: return BLUE;
      case BLACK_VALUE: return BLACK;
      case AQUAMARINE_VALUE: return AQUAMARINE;
      case ALICEBLUE_VALUE: return ALICEBLUE;
      case YELLOW_VALUE: return YELLOW;
      case PEACHPUFF_VALUE: return PEACHPUFF;
    }
    return null;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final int value;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final String name;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final String literal;

  /**
   * Only this class can construct instances.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private Colors(int value, String name, String literal)
  {
    this.value = value;
    this.name = name;
    this.literal = literal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public int getValue()
  {
    return value;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getLiteral()
  {
    return literal;
  }

  /**
   * Returns the literal value of the enumerator, which is its string representation.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    return literal;
  }
  
} //Colors
