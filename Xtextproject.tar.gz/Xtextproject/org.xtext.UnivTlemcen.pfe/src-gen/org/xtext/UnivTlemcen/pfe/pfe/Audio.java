/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Audio</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Audio#getUrlT <em>Url T</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Audio#getTextbout <em>Textbout</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Audio#getLigneAudio <em>Ligne Audio</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Audio#getColoneAudio <em>Colone Audio</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Audio#getStyleAudio <em>Style Audio</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getAudio()
 * @model
 * @generated
 */
public interface Audio extends composant
{
  /**
   * Returns the value of the '<em><b>Url T</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Url T</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Url T</em>' attribute.
   * @see #setUrlT(String)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getAudio_UrlT()
   * @model
   * @generated
   */
  String getUrlT();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Audio#getUrlT <em>Url T</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Url T</em>' attribute.
   * @see #getUrlT()
   * @generated
   */
  void setUrlT(String value);

  /**
   * Returns the value of the '<em><b>Textbout</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Textbout</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Textbout</em>' attribute.
   * @see #setTextbout(String)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getAudio_Textbout()
   * @model
   * @generated
   */
  String getTextbout();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Audio#getTextbout <em>Textbout</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Textbout</em>' attribute.
   * @see #getTextbout()
   * @generated
   */
  void setTextbout(String value);

  /**
   * Returns the value of the '<em><b>Ligne Audio</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.LC}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Ligne Audio</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Ligne Audio</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #setLigneAudio(LC)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getAudio_LigneAudio()
   * @model
   * @generated
   */
  LC getLigneAudio();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Audio#getLigneAudio <em>Ligne Audio</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Ligne Audio</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #getLigneAudio()
   * @generated
   */
  void setLigneAudio(LC value);

  /**
   * Returns the value of the '<em><b>Colone Audio</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.LC}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Colone Audio</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Colone Audio</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #setColoneAudio(LC)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getAudio_ColoneAudio()
   * @model
   * @generated
   */
  LC getColoneAudio();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Audio#getColoneAudio <em>Colone Audio</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Colone Audio</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #getColoneAudio()
   * @generated
   */
  void setColoneAudio(LC value);

  /**
   * Returns the value of the '<em><b>Style Audio</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Style Audio</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Style Audio</em>' reference.
   * @see #setStyleAudio(StyleView)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getAudio_StyleAudio()
   * @model
   * @generated
   */
  StyleView getStyleAudio();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Audio#getStyleAudio <em>Style Audio</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Style Audio</em>' reference.
   * @see #getStyleAudio()
   * @generated
   */
  void setStyleAudio(StyleView value);

} // Audio
