/**
 */
package org.xtext.UnivTlemcen.pfe.pfe.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.xtext.UnivTlemcen.pfe.pfe.Backnum;
import org.xtext.UnivTlemcen.pfe.pfe.Colors;
import org.xtext.UnivTlemcen.pfe.pfe.JustifyContentType;
import org.xtext.UnivTlemcen.pfe.pfe.One;
import org.xtext.UnivTlemcen.pfe.pfe.PfePackage;
import org.xtext.UnivTlemcen.pfe.pfe.StyleView;
import org.xtext.UnivTlemcen.pfe.pfe.alfem;
import org.xtext.UnivTlemcen.pfe.pfe.aliIT;
import org.xtext.UnivTlemcen.pfe.pfe.bordersty;
import org.xtext.UnivTlemcen.pfe.pfe.entier;
import org.xtext.UnivTlemcen.pfe.pfe.flexd;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Style View</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getBackfaceVisibility2 <em>Backface Visibility2</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getBackgroundColor2 <em>Background Color2</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getBorderBottomColor2 <em>Border Bottom Color2</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getBorderBottomLeftRadius2 <em>Border Bottom Left Radius2</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getBorderBottomRightRadius2 <em>Border Bottom Right Radius2</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getBorderBottomWidth2 <em>Border Bottom Width2</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getBorderColort <em>Border Colort</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getBorderLeftColort <em>Border Left Colort</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getBorderLeftWidtht <em>Border Left Widtht</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getBorderRadiust <em>Border Radiust</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getBorderRightColort <em>Border Right Colort</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getBorderRightWidtht <em>Border Right Widtht</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getBorderStylet <em>Border Stylet</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getBorderTopColort <em>Border Top Colort</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getBorderTopLeftRadiust <em>Border Top Left Radiust</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getBorderTopRightRadiust <em>Border Top Right Radiust</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getBorderTopWidtht <em>Border Top Widtht</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getBorderWidtht <em>Border Widtht</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getOpacityt <em>Opacityt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getAlignItemst <em>Align Itemst</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getAlignSelft <em>Align Selft</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getBottomt <em>Bottomt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getFlext <em>Flext</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getFlexDirectiont <em>Flex Directiont</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getFlexWrapt <em>Flex Wrapt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getHeighte <em>Heighte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getJustifyContente <em>Justify Contente</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getLefte <em>Lefte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getMargin <em>Margin</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getMarginBottome <em>Margin Bottome</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getMarginLefte <em>Margin Lefte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getMarginRighte <em>Margin Righte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getMarginTope <em>Margin Tope</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getMarginVerticale <em>Margin Verticale</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getPaddingt <em>Paddingt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getPaddingBottomt <em>Padding Bottomt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getPaddingHorizontale <em>Padding Horizontale</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getPaddingRighte <em>Padding Righte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getPaddingTope <em>Padding Tope</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getPaddingVerticale <em>Padding Verticale</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getRightt <em>Rightt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl#getWidtht <em>Widtht</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class StyleViewImpl extends stylesheetImpl implements StyleView
{
  /**
   * The default value of the '{@link #getBackfaceVisibility2() <em>Backface Visibility2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBackfaceVisibility2()
   * @generated
   * @ordered
   */
  protected static final Backnum BACKFACE_VISIBILITY2_EDEFAULT = Backnum.NONE;

  /**
   * The cached value of the '{@link #getBackfaceVisibility2() <em>Backface Visibility2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBackfaceVisibility2()
   * @generated
   * @ordered
   */
  protected Backnum backfaceVisibility2 = BACKFACE_VISIBILITY2_EDEFAULT;

  /**
   * The default value of the '{@link #getBackgroundColor2() <em>Background Color2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBackgroundColor2()
   * @generated
   * @ordered
   */
  protected static final Colors BACKGROUND_COLOR2_EDEFAULT = Colors.NONE;

  /**
   * The cached value of the '{@link #getBackgroundColor2() <em>Background Color2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBackgroundColor2()
   * @generated
   * @ordered
   */
  protected Colors backgroundColor2 = BACKGROUND_COLOR2_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderBottomColor2() <em>Border Bottom Color2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomColor2()
   * @generated
   * @ordered
   */
  protected static final Colors BORDER_BOTTOM_COLOR2_EDEFAULT = Colors.NONE;

  /**
   * The cached value of the '{@link #getBorderBottomColor2() <em>Border Bottom Color2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomColor2()
   * @generated
   * @ordered
   */
  protected Colors borderBottomColor2 = BORDER_BOTTOM_COLOR2_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderBottomLeftRadius2() <em>Border Bottom Left Radius2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomLeftRadius2()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_BOTTOM_LEFT_RADIUS2_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderBottomLeftRadius2() <em>Border Bottom Left Radius2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomLeftRadius2()
   * @generated
   * @ordered
   */
  protected entier borderBottomLeftRadius2 = BORDER_BOTTOM_LEFT_RADIUS2_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderBottomRightRadius2() <em>Border Bottom Right Radius2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomRightRadius2()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_BOTTOM_RIGHT_RADIUS2_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderBottomRightRadius2() <em>Border Bottom Right Radius2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomRightRadius2()
   * @generated
   * @ordered
   */
  protected entier borderBottomRightRadius2 = BORDER_BOTTOM_RIGHT_RADIUS2_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderBottomWidth2() <em>Border Bottom Width2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomWidth2()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_BOTTOM_WIDTH2_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderBottomWidth2() <em>Border Bottom Width2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomWidth2()
   * @generated
   * @ordered
   */
  protected entier borderBottomWidth2 = BORDER_BOTTOM_WIDTH2_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderColort() <em>Border Colort</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderColort()
   * @generated
   * @ordered
   */
  protected static final Colors BORDER_COLORT_EDEFAULT = Colors.NONE;

  /**
   * The cached value of the '{@link #getBorderColort() <em>Border Colort</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderColort()
   * @generated
   * @ordered
   */
  protected Colors borderColort = BORDER_COLORT_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderLeftColort() <em>Border Left Colort</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderLeftColort()
   * @generated
   * @ordered
   */
  protected static final Colors BORDER_LEFT_COLORT_EDEFAULT = Colors.NONE;

  /**
   * The cached value of the '{@link #getBorderLeftColort() <em>Border Left Colort</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderLeftColort()
   * @generated
   * @ordered
   */
  protected Colors borderLeftColort = BORDER_LEFT_COLORT_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderLeftWidtht() <em>Border Left Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderLeftWidtht()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_LEFT_WIDTHT_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderLeftWidtht() <em>Border Left Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderLeftWidtht()
   * @generated
   * @ordered
   */
  protected entier borderLeftWidtht = BORDER_LEFT_WIDTHT_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderRadiust() <em>Border Radiust</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderRadiust()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_RADIUST_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderRadiust() <em>Border Radiust</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderRadiust()
   * @generated
   * @ordered
   */
  protected entier borderRadiust = BORDER_RADIUST_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderRightColort() <em>Border Right Colort</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderRightColort()
   * @generated
   * @ordered
   */
  protected static final Colors BORDER_RIGHT_COLORT_EDEFAULT = Colors.NONE;

  /**
   * The cached value of the '{@link #getBorderRightColort() <em>Border Right Colort</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderRightColort()
   * @generated
   * @ordered
   */
  protected Colors borderRightColort = BORDER_RIGHT_COLORT_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderRightWidtht() <em>Border Right Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderRightWidtht()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_RIGHT_WIDTHT_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderRightWidtht() <em>Border Right Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderRightWidtht()
   * @generated
   * @ordered
   */
  protected entier borderRightWidtht = BORDER_RIGHT_WIDTHT_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderStylet() <em>Border Stylet</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderStylet()
   * @generated
   * @ordered
   */
  protected static final bordersty BORDER_STYLET_EDEFAULT = bordersty.NONE;

  /**
   * The cached value of the '{@link #getBorderStylet() <em>Border Stylet</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderStylet()
   * @generated
   * @ordered
   */
  protected bordersty borderStylet = BORDER_STYLET_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderTopColort() <em>Border Top Colort</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopColort()
   * @generated
   * @ordered
   */
  protected static final Colors BORDER_TOP_COLORT_EDEFAULT = Colors.NONE;

  /**
   * The cached value of the '{@link #getBorderTopColort() <em>Border Top Colort</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopColort()
   * @generated
   * @ordered
   */
  protected Colors borderTopColort = BORDER_TOP_COLORT_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderTopLeftRadiust() <em>Border Top Left Radiust</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopLeftRadiust()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_TOP_LEFT_RADIUST_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderTopLeftRadiust() <em>Border Top Left Radiust</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopLeftRadiust()
   * @generated
   * @ordered
   */
  protected entier borderTopLeftRadiust = BORDER_TOP_LEFT_RADIUST_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderTopRightRadiust() <em>Border Top Right Radiust</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopRightRadiust()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_TOP_RIGHT_RADIUST_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderTopRightRadiust() <em>Border Top Right Radiust</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopRightRadiust()
   * @generated
   * @ordered
   */
  protected entier borderTopRightRadiust = BORDER_TOP_RIGHT_RADIUST_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderTopWidtht() <em>Border Top Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopWidtht()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_TOP_WIDTHT_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderTopWidtht() <em>Border Top Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopWidtht()
   * @generated
   * @ordered
   */
  protected entier borderTopWidtht = BORDER_TOP_WIDTHT_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderWidtht() <em>Border Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderWidtht()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_WIDTHT_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderWidtht() <em>Border Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderWidtht()
   * @generated
   * @ordered
   */
  protected entier borderWidtht = BORDER_WIDTHT_EDEFAULT;

  /**
   * The default value of the '{@link #getOpacityt() <em>Opacityt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOpacityt()
   * @generated
   * @ordered
   */
  protected static final entier OPACITYT_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getOpacityt() <em>Opacityt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOpacityt()
   * @generated
   * @ordered
   */
  protected entier opacityt = OPACITYT_EDEFAULT;

  /**
   * The default value of the '{@link #getAlignItemst() <em>Align Itemst</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAlignItemst()
   * @generated
   * @ordered
   */
  protected static final aliIT ALIGN_ITEMST_EDEFAULT = aliIT.NONE;

  /**
   * The cached value of the '{@link #getAlignItemst() <em>Align Itemst</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAlignItemst()
   * @generated
   * @ordered
   */
  protected aliIT alignItemst = ALIGN_ITEMST_EDEFAULT;

  /**
   * The default value of the '{@link #getAlignSelft() <em>Align Selft</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAlignSelft()
   * @generated
   * @ordered
   */
  protected static final alfem ALIGN_SELFT_EDEFAULT = alfem.NONE;

  /**
   * The cached value of the '{@link #getAlignSelft() <em>Align Selft</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAlignSelft()
   * @generated
   * @ordered
   */
  protected alfem alignSelft = ALIGN_SELFT_EDEFAULT;

  /**
   * The default value of the '{@link #getBottomt() <em>Bottomt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBottomt()
   * @generated
   * @ordered
   */
  protected static final entier BOTTOMT_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBottomt() <em>Bottomt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBottomt()
   * @generated
   * @ordered
   */
  protected entier bottomt = BOTTOMT_EDEFAULT;

  /**
   * The default value of the '{@link #getFlext() <em>Flext</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFlext()
   * @generated
   * @ordered
   */
  protected static final entier FLEXT_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getFlext() <em>Flext</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFlext()
   * @generated
   * @ordered
   */
  protected entier flext = FLEXT_EDEFAULT;

  /**
   * The default value of the '{@link #getFlexDirectiont() <em>Flex Directiont</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFlexDirectiont()
   * @generated
   * @ordered
   */
  protected static final flexd FLEX_DIRECTIONT_EDEFAULT = flexd.NONE;

  /**
   * The cached value of the '{@link #getFlexDirectiont() <em>Flex Directiont</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFlexDirectiont()
   * @generated
   * @ordered
   */
  protected flexd flexDirectiont = FLEX_DIRECTIONT_EDEFAULT;

  /**
   * The default value of the '{@link #getFlexWrapt() <em>Flex Wrapt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFlexWrapt()
   * @generated
   * @ordered
   */
  protected static final One FLEX_WRAPT_EDEFAULT = One.WRAP;

  /**
   * The cached value of the '{@link #getFlexWrapt() <em>Flex Wrapt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFlexWrapt()
   * @generated
   * @ordered
   */
  protected One flexWrapt = FLEX_WRAPT_EDEFAULT;

  /**
   * The default value of the '{@link #getHeighte() <em>Heighte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHeighte()
   * @generated
   * @ordered
   */
  protected static final entier HEIGHTE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getHeighte() <em>Heighte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHeighte()
   * @generated
   * @ordered
   */
  protected entier heighte = HEIGHTE_EDEFAULT;

  /**
   * The default value of the '{@link #getJustifyContente() <em>Justify Contente</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getJustifyContente()
   * @generated
   * @ordered
   */
  protected static final JustifyContentType JUSTIFY_CONTENTE_EDEFAULT = JustifyContentType.NONE;

  /**
   * The cached value of the '{@link #getJustifyContente() <em>Justify Contente</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getJustifyContente()
   * @generated
   * @ordered
   */
  protected JustifyContentType justifyContente = JUSTIFY_CONTENTE_EDEFAULT;

  /**
   * The default value of the '{@link #getLefte() <em>Lefte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLefte()
   * @generated
   * @ordered
   */
  protected static final entier LEFTE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getLefte() <em>Lefte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLefte()
   * @generated
   * @ordered
   */
  protected entier lefte = LEFTE_EDEFAULT;

  /**
   * The default value of the '{@link #getMargin() <em>Margin</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMargin()
   * @generated
   * @ordered
   */
  protected static final entier MARGIN_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getMargin() <em>Margin</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMargin()
   * @generated
   * @ordered
   */
  protected entier margin = MARGIN_EDEFAULT;

  /**
   * The default value of the '{@link #getMarginBottome() <em>Margin Bottome</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginBottome()
   * @generated
   * @ordered
   */
  protected static final entier MARGIN_BOTTOME_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getMarginBottome() <em>Margin Bottome</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginBottome()
   * @generated
   * @ordered
   */
  protected entier marginBottome = MARGIN_BOTTOME_EDEFAULT;

  /**
   * The default value of the '{@link #getMarginLefte() <em>Margin Lefte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginLefte()
   * @generated
   * @ordered
   */
  protected static final entier MARGIN_LEFTE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getMarginLefte() <em>Margin Lefte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginLefte()
   * @generated
   * @ordered
   */
  protected entier marginLefte = MARGIN_LEFTE_EDEFAULT;

  /**
   * The default value of the '{@link #getMarginRighte() <em>Margin Righte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginRighte()
   * @generated
   * @ordered
   */
  protected static final entier MARGIN_RIGHTE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getMarginRighte() <em>Margin Righte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginRighte()
   * @generated
   * @ordered
   */
  protected entier marginRighte = MARGIN_RIGHTE_EDEFAULT;

  /**
   * The default value of the '{@link #getMarginTope() <em>Margin Tope</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginTope()
   * @generated
   * @ordered
   */
  protected static final entier MARGIN_TOPE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getMarginTope() <em>Margin Tope</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginTope()
   * @generated
   * @ordered
   */
  protected entier marginTope = MARGIN_TOPE_EDEFAULT;

  /**
   * The default value of the '{@link #getMarginVerticale() <em>Margin Verticale</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginVerticale()
   * @generated
   * @ordered
   */
  protected static final entier MARGIN_VERTICALE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getMarginVerticale() <em>Margin Verticale</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginVerticale()
   * @generated
   * @ordered
   */
  protected entier marginVerticale = MARGIN_VERTICALE_EDEFAULT;

  /**
   * The default value of the '{@link #getPaddingt() <em>Paddingt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingt()
   * @generated
   * @ordered
   */
  protected static final entier PADDINGT_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getPaddingt() <em>Paddingt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingt()
   * @generated
   * @ordered
   */
  protected entier paddingt = PADDINGT_EDEFAULT;

  /**
   * The default value of the '{@link #getPaddingBottomt() <em>Padding Bottomt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingBottomt()
   * @generated
   * @ordered
   */
  protected static final entier PADDING_BOTTOMT_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getPaddingBottomt() <em>Padding Bottomt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingBottomt()
   * @generated
   * @ordered
   */
  protected entier paddingBottomt = PADDING_BOTTOMT_EDEFAULT;

  /**
   * The default value of the '{@link #getPaddingHorizontale() <em>Padding Horizontale</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingHorizontale()
   * @generated
   * @ordered
   */
  protected static final entier PADDING_HORIZONTALE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getPaddingHorizontale() <em>Padding Horizontale</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingHorizontale()
   * @generated
   * @ordered
   */
  protected entier paddingHorizontale = PADDING_HORIZONTALE_EDEFAULT;

  /**
   * The default value of the '{@link #getPaddingRighte() <em>Padding Righte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingRighte()
   * @generated
   * @ordered
   */
  protected static final entier PADDING_RIGHTE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getPaddingRighte() <em>Padding Righte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingRighte()
   * @generated
   * @ordered
   */
  protected entier paddingRighte = PADDING_RIGHTE_EDEFAULT;

  /**
   * The default value of the '{@link #getPaddingTope() <em>Padding Tope</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingTope()
   * @generated
   * @ordered
   */
  protected static final entier PADDING_TOPE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getPaddingTope() <em>Padding Tope</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingTope()
   * @generated
   * @ordered
   */
  protected entier paddingTope = PADDING_TOPE_EDEFAULT;

  /**
   * The default value of the '{@link #getPaddingVerticale() <em>Padding Verticale</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingVerticale()
   * @generated
   * @ordered
   */
  protected static final entier PADDING_VERTICALE_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getPaddingVerticale() <em>Padding Verticale</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPaddingVerticale()
   * @generated
   * @ordered
   */
  protected entier paddingVerticale = PADDING_VERTICALE_EDEFAULT;

  /**
   * The default value of the '{@link #getRightt() <em>Rightt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getRightt()
   * @generated
   * @ordered
   */
  protected static final entier RIGHTT_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getRightt() <em>Rightt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getRightt()
   * @generated
   * @ordered
   */
  protected entier rightt = RIGHTT_EDEFAULT;

  /**
   * The default value of the '{@link #getWidtht() <em>Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getWidtht()
   * @generated
   * @ordered
   */
  protected static final entier WIDTHT_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getWidtht() <em>Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getWidtht()
   * @generated
   * @ordered
   */
  protected entier widtht = WIDTHT_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected StyleViewImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return PfePackage.Literals.STYLE_VIEW;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Backnum getBackfaceVisibility2()
  {
    return backfaceVisibility2;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBackfaceVisibility2(Backnum newBackfaceVisibility2)
  {
    Backnum oldBackfaceVisibility2 = backfaceVisibility2;
    backfaceVisibility2 = newBackfaceVisibility2 == null ? BACKFACE_VISIBILITY2_EDEFAULT : newBackfaceVisibility2;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__BACKFACE_VISIBILITY2, oldBackfaceVisibility2, backfaceVisibility2));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Colors getBackgroundColor2()
  {
    return backgroundColor2;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBackgroundColor2(Colors newBackgroundColor2)
  {
    Colors oldBackgroundColor2 = backgroundColor2;
    backgroundColor2 = newBackgroundColor2 == null ? BACKGROUND_COLOR2_EDEFAULT : newBackgroundColor2;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__BACKGROUND_COLOR2, oldBackgroundColor2, backgroundColor2));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Colors getBorderBottomColor2()
  {
    return borderBottomColor2;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderBottomColor2(Colors newBorderBottomColor2)
  {
    Colors oldBorderBottomColor2 = borderBottomColor2;
    borderBottomColor2 = newBorderBottomColor2 == null ? BORDER_BOTTOM_COLOR2_EDEFAULT : newBorderBottomColor2;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__BORDER_BOTTOM_COLOR2, oldBorderBottomColor2, borderBottomColor2));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderBottomLeftRadius2()
  {
    return borderBottomLeftRadius2;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderBottomLeftRadius2(entier newBorderBottomLeftRadius2)
  {
    entier oldBorderBottomLeftRadius2 = borderBottomLeftRadius2;
    borderBottomLeftRadius2 = newBorderBottomLeftRadius2 == null ? BORDER_BOTTOM_LEFT_RADIUS2_EDEFAULT : newBorderBottomLeftRadius2;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__BORDER_BOTTOM_LEFT_RADIUS2, oldBorderBottomLeftRadius2, borderBottomLeftRadius2));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderBottomRightRadius2()
  {
    return borderBottomRightRadius2;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderBottomRightRadius2(entier newBorderBottomRightRadius2)
  {
    entier oldBorderBottomRightRadius2 = borderBottomRightRadius2;
    borderBottomRightRadius2 = newBorderBottomRightRadius2 == null ? BORDER_BOTTOM_RIGHT_RADIUS2_EDEFAULT : newBorderBottomRightRadius2;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__BORDER_BOTTOM_RIGHT_RADIUS2, oldBorderBottomRightRadius2, borderBottomRightRadius2));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderBottomWidth2()
  {
    return borderBottomWidth2;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderBottomWidth2(entier newBorderBottomWidth2)
  {
    entier oldBorderBottomWidth2 = borderBottomWidth2;
    borderBottomWidth2 = newBorderBottomWidth2 == null ? BORDER_BOTTOM_WIDTH2_EDEFAULT : newBorderBottomWidth2;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__BORDER_BOTTOM_WIDTH2, oldBorderBottomWidth2, borderBottomWidth2));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Colors getBorderColort()
  {
    return borderColort;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderColort(Colors newBorderColort)
  {
    Colors oldBorderColort = borderColort;
    borderColort = newBorderColort == null ? BORDER_COLORT_EDEFAULT : newBorderColort;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__BORDER_COLORT, oldBorderColort, borderColort));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Colors getBorderLeftColort()
  {
    return borderLeftColort;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderLeftColort(Colors newBorderLeftColort)
  {
    Colors oldBorderLeftColort = borderLeftColort;
    borderLeftColort = newBorderLeftColort == null ? BORDER_LEFT_COLORT_EDEFAULT : newBorderLeftColort;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__BORDER_LEFT_COLORT, oldBorderLeftColort, borderLeftColort));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderLeftWidtht()
  {
    return borderLeftWidtht;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderLeftWidtht(entier newBorderLeftWidtht)
  {
    entier oldBorderLeftWidtht = borderLeftWidtht;
    borderLeftWidtht = newBorderLeftWidtht == null ? BORDER_LEFT_WIDTHT_EDEFAULT : newBorderLeftWidtht;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__BORDER_LEFT_WIDTHT, oldBorderLeftWidtht, borderLeftWidtht));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderRadiust()
  {
    return borderRadiust;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderRadiust(entier newBorderRadiust)
  {
    entier oldBorderRadiust = borderRadiust;
    borderRadiust = newBorderRadiust == null ? BORDER_RADIUST_EDEFAULT : newBorderRadiust;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__BORDER_RADIUST, oldBorderRadiust, borderRadiust));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Colors getBorderRightColort()
  {
    return borderRightColort;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderRightColort(Colors newBorderRightColort)
  {
    Colors oldBorderRightColort = borderRightColort;
    borderRightColort = newBorderRightColort == null ? BORDER_RIGHT_COLORT_EDEFAULT : newBorderRightColort;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__BORDER_RIGHT_COLORT, oldBorderRightColort, borderRightColort));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderRightWidtht()
  {
    return borderRightWidtht;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderRightWidtht(entier newBorderRightWidtht)
  {
    entier oldBorderRightWidtht = borderRightWidtht;
    borderRightWidtht = newBorderRightWidtht == null ? BORDER_RIGHT_WIDTHT_EDEFAULT : newBorderRightWidtht;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__BORDER_RIGHT_WIDTHT, oldBorderRightWidtht, borderRightWidtht));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public bordersty getBorderStylet()
  {
    return borderStylet;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderStylet(bordersty newBorderStylet)
  {
    bordersty oldBorderStylet = borderStylet;
    borderStylet = newBorderStylet == null ? BORDER_STYLET_EDEFAULT : newBorderStylet;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__BORDER_STYLET, oldBorderStylet, borderStylet));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Colors getBorderTopColort()
  {
    return borderTopColort;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderTopColort(Colors newBorderTopColort)
  {
    Colors oldBorderTopColort = borderTopColort;
    borderTopColort = newBorderTopColort == null ? BORDER_TOP_COLORT_EDEFAULT : newBorderTopColort;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__BORDER_TOP_COLORT, oldBorderTopColort, borderTopColort));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderTopLeftRadiust()
  {
    return borderTopLeftRadiust;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderTopLeftRadiust(entier newBorderTopLeftRadiust)
  {
    entier oldBorderTopLeftRadiust = borderTopLeftRadiust;
    borderTopLeftRadiust = newBorderTopLeftRadiust == null ? BORDER_TOP_LEFT_RADIUST_EDEFAULT : newBorderTopLeftRadiust;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__BORDER_TOP_LEFT_RADIUST, oldBorderTopLeftRadiust, borderTopLeftRadiust));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderTopRightRadiust()
  {
    return borderTopRightRadiust;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderTopRightRadiust(entier newBorderTopRightRadiust)
  {
    entier oldBorderTopRightRadiust = borderTopRightRadiust;
    borderTopRightRadiust = newBorderTopRightRadiust == null ? BORDER_TOP_RIGHT_RADIUST_EDEFAULT : newBorderTopRightRadiust;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__BORDER_TOP_RIGHT_RADIUST, oldBorderTopRightRadiust, borderTopRightRadiust));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderTopWidtht()
  {
    return borderTopWidtht;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderTopWidtht(entier newBorderTopWidtht)
  {
    entier oldBorderTopWidtht = borderTopWidtht;
    borderTopWidtht = newBorderTopWidtht == null ? BORDER_TOP_WIDTHT_EDEFAULT : newBorderTopWidtht;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__BORDER_TOP_WIDTHT, oldBorderTopWidtht, borderTopWidtht));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderWidtht()
  {
    return borderWidtht;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderWidtht(entier newBorderWidtht)
  {
    entier oldBorderWidtht = borderWidtht;
    borderWidtht = newBorderWidtht == null ? BORDER_WIDTHT_EDEFAULT : newBorderWidtht;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__BORDER_WIDTHT, oldBorderWidtht, borderWidtht));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getOpacityt()
  {
    return opacityt;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setOpacityt(entier newOpacityt)
  {
    entier oldOpacityt = opacityt;
    opacityt = newOpacityt == null ? OPACITYT_EDEFAULT : newOpacityt;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__OPACITYT, oldOpacityt, opacityt));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public aliIT getAlignItemst()
  {
    return alignItemst;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAlignItemst(aliIT newAlignItemst)
  {
    aliIT oldAlignItemst = alignItemst;
    alignItemst = newAlignItemst == null ? ALIGN_ITEMST_EDEFAULT : newAlignItemst;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__ALIGN_ITEMST, oldAlignItemst, alignItemst));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public alfem getAlignSelft()
  {
    return alignSelft;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAlignSelft(alfem newAlignSelft)
  {
    alfem oldAlignSelft = alignSelft;
    alignSelft = newAlignSelft == null ? ALIGN_SELFT_EDEFAULT : newAlignSelft;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__ALIGN_SELFT, oldAlignSelft, alignSelft));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBottomt()
  {
    return bottomt;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBottomt(entier newBottomt)
  {
    entier oldBottomt = bottomt;
    bottomt = newBottomt == null ? BOTTOMT_EDEFAULT : newBottomt;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__BOTTOMT, oldBottomt, bottomt));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getFlext()
  {
    return flext;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFlext(entier newFlext)
  {
    entier oldFlext = flext;
    flext = newFlext == null ? FLEXT_EDEFAULT : newFlext;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__FLEXT, oldFlext, flext));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public flexd getFlexDirectiont()
  {
    return flexDirectiont;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFlexDirectiont(flexd newFlexDirectiont)
  {
    flexd oldFlexDirectiont = flexDirectiont;
    flexDirectiont = newFlexDirectiont == null ? FLEX_DIRECTIONT_EDEFAULT : newFlexDirectiont;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__FLEX_DIRECTIONT, oldFlexDirectiont, flexDirectiont));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public One getFlexWrapt()
  {
    return flexWrapt;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFlexWrapt(One newFlexWrapt)
  {
    One oldFlexWrapt = flexWrapt;
    flexWrapt = newFlexWrapt == null ? FLEX_WRAPT_EDEFAULT : newFlexWrapt;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__FLEX_WRAPT, oldFlexWrapt, flexWrapt));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getHeighte()
  {
    return heighte;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setHeighte(entier newHeighte)
  {
    entier oldHeighte = heighte;
    heighte = newHeighte == null ? HEIGHTE_EDEFAULT : newHeighte;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__HEIGHTE, oldHeighte, heighte));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public JustifyContentType getJustifyContente()
  {
    return justifyContente;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setJustifyContente(JustifyContentType newJustifyContente)
  {
    JustifyContentType oldJustifyContente = justifyContente;
    justifyContente = newJustifyContente == null ? JUSTIFY_CONTENTE_EDEFAULT : newJustifyContente;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__JUSTIFY_CONTENTE, oldJustifyContente, justifyContente));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getLefte()
  {
    return lefte;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLefte(entier newLefte)
  {
    entier oldLefte = lefte;
    lefte = newLefte == null ? LEFTE_EDEFAULT : newLefte;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__LEFTE, oldLefte, lefte));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getMargin()
  {
    return margin;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMargin(entier newMargin)
  {
    entier oldMargin = margin;
    margin = newMargin == null ? MARGIN_EDEFAULT : newMargin;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__MARGIN, oldMargin, margin));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getMarginBottome()
  {
    return marginBottome;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMarginBottome(entier newMarginBottome)
  {
    entier oldMarginBottome = marginBottome;
    marginBottome = newMarginBottome == null ? MARGIN_BOTTOME_EDEFAULT : newMarginBottome;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__MARGIN_BOTTOME, oldMarginBottome, marginBottome));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getMarginLefte()
  {
    return marginLefte;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMarginLefte(entier newMarginLefte)
  {
    entier oldMarginLefte = marginLefte;
    marginLefte = newMarginLefte == null ? MARGIN_LEFTE_EDEFAULT : newMarginLefte;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__MARGIN_LEFTE, oldMarginLefte, marginLefte));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getMarginRighte()
  {
    return marginRighte;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMarginRighte(entier newMarginRighte)
  {
    entier oldMarginRighte = marginRighte;
    marginRighte = newMarginRighte == null ? MARGIN_RIGHTE_EDEFAULT : newMarginRighte;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__MARGIN_RIGHTE, oldMarginRighte, marginRighte));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getMarginTope()
  {
    return marginTope;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMarginTope(entier newMarginTope)
  {
    entier oldMarginTope = marginTope;
    marginTope = newMarginTope == null ? MARGIN_TOPE_EDEFAULT : newMarginTope;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__MARGIN_TOPE, oldMarginTope, marginTope));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getMarginVerticale()
  {
    return marginVerticale;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMarginVerticale(entier newMarginVerticale)
  {
    entier oldMarginVerticale = marginVerticale;
    marginVerticale = newMarginVerticale == null ? MARGIN_VERTICALE_EDEFAULT : newMarginVerticale;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__MARGIN_VERTICALE, oldMarginVerticale, marginVerticale));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getPaddingt()
  {
    return paddingt;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPaddingt(entier newPaddingt)
  {
    entier oldPaddingt = paddingt;
    paddingt = newPaddingt == null ? PADDINGT_EDEFAULT : newPaddingt;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__PADDINGT, oldPaddingt, paddingt));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getPaddingBottomt()
  {
    return paddingBottomt;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPaddingBottomt(entier newPaddingBottomt)
  {
    entier oldPaddingBottomt = paddingBottomt;
    paddingBottomt = newPaddingBottomt == null ? PADDING_BOTTOMT_EDEFAULT : newPaddingBottomt;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__PADDING_BOTTOMT, oldPaddingBottomt, paddingBottomt));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getPaddingHorizontale()
  {
    return paddingHorizontale;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPaddingHorizontale(entier newPaddingHorizontale)
  {
    entier oldPaddingHorizontale = paddingHorizontale;
    paddingHorizontale = newPaddingHorizontale == null ? PADDING_HORIZONTALE_EDEFAULT : newPaddingHorizontale;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__PADDING_HORIZONTALE, oldPaddingHorizontale, paddingHorizontale));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getPaddingRighte()
  {
    return paddingRighte;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPaddingRighte(entier newPaddingRighte)
  {
    entier oldPaddingRighte = paddingRighte;
    paddingRighte = newPaddingRighte == null ? PADDING_RIGHTE_EDEFAULT : newPaddingRighte;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__PADDING_RIGHTE, oldPaddingRighte, paddingRighte));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getPaddingTope()
  {
    return paddingTope;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPaddingTope(entier newPaddingTope)
  {
    entier oldPaddingTope = paddingTope;
    paddingTope = newPaddingTope == null ? PADDING_TOPE_EDEFAULT : newPaddingTope;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__PADDING_TOPE, oldPaddingTope, paddingTope));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getPaddingVerticale()
  {
    return paddingVerticale;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPaddingVerticale(entier newPaddingVerticale)
  {
    entier oldPaddingVerticale = paddingVerticale;
    paddingVerticale = newPaddingVerticale == null ? PADDING_VERTICALE_EDEFAULT : newPaddingVerticale;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__PADDING_VERTICALE, oldPaddingVerticale, paddingVerticale));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getRightt()
  {
    return rightt;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setRightt(entier newRightt)
  {
    entier oldRightt = rightt;
    rightt = newRightt == null ? RIGHTT_EDEFAULT : newRightt;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__RIGHTT, oldRightt, rightt));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getWidtht()
  {
    return widtht;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setWidtht(entier newWidtht)
  {
    entier oldWidtht = widtht;
    widtht = newWidtht == null ? WIDTHT_EDEFAULT : newWidtht;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLE_VIEW__WIDTHT, oldWidtht, widtht));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case PfePackage.STYLE_VIEW__BACKFACE_VISIBILITY2:
        return getBackfaceVisibility2();
      case PfePackage.STYLE_VIEW__BACKGROUND_COLOR2:
        return getBackgroundColor2();
      case PfePackage.STYLE_VIEW__BORDER_BOTTOM_COLOR2:
        return getBorderBottomColor2();
      case PfePackage.STYLE_VIEW__BORDER_BOTTOM_LEFT_RADIUS2:
        return getBorderBottomLeftRadius2();
      case PfePackage.STYLE_VIEW__BORDER_BOTTOM_RIGHT_RADIUS2:
        return getBorderBottomRightRadius2();
      case PfePackage.STYLE_VIEW__BORDER_BOTTOM_WIDTH2:
        return getBorderBottomWidth2();
      case PfePackage.STYLE_VIEW__BORDER_COLORT:
        return getBorderColort();
      case PfePackage.STYLE_VIEW__BORDER_LEFT_COLORT:
        return getBorderLeftColort();
      case PfePackage.STYLE_VIEW__BORDER_LEFT_WIDTHT:
        return getBorderLeftWidtht();
      case PfePackage.STYLE_VIEW__BORDER_RADIUST:
        return getBorderRadiust();
      case PfePackage.STYLE_VIEW__BORDER_RIGHT_COLORT:
        return getBorderRightColort();
      case PfePackage.STYLE_VIEW__BORDER_RIGHT_WIDTHT:
        return getBorderRightWidtht();
      case PfePackage.STYLE_VIEW__BORDER_STYLET:
        return getBorderStylet();
      case PfePackage.STYLE_VIEW__BORDER_TOP_COLORT:
        return getBorderTopColort();
      case PfePackage.STYLE_VIEW__BORDER_TOP_LEFT_RADIUST:
        return getBorderTopLeftRadiust();
      case PfePackage.STYLE_VIEW__BORDER_TOP_RIGHT_RADIUST:
        return getBorderTopRightRadiust();
      case PfePackage.STYLE_VIEW__BORDER_TOP_WIDTHT:
        return getBorderTopWidtht();
      case PfePackage.STYLE_VIEW__BORDER_WIDTHT:
        return getBorderWidtht();
      case PfePackage.STYLE_VIEW__OPACITYT:
        return getOpacityt();
      case PfePackage.STYLE_VIEW__ALIGN_ITEMST:
        return getAlignItemst();
      case PfePackage.STYLE_VIEW__ALIGN_SELFT:
        return getAlignSelft();
      case PfePackage.STYLE_VIEW__BOTTOMT:
        return getBottomt();
      case PfePackage.STYLE_VIEW__FLEXT:
        return getFlext();
      case PfePackage.STYLE_VIEW__FLEX_DIRECTIONT:
        return getFlexDirectiont();
      case PfePackage.STYLE_VIEW__FLEX_WRAPT:
        return getFlexWrapt();
      case PfePackage.STYLE_VIEW__HEIGHTE:
        return getHeighte();
      case PfePackage.STYLE_VIEW__JUSTIFY_CONTENTE:
        return getJustifyContente();
      case PfePackage.STYLE_VIEW__LEFTE:
        return getLefte();
      case PfePackage.STYLE_VIEW__MARGIN:
        return getMargin();
      case PfePackage.STYLE_VIEW__MARGIN_BOTTOME:
        return getMarginBottome();
      case PfePackage.STYLE_VIEW__MARGIN_LEFTE:
        return getMarginLefte();
      case PfePackage.STYLE_VIEW__MARGIN_RIGHTE:
        return getMarginRighte();
      case PfePackage.STYLE_VIEW__MARGIN_TOPE:
        return getMarginTope();
      case PfePackage.STYLE_VIEW__MARGIN_VERTICALE:
        return getMarginVerticale();
      case PfePackage.STYLE_VIEW__PADDINGT:
        return getPaddingt();
      case PfePackage.STYLE_VIEW__PADDING_BOTTOMT:
        return getPaddingBottomt();
      case PfePackage.STYLE_VIEW__PADDING_HORIZONTALE:
        return getPaddingHorizontale();
      case PfePackage.STYLE_VIEW__PADDING_RIGHTE:
        return getPaddingRighte();
      case PfePackage.STYLE_VIEW__PADDING_TOPE:
        return getPaddingTope();
      case PfePackage.STYLE_VIEW__PADDING_VERTICALE:
        return getPaddingVerticale();
      case PfePackage.STYLE_VIEW__RIGHTT:
        return getRightt();
      case PfePackage.STYLE_VIEW__WIDTHT:
        return getWidtht();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case PfePackage.STYLE_VIEW__BACKFACE_VISIBILITY2:
        setBackfaceVisibility2((Backnum)newValue);
        return;
      case PfePackage.STYLE_VIEW__BACKGROUND_COLOR2:
        setBackgroundColor2((Colors)newValue);
        return;
      case PfePackage.STYLE_VIEW__BORDER_BOTTOM_COLOR2:
        setBorderBottomColor2((Colors)newValue);
        return;
      case PfePackage.STYLE_VIEW__BORDER_BOTTOM_LEFT_RADIUS2:
        setBorderBottomLeftRadius2((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__BORDER_BOTTOM_RIGHT_RADIUS2:
        setBorderBottomRightRadius2((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__BORDER_BOTTOM_WIDTH2:
        setBorderBottomWidth2((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__BORDER_COLORT:
        setBorderColort((Colors)newValue);
        return;
      case PfePackage.STYLE_VIEW__BORDER_LEFT_COLORT:
        setBorderLeftColort((Colors)newValue);
        return;
      case PfePackage.STYLE_VIEW__BORDER_LEFT_WIDTHT:
        setBorderLeftWidtht((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__BORDER_RADIUST:
        setBorderRadiust((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__BORDER_RIGHT_COLORT:
        setBorderRightColort((Colors)newValue);
        return;
      case PfePackage.STYLE_VIEW__BORDER_RIGHT_WIDTHT:
        setBorderRightWidtht((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__BORDER_STYLET:
        setBorderStylet((bordersty)newValue);
        return;
      case PfePackage.STYLE_VIEW__BORDER_TOP_COLORT:
        setBorderTopColort((Colors)newValue);
        return;
      case PfePackage.STYLE_VIEW__BORDER_TOP_LEFT_RADIUST:
        setBorderTopLeftRadiust((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__BORDER_TOP_RIGHT_RADIUST:
        setBorderTopRightRadiust((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__BORDER_TOP_WIDTHT:
        setBorderTopWidtht((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__BORDER_WIDTHT:
        setBorderWidtht((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__OPACITYT:
        setOpacityt((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__ALIGN_ITEMST:
        setAlignItemst((aliIT)newValue);
        return;
      case PfePackage.STYLE_VIEW__ALIGN_SELFT:
        setAlignSelft((alfem)newValue);
        return;
      case PfePackage.STYLE_VIEW__BOTTOMT:
        setBottomt((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__FLEXT:
        setFlext((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__FLEX_DIRECTIONT:
        setFlexDirectiont((flexd)newValue);
        return;
      case PfePackage.STYLE_VIEW__FLEX_WRAPT:
        setFlexWrapt((One)newValue);
        return;
      case PfePackage.STYLE_VIEW__HEIGHTE:
        setHeighte((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__JUSTIFY_CONTENTE:
        setJustifyContente((JustifyContentType)newValue);
        return;
      case PfePackage.STYLE_VIEW__LEFTE:
        setLefte((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__MARGIN:
        setMargin((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__MARGIN_BOTTOME:
        setMarginBottome((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__MARGIN_LEFTE:
        setMarginLefte((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__MARGIN_RIGHTE:
        setMarginRighte((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__MARGIN_TOPE:
        setMarginTope((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__MARGIN_VERTICALE:
        setMarginVerticale((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__PADDINGT:
        setPaddingt((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__PADDING_BOTTOMT:
        setPaddingBottomt((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__PADDING_HORIZONTALE:
        setPaddingHorizontale((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__PADDING_RIGHTE:
        setPaddingRighte((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__PADDING_TOPE:
        setPaddingTope((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__PADDING_VERTICALE:
        setPaddingVerticale((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__RIGHTT:
        setRightt((entier)newValue);
        return;
      case PfePackage.STYLE_VIEW__WIDTHT:
        setWidtht((entier)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.STYLE_VIEW__BACKFACE_VISIBILITY2:
        setBackfaceVisibility2(BACKFACE_VISIBILITY2_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__BACKGROUND_COLOR2:
        setBackgroundColor2(BACKGROUND_COLOR2_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__BORDER_BOTTOM_COLOR2:
        setBorderBottomColor2(BORDER_BOTTOM_COLOR2_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__BORDER_BOTTOM_LEFT_RADIUS2:
        setBorderBottomLeftRadius2(BORDER_BOTTOM_LEFT_RADIUS2_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__BORDER_BOTTOM_RIGHT_RADIUS2:
        setBorderBottomRightRadius2(BORDER_BOTTOM_RIGHT_RADIUS2_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__BORDER_BOTTOM_WIDTH2:
        setBorderBottomWidth2(BORDER_BOTTOM_WIDTH2_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__BORDER_COLORT:
        setBorderColort(BORDER_COLORT_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__BORDER_LEFT_COLORT:
        setBorderLeftColort(BORDER_LEFT_COLORT_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__BORDER_LEFT_WIDTHT:
        setBorderLeftWidtht(BORDER_LEFT_WIDTHT_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__BORDER_RADIUST:
        setBorderRadiust(BORDER_RADIUST_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__BORDER_RIGHT_COLORT:
        setBorderRightColort(BORDER_RIGHT_COLORT_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__BORDER_RIGHT_WIDTHT:
        setBorderRightWidtht(BORDER_RIGHT_WIDTHT_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__BORDER_STYLET:
        setBorderStylet(BORDER_STYLET_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__BORDER_TOP_COLORT:
        setBorderTopColort(BORDER_TOP_COLORT_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__BORDER_TOP_LEFT_RADIUST:
        setBorderTopLeftRadiust(BORDER_TOP_LEFT_RADIUST_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__BORDER_TOP_RIGHT_RADIUST:
        setBorderTopRightRadiust(BORDER_TOP_RIGHT_RADIUST_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__BORDER_TOP_WIDTHT:
        setBorderTopWidtht(BORDER_TOP_WIDTHT_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__BORDER_WIDTHT:
        setBorderWidtht(BORDER_WIDTHT_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__OPACITYT:
        setOpacityt(OPACITYT_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__ALIGN_ITEMST:
        setAlignItemst(ALIGN_ITEMST_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__ALIGN_SELFT:
        setAlignSelft(ALIGN_SELFT_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__BOTTOMT:
        setBottomt(BOTTOMT_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__FLEXT:
        setFlext(FLEXT_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__FLEX_DIRECTIONT:
        setFlexDirectiont(FLEX_DIRECTIONT_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__FLEX_WRAPT:
        setFlexWrapt(FLEX_WRAPT_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__HEIGHTE:
        setHeighte(HEIGHTE_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__JUSTIFY_CONTENTE:
        setJustifyContente(JUSTIFY_CONTENTE_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__LEFTE:
        setLefte(LEFTE_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__MARGIN:
        setMargin(MARGIN_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__MARGIN_BOTTOME:
        setMarginBottome(MARGIN_BOTTOME_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__MARGIN_LEFTE:
        setMarginLefte(MARGIN_LEFTE_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__MARGIN_RIGHTE:
        setMarginRighte(MARGIN_RIGHTE_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__MARGIN_TOPE:
        setMarginTope(MARGIN_TOPE_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__MARGIN_VERTICALE:
        setMarginVerticale(MARGIN_VERTICALE_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__PADDINGT:
        setPaddingt(PADDINGT_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__PADDING_BOTTOMT:
        setPaddingBottomt(PADDING_BOTTOMT_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__PADDING_HORIZONTALE:
        setPaddingHorizontale(PADDING_HORIZONTALE_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__PADDING_RIGHTE:
        setPaddingRighte(PADDING_RIGHTE_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__PADDING_TOPE:
        setPaddingTope(PADDING_TOPE_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__PADDING_VERTICALE:
        setPaddingVerticale(PADDING_VERTICALE_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__RIGHTT:
        setRightt(RIGHTT_EDEFAULT);
        return;
      case PfePackage.STYLE_VIEW__WIDTHT:
        setWidtht(WIDTHT_EDEFAULT);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.STYLE_VIEW__BACKFACE_VISIBILITY2:
        return backfaceVisibility2 != BACKFACE_VISIBILITY2_EDEFAULT;
      case PfePackage.STYLE_VIEW__BACKGROUND_COLOR2:
        return backgroundColor2 != BACKGROUND_COLOR2_EDEFAULT;
      case PfePackage.STYLE_VIEW__BORDER_BOTTOM_COLOR2:
        return borderBottomColor2 != BORDER_BOTTOM_COLOR2_EDEFAULT;
      case PfePackage.STYLE_VIEW__BORDER_BOTTOM_LEFT_RADIUS2:
        return borderBottomLeftRadius2 != BORDER_BOTTOM_LEFT_RADIUS2_EDEFAULT;
      case PfePackage.STYLE_VIEW__BORDER_BOTTOM_RIGHT_RADIUS2:
        return borderBottomRightRadius2 != BORDER_BOTTOM_RIGHT_RADIUS2_EDEFAULT;
      case PfePackage.STYLE_VIEW__BORDER_BOTTOM_WIDTH2:
        return borderBottomWidth2 != BORDER_BOTTOM_WIDTH2_EDEFAULT;
      case PfePackage.STYLE_VIEW__BORDER_COLORT:
        return borderColort != BORDER_COLORT_EDEFAULT;
      case PfePackage.STYLE_VIEW__BORDER_LEFT_COLORT:
        return borderLeftColort != BORDER_LEFT_COLORT_EDEFAULT;
      case PfePackage.STYLE_VIEW__BORDER_LEFT_WIDTHT:
        return borderLeftWidtht != BORDER_LEFT_WIDTHT_EDEFAULT;
      case PfePackage.STYLE_VIEW__BORDER_RADIUST:
        return borderRadiust != BORDER_RADIUST_EDEFAULT;
      case PfePackage.STYLE_VIEW__BORDER_RIGHT_COLORT:
        return borderRightColort != BORDER_RIGHT_COLORT_EDEFAULT;
      case PfePackage.STYLE_VIEW__BORDER_RIGHT_WIDTHT:
        return borderRightWidtht != BORDER_RIGHT_WIDTHT_EDEFAULT;
      case PfePackage.STYLE_VIEW__BORDER_STYLET:
        return borderStylet != BORDER_STYLET_EDEFAULT;
      case PfePackage.STYLE_VIEW__BORDER_TOP_COLORT:
        return borderTopColort != BORDER_TOP_COLORT_EDEFAULT;
      case PfePackage.STYLE_VIEW__BORDER_TOP_LEFT_RADIUST:
        return borderTopLeftRadiust != BORDER_TOP_LEFT_RADIUST_EDEFAULT;
      case PfePackage.STYLE_VIEW__BORDER_TOP_RIGHT_RADIUST:
        return borderTopRightRadiust != BORDER_TOP_RIGHT_RADIUST_EDEFAULT;
      case PfePackage.STYLE_VIEW__BORDER_TOP_WIDTHT:
        return borderTopWidtht != BORDER_TOP_WIDTHT_EDEFAULT;
      case PfePackage.STYLE_VIEW__BORDER_WIDTHT:
        return borderWidtht != BORDER_WIDTHT_EDEFAULT;
      case PfePackage.STYLE_VIEW__OPACITYT:
        return opacityt != OPACITYT_EDEFAULT;
      case PfePackage.STYLE_VIEW__ALIGN_ITEMST:
        return alignItemst != ALIGN_ITEMST_EDEFAULT;
      case PfePackage.STYLE_VIEW__ALIGN_SELFT:
        return alignSelft != ALIGN_SELFT_EDEFAULT;
      case PfePackage.STYLE_VIEW__BOTTOMT:
        return bottomt != BOTTOMT_EDEFAULT;
      case PfePackage.STYLE_VIEW__FLEXT:
        return flext != FLEXT_EDEFAULT;
      case PfePackage.STYLE_VIEW__FLEX_DIRECTIONT:
        return flexDirectiont != FLEX_DIRECTIONT_EDEFAULT;
      case PfePackage.STYLE_VIEW__FLEX_WRAPT:
        return flexWrapt != FLEX_WRAPT_EDEFAULT;
      case PfePackage.STYLE_VIEW__HEIGHTE:
        return heighte != HEIGHTE_EDEFAULT;
      case PfePackage.STYLE_VIEW__JUSTIFY_CONTENTE:
        return justifyContente != JUSTIFY_CONTENTE_EDEFAULT;
      case PfePackage.STYLE_VIEW__LEFTE:
        return lefte != LEFTE_EDEFAULT;
      case PfePackage.STYLE_VIEW__MARGIN:
        return margin != MARGIN_EDEFAULT;
      case PfePackage.STYLE_VIEW__MARGIN_BOTTOME:
        return marginBottome != MARGIN_BOTTOME_EDEFAULT;
      case PfePackage.STYLE_VIEW__MARGIN_LEFTE:
        return marginLefte != MARGIN_LEFTE_EDEFAULT;
      case PfePackage.STYLE_VIEW__MARGIN_RIGHTE:
        return marginRighte != MARGIN_RIGHTE_EDEFAULT;
      case PfePackage.STYLE_VIEW__MARGIN_TOPE:
        return marginTope != MARGIN_TOPE_EDEFAULT;
      case PfePackage.STYLE_VIEW__MARGIN_VERTICALE:
        return marginVerticale != MARGIN_VERTICALE_EDEFAULT;
      case PfePackage.STYLE_VIEW__PADDINGT:
        return paddingt != PADDINGT_EDEFAULT;
      case PfePackage.STYLE_VIEW__PADDING_BOTTOMT:
        return paddingBottomt != PADDING_BOTTOMT_EDEFAULT;
      case PfePackage.STYLE_VIEW__PADDING_HORIZONTALE:
        return paddingHorizontale != PADDING_HORIZONTALE_EDEFAULT;
      case PfePackage.STYLE_VIEW__PADDING_RIGHTE:
        return paddingRighte != PADDING_RIGHTE_EDEFAULT;
      case PfePackage.STYLE_VIEW__PADDING_TOPE:
        return paddingTope != PADDING_TOPE_EDEFAULT;
      case PfePackage.STYLE_VIEW__PADDING_VERTICALE:
        return paddingVerticale != PADDING_VERTICALE_EDEFAULT;
      case PfePackage.STYLE_VIEW__RIGHTT:
        return rightt != RIGHTT_EDEFAULT;
      case PfePackage.STYLE_VIEW__WIDTHT:
        return widtht != WIDTHT_EDEFAULT;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (backfaceVisibility2: ");
    result.append(backfaceVisibility2);
    result.append(", backgroundColor2: ");
    result.append(backgroundColor2);
    result.append(", borderBottomColor2: ");
    result.append(borderBottomColor2);
    result.append(", borderBottomLeftRadius2: ");
    result.append(borderBottomLeftRadius2);
    result.append(", borderBottomRightRadius2: ");
    result.append(borderBottomRightRadius2);
    result.append(", borderBottomWidth2: ");
    result.append(borderBottomWidth2);
    result.append(", borderColort: ");
    result.append(borderColort);
    result.append(", borderLeftColort: ");
    result.append(borderLeftColort);
    result.append(", borderLeftWidtht: ");
    result.append(borderLeftWidtht);
    result.append(", borderRadiust: ");
    result.append(borderRadiust);
    result.append(", borderRightColort: ");
    result.append(borderRightColort);
    result.append(", borderRightWidtht: ");
    result.append(borderRightWidtht);
    result.append(", borderStylet: ");
    result.append(borderStylet);
    result.append(", borderTopColort: ");
    result.append(borderTopColort);
    result.append(", borderTopLeftRadiust: ");
    result.append(borderTopLeftRadiust);
    result.append(", borderTopRightRadiust: ");
    result.append(borderTopRightRadiust);
    result.append(", borderTopWidtht: ");
    result.append(borderTopWidtht);
    result.append(", borderWidtht: ");
    result.append(borderWidtht);
    result.append(", opacityt: ");
    result.append(opacityt);
    result.append(", alignItemst: ");
    result.append(alignItemst);
    result.append(", alignSelft: ");
    result.append(alignSelft);
    result.append(", bottomt: ");
    result.append(bottomt);
    result.append(", flext: ");
    result.append(flext);
    result.append(", flexDirectiont: ");
    result.append(flexDirectiont);
    result.append(", flexWrapt: ");
    result.append(flexWrapt);
    result.append(", heighte: ");
    result.append(heighte);
    result.append(", justifyContente: ");
    result.append(justifyContente);
    result.append(", lefte: ");
    result.append(lefte);
    result.append(", margin: ");
    result.append(margin);
    result.append(", marginBottome: ");
    result.append(marginBottome);
    result.append(", marginLefte: ");
    result.append(marginLefte);
    result.append(", marginRighte: ");
    result.append(marginRighte);
    result.append(", marginTope: ");
    result.append(marginTope);
    result.append(", marginVerticale: ");
    result.append(marginVerticale);
    result.append(", paddingt: ");
    result.append(paddingt);
    result.append(", paddingBottomt: ");
    result.append(paddingBottomt);
    result.append(", paddingHorizontale: ");
    result.append(paddingHorizontale);
    result.append(", paddingRighte: ");
    result.append(paddingRighte);
    result.append(", paddingTope: ");
    result.append(paddingTope);
    result.append(", paddingVerticale: ");
    result.append(paddingVerticale);
    result.append(", rightt: ");
    result.append(rightt);
    result.append(", widtht: ");
    result.append(widtht);
    result.append(')');
    return result.toString();
  }

} //StyleViewImpl
