/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Style View</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBackfaceVisibility2 <em>Backface Visibility2</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBackgroundColor2 <em>Background Color2</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderBottomColor2 <em>Border Bottom Color2</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderBottomLeftRadius2 <em>Border Bottom Left Radius2</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderBottomRightRadius2 <em>Border Bottom Right Radius2</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderBottomWidth2 <em>Border Bottom Width2</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderColort <em>Border Colort</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderLeftColort <em>Border Left Colort</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderLeftWidtht <em>Border Left Widtht</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderRadiust <em>Border Radiust</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderRightColort <em>Border Right Colort</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderRightWidtht <em>Border Right Widtht</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderStylet <em>Border Stylet</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderTopColort <em>Border Top Colort</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderTopLeftRadiust <em>Border Top Left Radiust</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderTopRightRadiust <em>Border Top Right Radiust</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderTopWidtht <em>Border Top Widtht</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderWidtht <em>Border Widtht</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getOpacityt <em>Opacityt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getAlignItemst <em>Align Itemst</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getAlignSelft <em>Align Selft</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBottomt <em>Bottomt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getFlext <em>Flext</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getFlexDirectiont <em>Flex Directiont</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getFlexWrapt <em>Flex Wrapt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getHeighte <em>Heighte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getJustifyContente <em>Justify Contente</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getLefte <em>Lefte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMargin <em>Margin</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMarginBottome <em>Margin Bottome</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMarginLefte <em>Margin Lefte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMarginRighte <em>Margin Righte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMarginTope <em>Margin Tope</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMarginVerticale <em>Margin Verticale</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingt <em>Paddingt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingBottomt <em>Padding Bottomt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingHorizontale <em>Padding Horizontale</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingRighte <em>Padding Righte</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingTope <em>Padding Tope</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingVerticale <em>Padding Verticale</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getRightt <em>Rightt</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getWidtht <em>Widtht</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView()
 * @model
 * @generated
 */
public interface StyleView extends stylesheet
{
  /**
   * Returns the value of the '<em><b>Backface Visibility2</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Backnum}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Backface Visibility2</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Backface Visibility2</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Backnum
   * @see #setBackfaceVisibility2(Backnum)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_BackfaceVisibility2()
   * @model
   * @generated
   */
  Backnum getBackfaceVisibility2();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBackfaceVisibility2 <em>Backface Visibility2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Backface Visibility2</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Backnum
   * @see #getBackfaceVisibility2()
   * @generated
   */
  void setBackfaceVisibility2(Backnum value);

  /**
   * Returns the value of the '<em><b>Background Color2</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Colors}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Background Color2</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Background Color2</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #setBackgroundColor2(Colors)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_BackgroundColor2()
   * @model
   * @generated
   */
  Colors getBackgroundColor2();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBackgroundColor2 <em>Background Color2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Background Color2</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #getBackgroundColor2()
   * @generated
   */
  void setBackgroundColor2(Colors value);

  /**
   * Returns the value of the '<em><b>Border Bottom Color2</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Colors}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Bottom Color2</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Bottom Color2</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #setBorderBottomColor2(Colors)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_BorderBottomColor2()
   * @model
   * @generated
   */
  Colors getBorderBottomColor2();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderBottomColor2 <em>Border Bottom Color2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Bottom Color2</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #getBorderBottomColor2()
   * @generated
   */
  void setBorderBottomColor2(Colors value);

  /**
   * Returns the value of the '<em><b>Border Bottom Left Radius2</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Bottom Left Radius2</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Bottom Left Radius2</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderBottomLeftRadius2(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_BorderBottomLeftRadius2()
   * @model
   * @generated
   */
  entier getBorderBottomLeftRadius2();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderBottomLeftRadius2 <em>Border Bottom Left Radius2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Bottom Left Radius2</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderBottomLeftRadius2()
   * @generated
   */
  void setBorderBottomLeftRadius2(entier value);

  /**
   * Returns the value of the '<em><b>Border Bottom Right Radius2</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Bottom Right Radius2</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Bottom Right Radius2</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderBottomRightRadius2(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_BorderBottomRightRadius2()
   * @model
   * @generated
   */
  entier getBorderBottomRightRadius2();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderBottomRightRadius2 <em>Border Bottom Right Radius2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Bottom Right Radius2</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderBottomRightRadius2()
   * @generated
   */
  void setBorderBottomRightRadius2(entier value);

  /**
   * Returns the value of the '<em><b>Border Bottom Width2</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Bottom Width2</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Bottom Width2</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderBottomWidth2(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_BorderBottomWidth2()
   * @model
   * @generated
   */
  entier getBorderBottomWidth2();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderBottomWidth2 <em>Border Bottom Width2</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Bottom Width2</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderBottomWidth2()
   * @generated
   */
  void setBorderBottomWidth2(entier value);

  /**
   * Returns the value of the '<em><b>Border Colort</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Colors}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Colort</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Colort</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #setBorderColort(Colors)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_BorderColort()
   * @model
   * @generated
   */
  Colors getBorderColort();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderColort <em>Border Colort</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Colort</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #getBorderColort()
   * @generated
   */
  void setBorderColort(Colors value);

  /**
   * Returns the value of the '<em><b>Border Left Colort</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Colors}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Left Colort</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Left Colort</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #setBorderLeftColort(Colors)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_BorderLeftColort()
   * @model
   * @generated
   */
  Colors getBorderLeftColort();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderLeftColort <em>Border Left Colort</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Left Colort</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #getBorderLeftColort()
   * @generated
   */
  void setBorderLeftColort(Colors value);

  /**
   * Returns the value of the '<em><b>Border Left Widtht</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Left Widtht</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Left Widtht</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderLeftWidtht(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_BorderLeftWidtht()
   * @model
   * @generated
   */
  entier getBorderLeftWidtht();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderLeftWidtht <em>Border Left Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Left Widtht</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderLeftWidtht()
   * @generated
   */
  void setBorderLeftWidtht(entier value);

  /**
   * Returns the value of the '<em><b>Border Radiust</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Radiust</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Radiust</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderRadiust(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_BorderRadiust()
   * @model
   * @generated
   */
  entier getBorderRadiust();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderRadiust <em>Border Radiust</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Radiust</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderRadiust()
   * @generated
   */
  void setBorderRadiust(entier value);

  /**
   * Returns the value of the '<em><b>Border Right Colort</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Colors}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Right Colort</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Right Colort</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #setBorderRightColort(Colors)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_BorderRightColort()
   * @model
   * @generated
   */
  Colors getBorderRightColort();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderRightColort <em>Border Right Colort</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Right Colort</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #getBorderRightColort()
   * @generated
   */
  void setBorderRightColort(Colors value);

  /**
   * Returns the value of the '<em><b>Border Right Widtht</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Right Widtht</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Right Widtht</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderRightWidtht(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_BorderRightWidtht()
   * @model
   * @generated
   */
  entier getBorderRightWidtht();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderRightWidtht <em>Border Right Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Right Widtht</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderRightWidtht()
   * @generated
   */
  void setBorderRightWidtht(entier value);

  /**
   * Returns the value of the '<em><b>Border Stylet</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.bordersty}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Stylet</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Stylet</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.bordersty
   * @see #setBorderStylet(bordersty)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_BorderStylet()
   * @model
   * @generated
   */
  bordersty getBorderStylet();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderStylet <em>Border Stylet</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Stylet</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.bordersty
   * @see #getBorderStylet()
   * @generated
   */
  void setBorderStylet(bordersty value);

  /**
   * Returns the value of the '<em><b>Border Top Colort</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.Colors}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Top Colort</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Top Colort</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #setBorderTopColort(Colors)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_BorderTopColort()
   * @model
   * @generated
   */
  Colors getBorderTopColort();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderTopColort <em>Border Top Colort</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Top Colort</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see #getBorderTopColort()
   * @generated
   */
  void setBorderTopColort(Colors value);

  /**
   * Returns the value of the '<em><b>Border Top Left Radiust</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Top Left Radiust</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Top Left Radiust</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderTopLeftRadiust(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_BorderTopLeftRadiust()
   * @model
   * @generated
   */
  entier getBorderTopLeftRadiust();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderTopLeftRadiust <em>Border Top Left Radiust</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Top Left Radiust</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderTopLeftRadiust()
   * @generated
   */
  void setBorderTopLeftRadiust(entier value);

  /**
   * Returns the value of the '<em><b>Border Top Right Radiust</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Top Right Radiust</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Top Right Radiust</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderTopRightRadiust(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_BorderTopRightRadiust()
   * @model
   * @generated
   */
  entier getBorderTopRightRadiust();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderTopRightRadiust <em>Border Top Right Radiust</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Top Right Radiust</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderTopRightRadiust()
   * @generated
   */
  void setBorderTopRightRadiust(entier value);

  /**
   * Returns the value of the '<em><b>Border Top Widtht</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Top Widtht</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Top Widtht</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderTopWidtht(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_BorderTopWidtht()
   * @model
   * @generated
   */
  entier getBorderTopWidtht();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderTopWidtht <em>Border Top Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Top Widtht</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderTopWidtht()
   * @generated
   */
  void setBorderTopWidtht(entier value);

  /**
   * Returns the value of the '<em><b>Border Widtht</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Border Widtht</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Border Widtht</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBorderWidtht(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_BorderWidtht()
   * @model
   * @generated
   */
  entier getBorderWidtht();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderWidtht <em>Border Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Border Widtht</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBorderWidtht()
   * @generated
   */
  void setBorderWidtht(entier value);

  /**
   * Returns the value of the '<em><b>Opacityt</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Opacityt</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Opacityt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setOpacityt(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_Opacityt()
   * @model
   * @generated
   */
  entier getOpacityt();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getOpacityt <em>Opacityt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Opacityt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getOpacityt()
   * @generated
   */
  void setOpacityt(entier value);

  /**
   * Returns the value of the '<em><b>Align Itemst</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.aliIT}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Align Itemst</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Align Itemst</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.aliIT
   * @see #setAlignItemst(aliIT)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_AlignItemst()
   * @model
   * @generated
   */
  aliIT getAlignItemst();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getAlignItemst <em>Align Itemst</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Align Itemst</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.aliIT
   * @see #getAlignItemst()
   * @generated
   */
  void setAlignItemst(aliIT value);

  /**
   * Returns the value of the '<em><b>Align Selft</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.alfem}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Align Selft</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Align Selft</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.alfem
   * @see #setAlignSelft(alfem)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_AlignSelft()
   * @model
   * @generated
   */
  alfem getAlignSelft();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getAlignSelft <em>Align Selft</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Align Selft</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.alfem
   * @see #getAlignSelft()
   * @generated
   */
  void setAlignSelft(alfem value);

  /**
   * Returns the value of the '<em><b>Bottomt</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Bottomt</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Bottomt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setBottomt(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_Bottomt()
   * @model
   * @generated
   */
  entier getBottomt();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBottomt <em>Bottomt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Bottomt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getBottomt()
   * @generated
   */
  void setBottomt(entier value);

  /**
   * Returns the value of the '<em><b>Flext</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Flext</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Flext</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setFlext(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_Flext()
   * @model
   * @generated
   */
  entier getFlext();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getFlext <em>Flext</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Flext</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getFlext()
   * @generated
   */
  void setFlext(entier value);

  /**
   * Returns the value of the '<em><b>Flex Directiont</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.flexd}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Flex Directiont</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Flex Directiont</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.flexd
   * @see #setFlexDirectiont(flexd)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_FlexDirectiont()
   * @model
   * @generated
   */
  flexd getFlexDirectiont();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getFlexDirectiont <em>Flex Directiont</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Flex Directiont</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.flexd
   * @see #getFlexDirectiont()
   * @generated
   */
  void setFlexDirectiont(flexd value);

  /**
   * Returns the value of the '<em><b>Flex Wrapt</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.One}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Flex Wrapt</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Flex Wrapt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.One
   * @see #setFlexWrapt(One)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_FlexWrapt()
   * @model
   * @generated
   */
  One getFlexWrapt();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getFlexWrapt <em>Flex Wrapt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Flex Wrapt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.One
   * @see #getFlexWrapt()
   * @generated
   */
  void setFlexWrapt(One value);

  /**
   * Returns the value of the '<em><b>Heighte</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Heighte</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Heighte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setHeighte(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_Heighte()
   * @model
   * @generated
   */
  entier getHeighte();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getHeighte <em>Heighte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Heighte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getHeighte()
   * @generated
   */
  void setHeighte(entier value);

  /**
   * Returns the value of the '<em><b>Justify Contente</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.JustifyContentType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Justify Contente</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Justify Contente</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.JustifyContentType
   * @see #setJustifyContente(JustifyContentType)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_JustifyContente()
   * @model
   * @generated
   */
  JustifyContentType getJustifyContente();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getJustifyContente <em>Justify Contente</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Justify Contente</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.JustifyContentType
   * @see #getJustifyContente()
   * @generated
   */
  void setJustifyContente(JustifyContentType value);

  /**
   * Returns the value of the '<em><b>Lefte</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Lefte</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Lefte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setLefte(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_Lefte()
   * @model
   * @generated
   */
  entier getLefte();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getLefte <em>Lefte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Lefte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getLefte()
   * @generated
   */
  void setLefte(entier value);

  /**
   * Returns the value of the '<em><b>Margin</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Margin</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Margin</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setMargin(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_Margin()
   * @model
   * @generated
   */
  entier getMargin();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMargin <em>Margin</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Margin</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getMargin()
   * @generated
   */
  void setMargin(entier value);

  /**
   * Returns the value of the '<em><b>Margin Bottome</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Margin Bottome</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Margin Bottome</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setMarginBottome(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_MarginBottome()
   * @model
   * @generated
   */
  entier getMarginBottome();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMarginBottome <em>Margin Bottome</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Margin Bottome</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getMarginBottome()
   * @generated
   */
  void setMarginBottome(entier value);

  /**
   * Returns the value of the '<em><b>Margin Lefte</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Margin Lefte</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Margin Lefte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setMarginLefte(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_MarginLefte()
   * @model
   * @generated
   */
  entier getMarginLefte();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMarginLefte <em>Margin Lefte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Margin Lefte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getMarginLefte()
   * @generated
   */
  void setMarginLefte(entier value);

  /**
   * Returns the value of the '<em><b>Margin Righte</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Margin Righte</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Margin Righte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setMarginRighte(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_MarginRighte()
   * @model
   * @generated
   */
  entier getMarginRighte();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMarginRighte <em>Margin Righte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Margin Righte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getMarginRighte()
   * @generated
   */
  void setMarginRighte(entier value);

  /**
   * Returns the value of the '<em><b>Margin Tope</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Margin Tope</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Margin Tope</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setMarginTope(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_MarginTope()
   * @model
   * @generated
   */
  entier getMarginTope();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMarginTope <em>Margin Tope</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Margin Tope</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getMarginTope()
   * @generated
   */
  void setMarginTope(entier value);

  /**
   * Returns the value of the '<em><b>Margin Verticale</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Margin Verticale</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Margin Verticale</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setMarginVerticale(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_MarginVerticale()
   * @model
   * @generated
   */
  entier getMarginVerticale();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMarginVerticale <em>Margin Verticale</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Margin Verticale</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getMarginVerticale()
   * @generated
   */
  void setMarginVerticale(entier value);

  /**
   * Returns the value of the '<em><b>Paddingt</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Paddingt</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Paddingt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setPaddingt(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_Paddingt()
   * @model
   * @generated
   */
  entier getPaddingt();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingt <em>Paddingt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Paddingt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getPaddingt()
   * @generated
   */
  void setPaddingt(entier value);

  /**
   * Returns the value of the '<em><b>Padding Bottomt</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Padding Bottomt</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Padding Bottomt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setPaddingBottomt(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_PaddingBottomt()
   * @model
   * @generated
   */
  entier getPaddingBottomt();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingBottomt <em>Padding Bottomt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Padding Bottomt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getPaddingBottomt()
   * @generated
   */
  void setPaddingBottomt(entier value);

  /**
   * Returns the value of the '<em><b>Padding Horizontale</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Padding Horizontale</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Padding Horizontale</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setPaddingHorizontale(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_PaddingHorizontale()
   * @model
   * @generated
   */
  entier getPaddingHorizontale();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingHorizontale <em>Padding Horizontale</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Padding Horizontale</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getPaddingHorizontale()
   * @generated
   */
  void setPaddingHorizontale(entier value);

  /**
   * Returns the value of the '<em><b>Padding Righte</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Padding Righte</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Padding Righte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setPaddingRighte(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_PaddingRighte()
   * @model
   * @generated
   */
  entier getPaddingRighte();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingRighte <em>Padding Righte</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Padding Righte</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getPaddingRighte()
   * @generated
   */
  void setPaddingRighte(entier value);

  /**
   * Returns the value of the '<em><b>Padding Tope</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Padding Tope</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Padding Tope</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setPaddingTope(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_PaddingTope()
   * @model
   * @generated
   */
  entier getPaddingTope();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingTope <em>Padding Tope</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Padding Tope</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getPaddingTope()
   * @generated
   */
  void setPaddingTope(entier value);

  /**
   * Returns the value of the '<em><b>Padding Verticale</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Padding Verticale</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Padding Verticale</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setPaddingVerticale(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_PaddingVerticale()
   * @model
   * @generated
   */
  entier getPaddingVerticale();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingVerticale <em>Padding Verticale</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Padding Verticale</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getPaddingVerticale()
   * @generated
   */
  void setPaddingVerticale(entier value);

  /**
   * Returns the value of the '<em><b>Rightt</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Rightt</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Rightt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setRightt(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_Rightt()
   * @model
   * @generated
   */
  entier getRightt();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getRightt <em>Rightt</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Rightt</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getRightt()
   * @generated
   */
  void setRightt(entier value);

  /**
   * Returns the value of the '<em><b>Widtht</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.entier}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Widtht</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Widtht</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #setWidtht(entier)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getStyleView_Widtht()
   * @model
   * @generated
   */
  entier getWidtht();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getWidtht <em>Widtht</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Widtht</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see #getWidtht()
   * @generated
   */
  void setWidtht(entier value);

} // StyleView
