/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfeFactory
 * @model kind="package"
 * @generated
 */
public interface PfePackage extends EPackage
{
  /**
   * The package name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNAME = "pfe";

  /**
   * The package namespace URI.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_URI = "http://www.xtext.org/UnivTlemcen/pfe/Pfe";

  /**
   * The package namespace name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_PREFIX = "pfe";

  /**
   * The singleton instance of the package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  PfePackage eINSTANCE = org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl.init();

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ApplicationImpl <em>Application</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.ApplicationImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getApplication()
   * @generated
   */
  int APPLICATION = 0;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int APPLICATION__NAME = 0;

  /**
   * The feature id for the '<em><b>Package Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int APPLICATION__PACKAGE_NAME = 1;

  /**
   * The feature id for the '<em><b>First Layout</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int APPLICATION__FIRST_LAYOUT = 2;

  /**
   * The feature id for the '<em><b>Model</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int APPLICATION__MODEL = 3;

  /**
   * The feature id for the '<em><b>Vue</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int APPLICATION__VUE = 4;

  /**
   * The feature id for the '<em><b>Controleur</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int APPLICATION__CONTROLEUR = 5;

  /**
   * The number of structural features of the '<em>Application</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int APPLICATION_FEATURE_COUNT = 6;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ControleurImpl <em>Controleur</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.ControleurImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getControleur()
   * @generated
   */
  int CONTROLEUR = 1;

  /**
   * The number of structural features of the '<em>Controleur</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONTROLEUR_FEATURE_COUNT = 0;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.FonctionsImpl <em>Fonctions</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.FonctionsImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getFonctions()
   * @generated
   */
  int FONCTIONS = 2;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FONCTIONS__NAME = CONTROLEUR_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Fonctions</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FONCTIONS_FEATURE_COUNT = CONTROLEUR_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.stylesheetImpl <em>stylesheet</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.stylesheetImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getstylesheet()
   * @generated
   */
  int STYLESHEET = 3;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLESHEET__NAME = FONCTIONS__NAME;

  /**
   * The number of structural features of the '<em>stylesheet</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLESHEET_FEATURE_COUNT = FONCTIONS_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.fonctionImpl <em>fonction</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.fonctionImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getfonction()
   * @generated
   */
  int FONCTION = 4;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FONCTION__NAME = FONCTIONS__NAME;

  /**
   * The number of structural features of the '<em>fonction</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FONCTION_FEATURE_COUNT = FONCTIONS_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl <em>Style Text</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getStyleText()
   * @generated
   */
  int STYLE_TEXT = 5;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__NAME = STYLESHEET__NAME;

  /**
   * The feature id for the '<em><b>Colore</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__COLORE = STYLESHEET_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Font Family E</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__FONT_FAMILY_E = STYLESHEET_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Font Sizes</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__FONT_SIZES = STYLESHEET_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Font Styles</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__FONT_STYLES = STYLESHEET_FEATURE_COUNT + 3;

  /**
   * The feature id for the '<em><b>Font Weighte</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__FONT_WEIGHTE = STYLESHEET_FEATURE_COUNT + 4;

  /**
   * The feature id for the '<em><b>Line Heighte</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__LINE_HEIGHTE = STYLESHEET_FEATURE_COUNT + 5;

  /**
   * The feature id for the '<em><b>Text Aligne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__TEXT_ALIGNE = STYLESHEET_FEATURE_COUNT + 6;

  /**
   * The feature id for the '<em><b>Backface Visibilitye</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__BACKFACE_VISIBILITYE = STYLESHEET_FEATURE_COUNT + 7;

  /**
   * The feature id for the '<em><b>Background Colore</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__BACKGROUND_COLORE = STYLESHEET_FEATURE_COUNT + 8;

  /**
   * The feature id for the '<em><b>Border Bottom Colore</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__BORDER_BOTTOM_COLORE = STYLESHEET_FEATURE_COUNT + 9;

  /**
   * The feature id for the '<em><b>Border Bottom Left Radiuse</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__BORDER_BOTTOM_LEFT_RADIUSE = STYLESHEET_FEATURE_COUNT + 10;

  /**
   * The feature id for the '<em><b>Border Bottom Right Radiuse</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__BORDER_BOTTOM_RIGHT_RADIUSE = STYLESHEET_FEATURE_COUNT + 11;

  /**
   * The feature id for the '<em><b>Border Bottom Widthe</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__BORDER_BOTTOM_WIDTHE = STYLESHEET_FEATURE_COUNT + 12;

  /**
   * The feature id for the '<em><b>Border Colore</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__BORDER_COLORE = STYLESHEET_FEATURE_COUNT + 13;

  /**
   * The feature id for the '<em><b>Border Left Colore</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__BORDER_LEFT_COLORE = STYLESHEET_FEATURE_COUNT + 14;

  /**
   * The feature id for the '<em><b>Border Left Widthe</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__BORDER_LEFT_WIDTHE = STYLESHEET_FEATURE_COUNT + 15;

  /**
   * The feature id for the '<em><b>Border Radiuse</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__BORDER_RADIUSE = STYLESHEET_FEATURE_COUNT + 16;

  /**
   * The feature id for the '<em><b>Border Right Colore</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__BORDER_RIGHT_COLORE = STYLESHEET_FEATURE_COUNT + 17;

  /**
   * The feature id for the '<em><b>Border Right Width</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__BORDER_RIGHT_WIDTH = STYLESHEET_FEATURE_COUNT + 18;

  /**
   * The feature id for the '<em><b>Border Styles</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__BORDER_STYLES = STYLESHEET_FEATURE_COUNT + 19;

  /**
   * The feature id for the '<em><b>Border Top Colore</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__BORDER_TOP_COLORE = STYLESHEET_FEATURE_COUNT + 20;

  /**
   * The feature id for the '<em><b>Border Top Left Radiuse</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__BORDER_TOP_LEFT_RADIUSE = STYLESHEET_FEATURE_COUNT + 21;

  /**
   * The feature id for the '<em><b>Border Top Right Radiuse</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__BORDER_TOP_RIGHT_RADIUSE = STYLESHEET_FEATURE_COUNT + 22;

  /**
   * The feature id for the '<em><b>Border Top Widthe</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__BORDER_TOP_WIDTHE = STYLESHEET_FEATURE_COUNT + 23;

  /**
   * The feature id for the '<em><b>Border Widthe</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__BORDER_WIDTHE = STYLESHEET_FEATURE_COUNT + 24;

  /**
   * The feature id for the '<em><b>Opacitye</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT__OPACITYE = STYLESHEET_FEATURE_COUNT + 25;

  /**
   * The number of structural features of the '<em>Style Text</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_TEXT_FEATURE_COUNT = STYLESHEET_FEATURE_COUNT + 26;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl <em>Style View</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getStyleView()
   * @generated
   */
  int STYLE_VIEW = 6;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__NAME = STYLESHEET__NAME;

  /**
   * The feature id for the '<em><b>Backface Visibility2</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__BACKFACE_VISIBILITY2 = STYLESHEET_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Background Color2</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__BACKGROUND_COLOR2 = STYLESHEET_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Border Bottom Color2</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__BORDER_BOTTOM_COLOR2 = STYLESHEET_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Border Bottom Left Radius2</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__BORDER_BOTTOM_LEFT_RADIUS2 = STYLESHEET_FEATURE_COUNT + 3;

  /**
   * The feature id for the '<em><b>Border Bottom Right Radius2</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__BORDER_BOTTOM_RIGHT_RADIUS2 = STYLESHEET_FEATURE_COUNT + 4;

  /**
   * The feature id for the '<em><b>Border Bottom Width2</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__BORDER_BOTTOM_WIDTH2 = STYLESHEET_FEATURE_COUNT + 5;

  /**
   * The feature id for the '<em><b>Border Colort</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__BORDER_COLORT = STYLESHEET_FEATURE_COUNT + 6;

  /**
   * The feature id for the '<em><b>Border Left Colort</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__BORDER_LEFT_COLORT = STYLESHEET_FEATURE_COUNT + 7;

  /**
   * The feature id for the '<em><b>Border Left Widtht</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__BORDER_LEFT_WIDTHT = STYLESHEET_FEATURE_COUNT + 8;

  /**
   * The feature id for the '<em><b>Border Radiust</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__BORDER_RADIUST = STYLESHEET_FEATURE_COUNT + 9;

  /**
   * The feature id for the '<em><b>Border Right Colort</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__BORDER_RIGHT_COLORT = STYLESHEET_FEATURE_COUNT + 10;

  /**
   * The feature id for the '<em><b>Border Right Widtht</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__BORDER_RIGHT_WIDTHT = STYLESHEET_FEATURE_COUNT + 11;

  /**
   * The feature id for the '<em><b>Border Stylet</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__BORDER_STYLET = STYLESHEET_FEATURE_COUNT + 12;

  /**
   * The feature id for the '<em><b>Border Top Colort</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__BORDER_TOP_COLORT = STYLESHEET_FEATURE_COUNT + 13;

  /**
   * The feature id for the '<em><b>Border Top Left Radiust</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__BORDER_TOP_LEFT_RADIUST = STYLESHEET_FEATURE_COUNT + 14;

  /**
   * The feature id for the '<em><b>Border Top Right Radiust</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__BORDER_TOP_RIGHT_RADIUST = STYLESHEET_FEATURE_COUNT + 15;

  /**
   * The feature id for the '<em><b>Border Top Widtht</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__BORDER_TOP_WIDTHT = STYLESHEET_FEATURE_COUNT + 16;

  /**
   * The feature id for the '<em><b>Border Widtht</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__BORDER_WIDTHT = STYLESHEET_FEATURE_COUNT + 17;

  /**
   * The feature id for the '<em><b>Opacityt</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__OPACITYT = STYLESHEET_FEATURE_COUNT + 18;

  /**
   * The feature id for the '<em><b>Align Itemst</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__ALIGN_ITEMST = STYLESHEET_FEATURE_COUNT + 19;

  /**
   * The feature id for the '<em><b>Align Selft</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__ALIGN_SELFT = STYLESHEET_FEATURE_COUNT + 20;

  /**
   * The feature id for the '<em><b>Bottomt</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__BOTTOMT = STYLESHEET_FEATURE_COUNT + 21;

  /**
   * The feature id for the '<em><b>Flext</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__FLEXT = STYLESHEET_FEATURE_COUNT + 22;

  /**
   * The feature id for the '<em><b>Flex Directiont</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__FLEX_DIRECTIONT = STYLESHEET_FEATURE_COUNT + 23;

  /**
   * The feature id for the '<em><b>Flex Wrapt</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__FLEX_WRAPT = STYLESHEET_FEATURE_COUNT + 24;

  /**
   * The feature id for the '<em><b>Heighte</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__HEIGHTE = STYLESHEET_FEATURE_COUNT + 25;

  /**
   * The feature id for the '<em><b>Justify Contente</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__JUSTIFY_CONTENTE = STYLESHEET_FEATURE_COUNT + 26;

  /**
   * The feature id for the '<em><b>Lefte</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__LEFTE = STYLESHEET_FEATURE_COUNT + 27;

  /**
   * The feature id for the '<em><b>Margin</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__MARGIN = STYLESHEET_FEATURE_COUNT + 28;

  /**
   * The feature id for the '<em><b>Margin Bottome</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__MARGIN_BOTTOME = STYLESHEET_FEATURE_COUNT + 29;

  /**
   * The feature id for the '<em><b>Margin Lefte</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__MARGIN_LEFTE = STYLESHEET_FEATURE_COUNT + 30;

  /**
   * The feature id for the '<em><b>Margin Righte</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__MARGIN_RIGHTE = STYLESHEET_FEATURE_COUNT + 31;

  /**
   * The feature id for the '<em><b>Margin Tope</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__MARGIN_TOPE = STYLESHEET_FEATURE_COUNT + 32;

  /**
   * The feature id for the '<em><b>Margin Verticale</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__MARGIN_VERTICALE = STYLESHEET_FEATURE_COUNT + 33;

  /**
   * The feature id for the '<em><b>Paddingt</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__PADDINGT = STYLESHEET_FEATURE_COUNT + 34;

  /**
   * The feature id for the '<em><b>Padding Bottomt</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__PADDING_BOTTOMT = STYLESHEET_FEATURE_COUNT + 35;

  /**
   * The feature id for the '<em><b>Padding Horizontale</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__PADDING_HORIZONTALE = STYLESHEET_FEATURE_COUNT + 36;

  /**
   * The feature id for the '<em><b>Padding Righte</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__PADDING_RIGHTE = STYLESHEET_FEATURE_COUNT + 37;

  /**
   * The feature id for the '<em><b>Padding Tope</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__PADDING_TOPE = STYLESHEET_FEATURE_COUNT + 38;

  /**
   * The feature id for the '<em><b>Padding Verticale</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__PADDING_VERTICALE = STYLESHEET_FEATURE_COUNT + 39;

  /**
   * The feature id for the '<em><b>Rightt</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__RIGHTT = STYLESHEET_FEATURE_COUNT + 40;

  /**
   * The feature id for the '<em><b>Widtht</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW__WIDTHT = STYLESHEET_FEATURE_COUNT + 41;

  /**
   * The number of structural features of the '<em>Style View</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_VIEW_FEATURE_COUNT = STYLESHEET_FEATURE_COUNT + 42;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl <em>Style Image</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getStyleImage()
   * @generated
   */
  int STYLE_IMAGE = 7;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__NAME = STYLESHEET__NAME;

  /**
   * The feature id for the '<em><b>Backface Visibility</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__BACKFACE_VISIBILITY = STYLESHEET_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Background Colora</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__BACKGROUND_COLORA = STYLESHEET_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Border Bottom Left Radiusa</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__BORDER_BOTTOM_LEFT_RADIUSA = STYLESHEET_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Border Bottom Right Radiusa</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__BORDER_BOTTOM_RIGHT_RADIUSA = STYLESHEET_FEATURE_COUNT + 3;

  /**
   * The feature id for the '<em><b>Border Colora</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__BORDER_COLORA = STYLESHEET_FEATURE_COUNT + 4;

  /**
   * The feature id for the '<em><b>Border Radiusa</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__BORDER_RADIUSA = STYLESHEET_FEATURE_COUNT + 5;

  /**
   * The feature id for the '<em><b>Border Top Left Radiusa</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__BORDER_TOP_LEFT_RADIUSA = STYLESHEET_FEATURE_COUNT + 6;

  /**
   * The feature id for the '<em><b>Border Top Right Radiusa</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__BORDER_TOP_RIGHT_RADIUSA = STYLESHEET_FEATURE_COUNT + 7;

  /**
   * The feature id for the '<em><b>Border Widtha</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__BORDER_WIDTHA = STYLESHEET_FEATURE_COUNT + 8;

  /**
   * The feature id for the '<em><b>Opacitya</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__OPACITYA = STYLESHEET_FEATURE_COUNT + 9;

  /**
   * The feature id for the '<em><b>Overflowa</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__OVERFLOWA = STYLESHEET_FEATURE_COUNT + 10;

  /**
   * The feature id for the '<em><b>Align Itemst</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__ALIGN_ITEMST = STYLESHEET_FEATURE_COUNT + 11;

  /**
   * The feature id for the '<em><b>Align Selft</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__ALIGN_SELFT = STYLESHEET_FEATURE_COUNT + 12;

  /**
   * The feature id for the '<em><b>Bottomt</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__BOTTOMT = STYLESHEET_FEATURE_COUNT + 13;

  /**
   * The feature id for the '<em><b>Flext</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__FLEXT = STYLESHEET_FEATURE_COUNT + 14;

  /**
   * The feature id for the '<em><b>Justify Contente</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__JUSTIFY_CONTENTE = STYLESHEET_FEATURE_COUNT + 15;

  /**
   * The feature id for the '<em><b>Lefte</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__LEFTE = STYLESHEET_FEATURE_COUNT + 16;

  /**
   * The feature id for the '<em><b>Margin</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__MARGIN = STYLESHEET_FEATURE_COUNT + 17;

  /**
   * The feature id for the '<em><b>Margin Bottome</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__MARGIN_BOTTOME = STYLESHEET_FEATURE_COUNT + 18;

  /**
   * The feature id for the '<em><b>Margin Lefte</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__MARGIN_LEFTE = STYLESHEET_FEATURE_COUNT + 19;

  /**
   * The feature id for the '<em><b>Margin Righte</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__MARGIN_RIGHTE = STYLESHEET_FEATURE_COUNT + 20;

  /**
   * The feature id for the '<em><b>Margin Tope</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__MARGIN_TOPE = STYLESHEET_FEATURE_COUNT + 21;

  /**
   * The feature id for the '<em><b>Margin Verticale</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__MARGIN_VERTICALE = STYLESHEET_FEATURE_COUNT + 22;

  /**
   * The feature id for the '<em><b>Paddingt</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__PADDINGT = STYLESHEET_FEATURE_COUNT + 23;

  /**
   * The feature id for the '<em><b>Padding Bottomt</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__PADDING_BOTTOMT = STYLESHEET_FEATURE_COUNT + 24;

  /**
   * The feature id for the '<em><b>Padding Horizontale</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__PADDING_HORIZONTALE = STYLESHEET_FEATURE_COUNT + 25;

  /**
   * The feature id for the '<em><b>Padding Righte</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__PADDING_RIGHTE = STYLESHEET_FEATURE_COUNT + 26;

  /**
   * The feature id for the '<em><b>Padding Tope</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__PADDING_TOPE = STYLESHEET_FEATURE_COUNT + 27;

  /**
   * The feature id for the '<em><b>Padding Verticale</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__PADDING_VERTICALE = STYLESHEET_FEATURE_COUNT + 28;

  /**
   * The feature id for the '<em><b>Rightt</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__RIGHTT = STYLESHEET_FEATURE_COUNT + 29;

  /**
   * The feature id for the '<em><b>Widtht</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__WIDTHT = STYLESHEET_FEATURE_COUNT + 30;

  /**
   * The feature id for the '<em><b>Flex Directiont</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__FLEX_DIRECTIONT = STYLESHEET_FEATURE_COUNT + 31;

  /**
   * The feature id for the '<em><b>Flex Wrapt</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__FLEX_WRAPT = STYLESHEET_FEATURE_COUNT + 32;

  /**
   * The feature id for the '<em><b>Heighte</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE__HEIGHTE = STYLESHEET_FEATURE_COUNT + 33;

  /**
   * The number of structural features of the '<em>Style Image</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLE_IMAGE_FEATURE_COUNT = STYLESHEET_FEATURE_COUNT + 34;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl <em>Styleflexbox</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getStyleflexbox()
   * @generated
   */
  int STYLEFLEXBOX = 8;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__NAME = STYLESHEET__NAME;

  /**
   * The feature id for the '<em><b>Align Items3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__ALIGN_ITEMS3 = STYLESHEET_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Align Self3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__ALIGN_SELF3 = STYLESHEET_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Border Bottom Width3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__BORDER_BOTTOM_WIDTH3 = STYLESHEET_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Border Left Width3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__BORDER_LEFT_WIDTH3 = STYLESHEET_FEATURE_COUNT + 3;

  /**
   * The feature id for the '<em><b>Border Right Width3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__BORDER_RIGHT_WIDTH3 = STYLESHEET_FEATURE_COUNT + 4;

  /**
   * The feature id for the '<em><b>Border Top Width3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__BORDER_TOP_WIDTH3 = STYLESHEET_FEATURE_COUNT + 5;

  /**
   * The feature id for the '<em><b>Border Width3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__BORDER_WIDTH3 = STYLESHEET_FEATURE_COUNT + 6;

  /**
   * The feature id for the '<em><b>Bottom3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__BOTTOM3 = STYLESHEET_FEATURE_COUNT + 7;

  /**
   * The feature id for the '<em><b>Flex3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__FLEX3 = STYLESHEET_FEATURE_COUNT + 8;

  /**
   * The feature id for the '<em><b>Flex Direction3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__FLEX_DIRECTION3 = STYLESHEET_FEATURE_COUNT + 9;

  /**
   * The feature id for the '<em><b>Flex Wrap3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__FLEX_WRAP3 = STYLESHEET_FEATURE_COUNT + 10;

  /**
   * The feature id for the '<em><b>Height3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__HEIGHT3 = STYLESHEET_FEATURE_COUNT + 11;

  /**
   * The feature id for the '<em><b>Justify Content3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__JUSTIFY_CONTENT3 = STYLESHEET_FEATURE_COUNT + 12;

  /**
   * The feature id for the '<em><b>Left3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__LEFT3 = STYLESHEET_FEATURE_COUNT + 13;

  /**
   * The feature id for the '<em><b>Margin3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__MARGIN3 = STYLESHEET_FEATURE_COUNT + 14;

  /**
   * The feature id for the '<em><b>Margin Bottom3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__MARGIN_BOTTOM3 = STYLESHEET_FEATURE_COUNT + 15;

  /**
   * The feature id for the '<em><b>Margin Left3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__MARGIN_LEFT3 = STYLESHEET_FEATURE_COUNT + 16;

  /**
   * The feature id for the '<em><b>Margin Right3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__MARGIN_RIGHT3 = STYLESHEET_FEATURE_COUNT + 17;

  /**
   * The feature id for the '<em><b>Margin Top3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__MARGIN_TOP3 = STYLESHEET_FEATURE_COUNT + 18;

  /**
   * The feature id for the '<em><b>Margin Vertical3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__MARGIN_VERTICAL3 = STYLESHEET_FEATURE_COUNT + 19;

  /**
   * The feature id for the '<em><b>Pendding3</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__PENDDING3 = STYLESHEET_FEATURE_COUNT + 20;

  /**
   * The feature id for the '<em><b>Pandding B</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX__PANDDING_B = STYLESHEET_FEATURE_COUNT + 21;

  /**
   * The number of structural features of the '<em>Styleflexbox</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STYLEFLEXBOX_FEATURE_COUNT = STYLESHEET_FEATURE_COUNT + 22;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.RemplirTableImpl <em>Remplir Table</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.RemplirTableImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getRemplirTable()
   * @generated
   */
  int REMPLIR_TABLE = 9;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int REMPLIR_TABLE__NAME = FONCTION__NAME;

  /**
   * The feature id for the '<em><b>Utiliser</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int REMPLIR_TABLE__UTILISER = FONCTION_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Remplir Table</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int REMPLIR_TABLE_FEATURE_COUNT = FONCTION_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.AlerteFonctionImpl <em>Alerte Fonction</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.AlerteFonctionImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getAlerteFonction()
   * @generated
   */
  int ALERTE_FONCTION = 10;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ALERTE_FONCTION__NAME = FONCTION__NAME;

  /**
   * The feature id for the '<em><b>Message</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ALERTE_FONCTION__MESSAGE = FONCTION_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Alerte Fonction</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ALERTE_FONCTION_FEATURE_COUNT = FONCTION_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.NavigateImpl <em>Navigate</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.NavigateImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getNavigate()
   * @generated
   */
  int NAVIGATE = 11;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NAVIGATE__NAME = FONCTION__NAME;

  /**
   * The feature id for the '<em><b>Ref</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NAVIGATE__REF = FONCTION_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Navigate</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int NAVIGATE_FEATURE_COUNT = FONCTION_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.VueImpl <em>Vue</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.VueImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getVue()
   * @generated
   */
  int VUE = 12;

  /**
   * The number of structural features of the '<em>Vue</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int VUE_FEATURE_COUNT = 0;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ElementsImpl <em>Elements</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.ElementsImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getElements()
   * @generated
   */
  int ELEMENTS = 13;

  /**
   * The number of structural features of the '<em>Elements</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ELEMENTS_FEATURE_COUNT = VUE_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.composantImpl <em>composant</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.composantImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getcomposant()
   * @generated
   */
  int COMPOSANT = 14;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int COMPOSANT__NAME = ELEMENTS_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>composant</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int COMPOSANT_FEATURE_COUNT = ELEMENTS_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.FormsImpl <em>Forms</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.FormsImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getForms()
   * @generated
   */
  int FORMS = 15;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FORMS__NAME = ELEMENTS_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Ligne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FORMS__LIGNE = ELEMENTS_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Colonne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FORMS__COLONNE = ELEMENTS_FEATURE_COUNT + 2;

  /**
   * The number of structural features of the '<em>Forms</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FORMS_FEATURE_COUNT = ELEMENTS_FEATURE_COUNT + 3;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.listsImpl <em>lists</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.listsImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getlists()
   * @generated
   */
  int LISTS = 16;

  /**
   * The number of structural features of the '<em>lists</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LISTS_FEATURE_COUNT = ELEMENTS_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.IconsImpl <em>Icons</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.IconsImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getIcons()
   * @generated
   */
  int ICONS = 17;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ICONS__NAME = ELEMENTS_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Ligne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ICONS__LIGNE = ELEMENTS_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Colonne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ICONS__COLONNE = ELEMENTS_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Style</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ICONS__STYLE = ELEMENTS_FEATURE_COUNT + 3;

  /**
   * The number of structural features of the '<em>Icons</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ICONS_FEATURE_COUNT = ELEMENTS_FEATURE_COUNT + 4;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.listViewImpl <em>list View</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.listViewImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getlistView()
   * @generated
   */
  int LIST_VIEW = 18;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LIST_VIEW__NAME = LISTS_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Utiliser</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LIST_VIEW__UTILISER = LISTS_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Ligne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LIST_VIEW__LIGNE = LISTS_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Colonne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LIST_VIEW__COLONNE = LISTS_FEATURE_COUNT + 3;

  /**
   * The feature id for the '<em><b>Style</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LIST_VIEW__STYLE = LISTS_FEATURE_COUNT + 4;

  /**
   * The number of structural features of the '<em>list View</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LIST_VIEW_FEATURE_COUNT = LISTS_FEATURE_COUNT + 5;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.RadioButtonImpl <em>Radio Button</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.RadioButtonImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getRadioButton()
   * @generated
   */
  int RADIO_BUTTON = 19;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int RADIO_BUTTON__NAME = ELEMENTS_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Ligne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int RADIO_BUTTON__LIGNE = ELEMENTS_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Colonne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int RADIO_BUTTON__COLONNE = ELEMENTS_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Style</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int RADIO_BUTTON__STYLE = ELEMENTS_FEATURE_COUNT + 3;

  /**
   * The number of structural features of the '<em>Radio Button</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int RADIO_BUTTON_FEATURE_COUNT = ELEMENTS_FEATURE_COUNT + 4;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.CheckBoxImpl <em>Check Box</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.CheckBoxImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getCheckBox()
   * @generated
   */
  int CHECK_BOX = 20;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CHECK_BOX__NAME = ELEMENTS_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Ligne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CHECK_BOX__LIGNE = ELEMENTS_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Colonne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CHECK_BOX__COLONNE = ELEMENTS_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Style</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CHECK_BOX__STYLE = ELEMENTS_FEATURE_COUNT + 3;

  /**
   * The number of structural features of the '<em>Check Box</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CHECK_BOX_FEATURE_COUNT = ELEMENTS_FEATURE_COUNT + 4;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.TextImpl <em>Text</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.TextImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getText()
   * @generated
   */
  int TEXT = 21;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TEXT__NAME = FORMS__NAME;

  /**
   * The feature id for the '<em><b>Ligne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TEXT__LIGNE = FORMS__LIGNE;

  /**
   * The feature id for the '<em><b>Colonne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TEXT__COLONNE = FORMS__COLONNE;

  /**
   * The feature id for the '<em><b>Contenu</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TEXT__CONTENU = FORMS_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Style</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TEXT__STYLE = FORMS_FEATURE_COUNT + 1;

  /**
   * The number of structural features of the '<em>Text</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TEXT_FEATURE_COUNT = FORMS_FEATURE_COUNT + 2;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.InputImpl <em>Input</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.InputImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getInput()
   * @generated
   */
  int INPUT = 22;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT__NAME = FORMS__NAME;

  /**
   * The feature id for the '<em><b>Ligne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT__LIGNE = FORMS__LIGNE;

  /**
   * The feature id for the '<em><b>Colonne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT__COLONNE = FORMS__COLONNE;

  /**
   * The feature id for the '<em><b>Style</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT__STYLE = FORMS_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Input</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int INPUT_FEATURE_COUNT = FORMS_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.IconeImpl <em>Icone</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.IconeImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getIcone()
   * @generated
   */
  int ICONE = 23;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ICONE__NAME = ICONS__NAME;

  /**
   * The feature id for the '<em><b>Ligne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ICONE__LIGNE = ICONS__LIGNE;

  /**
   * The feature id for the '<em><b>Colonne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ICONE__COLONNE = ICONS__COLONNE;

  /**
   * The feature id for the '<em><b>Style</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ICONE__STYLE = ICONS__STYLE;

  /**
   * The feature id for the '<em><b>Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ICONE__TYPE = ICONS_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Icone</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ICONE_FEATURE_COUNT = ICONS_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.SocialIconImpl <em>Social Icon</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.SocialIconImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getSocialIcon()
   * @generated
   */
  int SOCIAL_ICON = 24;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SOCIAL_ICON__NAME = ICONS__NAME;

  /**
   * The feature id for the '<em><b>Ligne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SOCIAL_ICON__LIGNE = ICONS__LIGNE;

  /**
   * The feature id for the '<em><b>Colonne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SOCIAL_ICON__COLONNE = ICONS__COLONNE;

  /**
   * The feature id for the '<em><b>Style</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SOCIAL_ICON__STYLE = ICONS__STYLE;

  /**
   * The feature id for the '<em><b>Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SOCIAL_ICON__TYPE = ICONS_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Button</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SOCIAL_ICON__BUTTON = ICONS_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Raised</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SOCIAL_ICON__RAISED = ICONS_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Onclique</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SOCIAL_ICON__ONCLIQUE = ICONS_FEATURE_COUNT + 3;

  /**
   * The feature id for the '<em><b>Onlongclique</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SOCIAL_ICON__ONLONGCLIQUE = ICONS_FEATURE_COUNT + 4;

  /**
   * The number of structural features of the '<em>Social Icon</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SOCIAL_ICON_FEATURE_COUNT = ICONS_FEATURE_COUNT + 5;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.TabImpl <em>Tab</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.TabImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getTab()
   * @generated
   */
  int TAB = 25;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TAB__NAME = ELEMENTS_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Title</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TAB__TITLE = ELEMENTS_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Text</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TAB__TEXT = ELEMENTS_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Icon</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TAB__ICON = ELEMENTS_FEATURE_COUNT + 3;

  /**
   * The feature id for the '<em><b>Elements</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TAB__ELEMENTS = ELEMENTS_FEATURE_COUNT + 4;

  /**
   * The feature id for the '<em><b>Ligne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TAB__LIGNE = ELEMENTS_FEATURE_COUNT + 5;

  /**
   * The feature id for the '<em><b>Colonne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TAB__COLONNE = ELEMENTS_FEATURE_COUNT + 6;

  /**
   * The number of structural features of the '<em>Tab</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TAB_FEATURE_COUNT = ELEMENTS_FEATURE_COUNT + 7;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.HeadingImpl <em>Heading</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.HeadingImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getHeading()
   * @generated
   */
  int HEADING = 26;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HEADING__NAME = ELEMENTS_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HEADING__TYPE = ELEMENTS_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Ligne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HEADING__LIGNE = ELEMENTS_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Colonne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HEADING__COLONNE = ELEMENTS_FEATURE_COUNT + 3;

  /**
   * The number of structural features of the '<em>Heading</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int HEADING_FEATURE_COUNT = ELEMENTS_FEATURE_COUNT + 4;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ContainerStyleImpl <em>Container Style</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.ContainerStyleImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getContainerStyle()
   * @generated
   */
  int CONTAINER_STYLE = 27;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONTAINER_STYLE__NAME = ELEMENTS_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Container Style</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONTAINER_STYLE_FEATURE_COUNT = ELEMENTS_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ContainerFonctionsImpl <em>Container Fonctions</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.ContainerFonctionsImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getContainerFonctions()
   * @generated
   */
  int CONTAINER_FONCTIONS = 28;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONTAINER_FONCTIONS__NAME = ELEMENTS_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Container Fonctions</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int CONTAINER_FONCTIONS_FEATURE_COUNT = ELEMENTS_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.LayoutImpl <em>Layout</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.LayoutImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getLayout()
   * @generated
   */
  int LAYOUT = 29;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LAYOUT__NAME = ELEMENTS_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Titre</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LAYOUT__TITRE = ELEMENTS_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Contient</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LAYOUT__CONTIENT = ELEMENTS_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Style</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LAYOUT__STYLE = ELEMENTS_FEATURE_COUNT + 3;

  /**
   * The feature id for the '<em><b>Style B</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LAYOUT__STYLE_B = ELEMENTS_FEATURE_COUNT + 4;

  /**
   * The number of structural features of the '<em>Layout</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int LAYOUT_FEATURE_COUNT = ELEMENTS_FEATURE_COUNT + 5;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.BoutonImpl <em>Bouton</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.BoutonImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getBouton()
   * @generated
   */
  int BOUTON = 30;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BOUTON__NAME = ELEMENTS_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Icon</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BOUTON__ICON = ELEMENTS_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Onclique</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BOUTON__ONCLIQUE = ELEMENTS_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Onlongclique</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BOUTON__ONLONGCLIQUE = ELEMENTS_FEATURE_COUNT + 3;

  /**
   * The feature id for the '<em><b>Prop</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BOUTON__PROP = ELEMENTS_FEATURE_COUNT + 4;

  /**
   * The feature id for the '<em><b>Icon Right</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BOUTON__ICON_RIGHT = ELEMENTS_FEATURE_COUNT + 5;

  /**
   * The feature id for the '<em><b>Ligne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BOUTON__LIGNE = ELEMENTS_FEATURE_COUNT + 6;

  /**
   * The feature id for the '<em><b>Colonne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BOUTON__COLONNE = ELEMENTS_FEATURE_COUNT + 7;

  /**
   * The feature id for the '<em><b>Style</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BOUTON__STYLE = ELEMENTS_FEATURE_COUNT + 8;

  /**
   * The number of structural features of the '<em>Bouton</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int BOUTON_FEATURE_COUNT = ELEMENTS_FEATURE_COUNT + 9;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.VideoImpl <em>Video</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.VideoImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getVideo()
   * @generated
   */
  int VIDEO = 31;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int VIDEO__NAME = COMPOSANT__NAME;

  /**
   * The feature id for the '<em><b>Url V</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int VIDEO__URL_V = COMPOSANT_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Mutte</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int VIDEO__MUTTE = COMPOSANT_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Widtht</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int VIDEO__WIDTHT = COMPOSANT_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Heightr</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int VIDEO__HEIGHTR = COMPOSANT_FEATURE_COUNT + 3;

  /**
   * The feature id for the '<em><b>Ligne Audio</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int VIDEO__LIGNE_AUDIO = COMPOSANT_FEATURE_COUNT + 4;

  /**
   * The feature id for the '<em><b>Colone Audio</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int VIDEO__COLONE_AUDIO = COMPOSANT_FEATURE_COUNT + 5;

  /**
   * The number of structural features of the '<em>Video</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int VIDEO_FEATURE_COUNT = COMPOSANT_FEATURE_COUNT + 6;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.AudioImpl <em>Audio</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.AudioImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getAudio()
   * @generated
   */
  int AUDIO = 32;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO__NAME = COMPOSANT__NAME;

  /**
   * The feature id for the '<em><b>Url T</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO__URL_T = COMPOSANT_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Textbout</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO__TEXTBOUT = COMPOSANT_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Ligne Audio</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO__LIGNE_AUDIO = COMPOSANT_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Colone Audio</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO__COLONE_AUDIO = COMPOSANT_FEATURE_COUNT + 3;

  /**
   * The feature id for the '<em><b>Style Audio</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO__STYLE_AUDIO = COMPOSANT_FEATURE_COUNT + 4;

  /**
   * The number of structural features of the '<em>Audio</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AUDIO_FEATURE_COUNT = COMPOSANT_FEATURE_COUNT + 5;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.MapViewImpl <em>Map View</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.MapViewImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getMapView()
   * @generated
   */
  int MAP_VIEW = 33;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAP_VIEW__NAME = COMPOSANT__NAME;

  /**
   * The feature id for the '<em><b>Latitude</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAP_VIEW__LATITUDE = COMPOSANT_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Longitude</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAP_VIEW__LONGITUDE = COMPOSANT_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Latitude Delta</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAP_VIEW__LATITUDE_DELTA = COMPOSANT_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Longitude Delta</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAP_VIEW__LONGITUDE_DELTA = COMPOSANT_FEATURE_COUNT + 3;

  /**
   * The feature id for the '<em><b>Ligne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAP_VIEW__LIGNE = COMPOSANT_FEATURE_COUNT + 4;

  /**
   * The feature id for the '<em><b>Colone</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAP_VIEW__COLONE = COMPOSANT_FEATURE_COUNT + 5;

  /**
   * The number of structural features of the '<em>Map View</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAP_VIEW_FEATURE_COUNT = COMPOSANT_FEATURE_COUNT + 6;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ImageImpl <em>Image</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.ImageImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getImage()
   * @generated
   */
  int IMAGE = 34;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IMAGE__NAME = COMPOSANT__NAME;

  /**
   * The feature id for the '<em><b>Url</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IMAGE__URL = COMPOSANT_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Ligne</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IMAGE__LIGNE = COMPOSANT_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Colone</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IMAGE__COLONE = COMPOSANT_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Style</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IMAGE__STYLE = COMPOSANT_FEATURE_COUNT + 3;

  /**
   * The number of structural features of the '<em>Image</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int IMAGE_FEATURE_COUNT = COMPOSANT_FEATURE_COUNT + 4;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ModelImpl <em>Model</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.ModelImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getModel()
   * @generated
   */
  int MODEL = 35;

  /**
   * The number of structural features of the '<em>Model</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MODEL_FEATURE_COUNT = 0;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.TableDefinitionImpl <em>Table Definition</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.TableDefinitionImpl
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getTableDefinition()
   * @generated
   */
  int TABLE_DEFINITION = 36;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TABLE_DEFINITION__NAME = MODEL_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Champ</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TABLE_DEFINITION__CHAMP = MODEL_FEATURE_COUNT + 1;

  /**
   * The number of structural features of the '<em>Table Definition</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TABLE_DEFINITION_FEATURE_COUNT = MODEL_FEATURE_COUNT + 2;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.One <em>One</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.One
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getOne()
   * @generated
   */
  int ONE = 37;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.Nine <em>Nine</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.Nine
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getNine()
   * @generated
   */
  int NINE = 38;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.Eignth <em>Eignth</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.Eignth
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getEignth()
   * @generated
   */
  int EIGNTH = 39;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.Three <em>Three</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.Three
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getThree()
   * @generated
   */
  int THREE = 40;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.Foor <em>Foor</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.Foor
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getFoor()
   * @generated
   */
  int FOOR = 41;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.Colors <em>Colors</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getColors()
   * @generated
   */
  int COLORS = 42;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.aliIT <em>ali IT</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.aliIT
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getaliIT()
   * @generated
   */
  int ALI_IT = 43;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.alfem <em>alfem</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.alfem
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getalfem()
   * @generated
   */
  int ALFEM = 44;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.bordersty <em>bordersty</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.bordersty
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getbordersty()
   * @generated
   */
  int BORDERSTY = 45;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.textType <em>text Type</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.textType
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#gettextType()
   * @generated
   */
  int TEXT_TYPE = 46;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.Backnum <em>Backnum</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.Backnum
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getBacknum()
   * @generated
   */
  int BACKNUM = 47;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.TypeH <em>Type H</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.TypeH
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getTypeH()
   * @generated
   */
  int TYPE_H = 48;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.IconType <em>Icon Type</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.IconType
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getIconType()
   * @generated
   */
  int ICON_TYPE = 49;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.sizelist <em>sizelist</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.sizelist
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getsizelist()
   * @generated
   */
  int SIZELIST = 50;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.SocialIconType <em>Social Icon Type</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.SocialIconType
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getSocialIconType()
   * @generated
   */
  int SOCIAL_ICON_TYPE = 51;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.flexd <em>flexd</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.flexd
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getflexd()
   * @generated
   */
  int FLEXD = 52;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.mut <em>mut</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.mut
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getmut()
   * @generated
   */
  int MUT = 53;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.buttonType <em>button Type</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.buttonType
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getbuttonType()
   * @generated
   */
  int BUTTON_TYPE = 54;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.raisedType <em>raised Type</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.raisedType
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getraisedType()
   * @generated
   */
  int RAISED_TYPE = 55;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.PropType <em>Prop Type</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.PropType
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getPropType()
   * @generated
   */
  int PROP_TYPE = 56;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.IconRightType <em>Icon Right Type</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.IconRightType
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getIconRightType()
   * @generated
   */
  int ICON_RIGHT_TYPE = 57;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.JustifyContentType <em>Justify Content Type</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.JustifyContentType
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getJustifyContentType()
   * @generated
   */
  int JUSTIFY_CONTENT_TYPE = 58;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.entier <em>entier</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getentier()
   * @generated
   */
  int ENTIER = 59;

  /**
   * The meta object id for the '{@link org.xtext.UnivTlemcen.pfe.pfe.LC <em>LC</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getLC()
   * @generated
   */
  int LC = 60;


  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.Application <em>Application</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Application</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Application
   * @generated
   */
  EClass getApplication();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Application#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Application#getName()
   * @see #getApplication()
   * @generated
   */
  EAttribute getApplication_Name();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Application#getPackageName <em>Package Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Package Name</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Application#getPackageName()
   * @see #getApplication()
   * @generated
   */
  EAttribute getApplication_PackageName();

  /**
   * Returns the meta object for the reference list '{@link org.xtext.UnivTlemcen.pfe.pfe.Application#getFirstLayout <em>First Layout</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference list '<em>First Layout</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Application#getFirstLayout()
   * @see #getApplication()
   * @generated
   */
  EReference getApplication_FirstLayout();

  /**
   * Returns the meta object for the containment reference list '{@link org.xtext.UnivTlemcen.pfe.pfe.Application#getModel <em>Model</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Model</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Application#getModel()
   * @see #getApplication()
   * @generated
   */
  EReference getApplication_Model();

  /**
   * Returns the meta object for the containment reference list '{@link org.xtext.UnivTlemcen.pfe.pfe.Application#getVue <em>Vue</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Vue</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Application#getVue()
   * @see #getApplication()
   * @generated
   */
  EReference getApplication_Vue();

  /**
   * Returns the meta object for the containment reference list '{@link org.xtext.UnivTlemcen.pfe.pfe.Application#getControleur <em>Controleur</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Controleur</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Application#getControleur()
   * @see #getApplication()
   * @generated
   */
  EReference getApplication_Controleur();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.Controleur <em>Controleur</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Controleur</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Controleur
   * @generated
   */
  EClass getControleur();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.Fonctions <em>Fonctions</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Fonctions</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Fonctions
   * @generated
   */
  EClass getFonctions();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Fonctions#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Fonctions#getName()
   * @see #getFonctions()
   * @generated
   */
  EAttribute getFonctions_Name();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.stylesheet <em>stylesheet</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>stylesheet</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.stylesheet
   * @generated
   */
  EClass getstylesheet();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.fonction <em>fonction</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>fonction</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.fonction
   * @generated
   */
  EClass getfonction();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText <em>Style Text</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Style Text</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText
   * @generated
   */
  EClass getStyleText();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getColore <em>Colore</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Colore</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getColore()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_Colore();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getFontFamilyE <em>Font Family E</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Font Family E</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getFontFamilyE()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_FontFamilyE();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getFontSizes <em>Font Sizes</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Font Sizes</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getFontSizes()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_FontSizes();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getFontStyles <em>Font Styles</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Font Styles</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getFontStyles()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_FontStyles();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getFontWeighte <em>Font Weighte</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Font Weighte</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getFontWeighte()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_FontWeighte();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getLineHeighte <em>Line Heighte</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Line Heighte</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getLineHeighte()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_LineHeighte();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getTextAligne <em>Text Aligne</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Text Aligne</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getTextAligne()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_TextAligne();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBackfaceVisibilitye <em>Backface Visibilitye</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Backface Visibilitye</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBackfaceVisibilitye()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_BackfaceVisibilitye();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBackgroundColore <em>Background Colore</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Background Colore</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBackgroundColore()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_BackgroundColore();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderBottomColore <em>Border Bottom Colore</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Bottom Colore</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderBottomColore()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_BorderBottomColore();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderBottomLeftRadiuse <em>Border Bottom Left Radiuse</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Bottom Left Radiuse</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderBottomLeftRadiuse()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_BorderBottomLeftRadiuse();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderBottomRightRadiuse <em>Border Bottom Right Radiuse</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Bottom Right Radiuse</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderBottomRightRadiuse()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_BorderBottomRightRadiuse();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderBottomWidthe <em>Border Bottom Widthe</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Bottom Widthe</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderBottomWidthe()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_BorderBottomWidthe();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderColore <em>Border Colore</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Colore</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderColore()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_BorderColore();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderLeftColore <em>Border Left Colore</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Left Colore</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderLeftColore()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_BorderLeftColore();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderLeftWidthe <em>Border Left Widthe</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Left Widthe</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderLeftWidthe()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_BorderLeftWidthe();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderRadiuse <em>Border Radiuse</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Radiuse</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderRadiuse()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_BorderRadiuse();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderRightColore <em>Border Right Colore</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Right Colore</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderRightColore()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_BorderRightColore();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderRightWidth <em>Border Right Width</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Right Width</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderRightWidth()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_BorderRightWidth();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderStyles <em>Border Styles</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Styles</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderStyles()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_BorderStyles();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderTopColore <em>Border Top Colore</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Top Colore</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderTopColore()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_BorderTopColore();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderTopLeftRadiuse <em>Border Top Left Radiuse</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Top Left Radiuse</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderTopLeftRadiuse()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_BorderTopLeftRadiuse();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderTopRightRadiuse <em>Border Top Right Radiuse</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Top Right Radiuse</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderTopRightRadiuse()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_BorderTopRightRadiuse();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderTopWidthe <em>Border Top Widthe</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Top Widthe</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderTopWidthe()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_BorderTopWidthe();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderWidthe <em>Border Widthe</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Widthe</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getBorderWidthe()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_BorderWidthe();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleText#getOpacitye <em>Opacitye</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Opacitye</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleText#getOpacitye()
   * @see #getStyleText()
   * @generated
   */
  EAttribute getStyleText_Opacitye();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView <em>Style View</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Style View</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView
   * @generated
   */
  EClass getStyleView();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBackfaceVisibility2 <em>Backface Visibility2</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Backface Visibility2</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBackfaceVisibility2()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_BackfaceVisibility2();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBackgroundColor2 <em>Background Color2</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Background Color2</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBackgroundColor2()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_BackgroundColor2();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderBottomColor2 <em>Border Bottom Color2</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Bottom Color2</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderBottomColor2()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_BorderBottomColor2();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderBottomLeftRadius2 <em>Border Bottom Left Radius2</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Bottom Left Radius2</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderBottomLeftRadius2()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_BorderBottomLeftRadius2();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderBottomRightRadius2 <em>Border Bottom Right Radius2</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Bottom Right Radius2</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderBottomRightRadius2()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_BorderBottomRightRadius2();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderBottomWidth2 <em>Border Bottom Width2</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Bottom Width2</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderBottomWidth2()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_BorderBottomWidth2();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderColort <em>Border Colort</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Colort</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderColort()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_BorderColort();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderLeftColort <em>Border Left Colort</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Left Colort</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderLeftColort()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_BorderLeftColort();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderLeftWidtht <em>Border Left Widtht</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Left Widtht</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderLeftWidtht()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_BorderLeftWidtht();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderRadiust <em>Border Radiust</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Radiust</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderRadiust()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_BorderRadiust();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderRightColort <em>Border Right Colort</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Right Colort</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderRightColort()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_BorderRightColort();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderRightWidtht <em>Border Right Widtht</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Right Widtht</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderRightWidtht()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_BorderRightWidtht();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderStylet <em>Border Stylet</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Stylet</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderStylet()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_BorderStylet();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderTopColort <em>Border Top Colort</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Top Colort</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderTopColort()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_BorderTopColort();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderTopLeftRadiust <em>Border Top Left Radiust</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Top Left Radiust</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderTopLeftRadiust()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_BorderTopLeftRadiust();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderTopRightRadiust <em>Border Top Right Radiust</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Top Right Radiust</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderTopRightRadiust()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_BorderTopRightRadiust();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderTopWidtht <em>Border Top Widtht</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Top Widtht</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderTopWidtht()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_BorderTopWidtht();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderWidtht <em>Border Widtht</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Widtht</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBorderWidtht()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_BorderWidtht();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getOpacityt <em>Opacityt</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Opacityt</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getOpacityt()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_Opacityt();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getAlignItemst <em>Align Itemst</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Align Itemst</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getAlignItemst()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_AlignItemst();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getAlignSelft <em>Align Selft</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Align Selft</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getAlignSelft()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_AlignSelft();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBottomt <em>Bottomt</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Bottomt</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getBottomt()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_Bottomt();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getFlext <em>Flext</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Flext</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getFlext()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_Flext();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getFlexDirectiont <em>Flex Directiont</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Flex Directiont</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getFlexDirectiont()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_FlexDirectiont();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getFlexWrapt <em>Flex Wrapt</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Flex Wrapt</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getFlexWrapt()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_FlexWrapt();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getHeighte <em>Heighte</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Heighte</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getHeighte()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_Heighte();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getJustifyContente <em>Justify Contente</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Justify Contente</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getJustifyContente()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_JustifyContente();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getLefte <em>Lefte</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Lefte</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getLefte()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_Lefte();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMargin <em>Margin</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Margin</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMargin()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_Margin();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMarginBottome <em>Margin Bottome</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Margin Bottome</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMarginBottome()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_MarginBottome();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMarginLefte <em>Margin Lefte</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Margin Lefte</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMarginLefte()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_MarginLefte();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMarginRighte <em>Margin Righte</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Margin Righte</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMarginRighte()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_MarginRighte();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMarginTope <em>Margin Tope</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Margin Tope</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMarginTope()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_MarginTope();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMarginVerticale <em>Margin Verticale</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Margin Verticale</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getMarginVerticale()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_MarginVerticale();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingt <em>Paddingt</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Paddingt</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingt()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_Paddingt();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingBottomt <em>Padding Bottomt</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Padding Bottomt</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingBottomt()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_PaddingBottomt();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingHorizontale <em>Padding Horizontale</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Padding Horizontale</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingHorizontale()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_PaddingHorizontale();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingRighte <em>Padding Righte</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Padding Righte</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingRighte()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_PaddingRighte();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingTope <em>Padding Tope</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Padding Tope</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingTope()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_PaddingTope();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingVerticale <em>Padding Verticale</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Padding Verticale</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getPaddingVerticale()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_PaddingVerticale();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getRightt <em>Rightt</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Rightt</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getRightt()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_Rightt();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleView#getWidtht <em>Widtht</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Widtht</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleView#getWidtht()
   * @see #getStyleView()
   * @generated
   */
  EAttribute getStyleView_Widtht();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage <em>Style Image</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Style Image</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage
   * @generated
   */
  EClass getStyleImage();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBackfaceVisibility <em>Backface Visibility</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Backface Visibility</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBackfaceVisibility()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_BackfaceVisibility();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBackgroundColora <em>Background Colora</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Background Colora</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBackgroundColora()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_BackgroundColora();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderBottomLeftRadiusa <em>Border Bottom Left Radiusa</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Bottom Left Radiusa</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderBottomLeftRadiusa()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_BorderBottomLeftRadiusa();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderBottomRightRadiusa <em>Border Bottom Right Radiusa</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Bottom Right Radiusa</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderBottomRightRadiusa()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_BorderBottomRightRadiusa();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderColora <em>Border Colora</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Colora</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderColora()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_BorderColora();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderRadiusa <em>Border Radiusa</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Radiusa</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderRadiusa()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_BorderRadiusa();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderTopLeftRadiusa <em>Border Top Left Radiusa</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Top Left Radiusa</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderTopLeftRadiusa()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_BorderTopLeftRadiusa();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderTopRightRadiusa <em>Border Top Right Radiusa</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Top Right Radiusa</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderTopRightRadiusa()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_BorderTopRightRadiusa();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderWidtha <em>Border Widtha</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Widtha</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBorderWidtha()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_BorderWidtha();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getOpacitya <em>Opacitya</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Opacitya</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getOpacitya()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_Opacitya();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getOverflowa <em>Overflowa</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Overflowa</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getOverflowa()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_Overflowa();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getAlignItemst <em>Align Itemst</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Align Itemst</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getAlignItemst()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_AlignItemst();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getAlignSelft <em>Align Selft</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Align Selft</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getAlignSelft()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_AlignSelft();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBottomt <em>Bottomt</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Bottomt</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getBottomt()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_Bottomt();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getFlext <em>Flext</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Flext</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getFlext()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_Flext();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getJustifyContente <em>Justify Contente</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Justify Contente</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getJustifyContente()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_JustifyContente();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getLefte <em>Lefte</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Lefte</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getLefte()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_Lefte();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMargin <em>Margin</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Margin</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMargin()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_Margin();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMarginBottome <em>Margin Bottome</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Margin Bottome</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMarginBottome()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_MarginBottome();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMarginLefte <em>Margin Lefte</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Margin Lefte</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMarginLefte()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_MarginLefte();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMarginRighte <em>Margin Righte</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Margin Righte</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMarginRighte()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_MarginRighte();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMarginTope <em>Margin Tope</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Margin Tope</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMarginTope()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_MarginTope();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMarginVerticale <em>Margin Verticale</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Margin Verticale</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getMarginVerticale()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_MarginVerticale();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingt <em>Paddingt</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Paddingt</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingt()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_Paddingt();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingBottomt <em>Padding Bottomt</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Padding Bottomt</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingBottomt()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_PaddingBottomt();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingHorizontale <em>Padding Horizontale</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Padding Horizontale</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingHorizontale()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_PaddingHorizontale();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingRighte <em>Padding Righte</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Padding Righte</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingRighte()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_PaddingRighte();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingTope <em>Padding Tope</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Padding Tope</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingTope()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_PaddingTope();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingVerticale <em>Padding Verticale</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Padding Verticale</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getPaddingVerticale()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_PaddingVerticale();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getRightt <em>Rightt</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Rightt</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getRightt()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_Rightt();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getWidtht <em>Widtht</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Widtht</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getWidtht()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_Widtht();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getFlexDirectiont <em>Flex Directiont</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Flex Directiont</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getFlexDirectiont()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_FlexDirectiont();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getFlexWrapt <em>Flex Wrapt</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Flex Wrapt</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getFlexWrapt()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_FlexWrapt();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getHeighte <em>Heighte</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Heighte</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.StyleImage#getHeighte()
   * @see #getStyleImage()
   * @generated
   */
  EAttribute getStyleImage_Heighte();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox <em>Styleflexbox</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Styleflexbox</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox
   * @generated
   */
  EClass getStyleflexbox();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getAlignItems3 <em>Align Items3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Align Items3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getAlignItems3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_AlignItems3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getAlignSelf3 <em>Align Self3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Align Self3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getAlignSelf3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_AlignSelf3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBorderBottomWidth3 <em>Border Bottom Width3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Bottom Width3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBorderBottomWidth3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_BorderBottomWidth3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBorderLeftWidth3 <em>Border Left Width3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Left Width3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBorderLeftWidth3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_BorderLeftWidth3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBorderRightWidth3 <em>Border Right Width3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Right Width3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBorderRightWidth3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_BorderRightWidth3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBorderTopWidth3 <em>Border Top Width3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Top Width3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBorderTopWidth3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_BorderTopWidth3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBorderWidth3 <em>Border Width3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Border Width3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBorderWidth3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_BorderWidth3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBottom3 <em>Bottom3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Bottom3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getBottom3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_Bottom3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getFlex3 <em>Flex3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Flex3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getFlex3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_Flex3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getFlexDirection3 <em>Flex Direction3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Flex Direction3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getFlexDirection3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_FlexDirection3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getFlexWrap3 <em>Flex Wrap3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Flex Wrap3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getFlexWrap3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_FlexWrap3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getHeight3 <em>Height3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Height3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getHeight3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_Height3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getJustifyContent3 <em>Justify Content3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Justify Content3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getJustifyContent3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_JustifyContent3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getLeft3 <em>Left3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Left3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getLeft3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_Left3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMargin3 <em>Margin3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Margin3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMargin3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_Margin3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMarginBottom3 <em>Margin Bottom3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Margin Bottom3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMarginBottom3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_MarginBottom3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMarginLeft3 <em>Margin Left3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Margin Left3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMarginLeft3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_MarginLeft3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMarginRight3 <em>Margin Right3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Margin Right3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMarginRight3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_MarginRight3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMarginTop3 <em>Margin Top3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Margin Top3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMarginTop3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_MarginTop3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMarginVertical3 <em>Margin Vertical3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Margin Vertical3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getMarginVertical3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_MarginVertical3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getPendding3 <em>Pendding3</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Pendding3</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getPendding3()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_Pendding3();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getPanddingB <em>Pandding B</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Pandding B</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox#getPanddingB()
   * @see #getStyleflexbox()
   * @generated
   */
  EAttribute getStyleflexbox_PanddingB();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.RemplirTable <em>Remplir Table</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Remplir Table</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.RemplirTable
   * @generated
   */
  EClass getRemplirTable();

  /**
   * Returns the meta object for the reference list '{@link org.xtext.UnivTlemcen.pfe.pfe.RemplirTable#getUtiliser <em>Utiliser</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference list '<em>Utiliser</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.RemplirTable#getUtiliser()
   * @see #getRemplirTable()
   * @generated
   */
  EReference getRemplirTable_Utiliser();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.AlerteFonction <em>Alerte Fonction</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Alerte Fonction</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.AlerteFonction
   * @generated
   */
  EClass getAlerteFonction();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.AlerteFonction#getMessage <em>Message</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Message</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.AlerteFonction#getMessage()
   * @see #getAlerteFonction()
   * @generated
   */
  EAttribute getAlerteFonction_Message();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.Navigate <em>Navigate</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Navigate</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Navigate
   * @generated
   */
  EClass getNavigate();

  /**
   * Returns the meta object for the reference list '{@link org.xtext.UnivTlemcen.pfe.pfe.Navigate#getRef <em>Ref</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference list '<em>Ref</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Navigate#getRef()
   * @see #getNavigate()
   * @generated
   */
  EReference getNavigate_Ref();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.Vue <em>Vue</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Vue</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Vue
   * @generated
   */
  EClass getVue();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.Elements <em>Elements</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Elements</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Elements
   * @generated
   */
  EClass getElements();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.composant <em>composant</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>composant</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.composant
   * @generated
   */
  EClass getcomposant();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.composant#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.composant#getName()
   * @see #getcomposant()
   * @generated
   */
  EAttribute getcomposant_Name();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.Forms <em>Forms</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Forms</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Forms
   * @generated
   */
  EClass getForms();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Forms#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Forms#getName()
   * @see #getForms()
   * @generated
   */
  EAttribute getForms_Name();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Forms#getLigne <em>Ligne</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Ligne</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Forms#getLigne()
   * @see #getForms()
   * @generated
   */
  EAttribute getForms_Ligne();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Forms#getColonne <em>Colonne</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Colonne</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Forms#getColonne()
   * @see #getForms()
   * @generated
   */
  EAttribute getForms_Colonne();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.lists <em>lists</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>lists</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.lists
   * @generated
   */
  EClass getlists();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.Icons <em>Icons</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Icons</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Icons
   * @generated
   */
  EClass getIcons();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Icons#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Icons#getName()
   * @see #getIcons()
   * @generated
   */
  EAttribute getIcons_Name();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Icons#getLigne <em>Ligne</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Ligne</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Icons#getLigne()
   * @see #getIcons()
   * @generated
   */
  EAttribute getIcons_Ligne();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Icons#getColonne <em>Colonne</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Colonne</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Icons#getColonne()
   * @see #getIcons()
   * @generated
   */
  EAttribute getIcons_Colonne();

  /**
   * Returns the meta object for the reference '{@link org.xtext.UnivTlemcen.pfe.pfe.Icons#getStyle <em>Style</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Style</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Icons#getStyle()
   * @see #getIcons()
   * @generated
   */
  EReference getIcons_Style();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.listView <em>list View</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>list View</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.listView
   * @generated
   */
  EClass getlistView();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.listView#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.listView#getName()
   * @see #getlistView()
   * @generated
   */
  EAttribute getlistView_Name();

  /**
   * Returns the meta object for the reference list '{@link org.xtext.UnivTlemcen.pfe.pfe.listView#getUtiliser <em>Utiliser</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference list '<em>Utiliser</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.listView#getUtiliser()
   * @see #getlistView()
   * @generated
   */
  EReference getlistView_Utiliser();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.listView#getLigne <em>Ligne</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Ligne</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.listView#getLigne()
   * @see #getlistView()
   * @generated
   */
  EAttribute getlistView_Ligne();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.listView#getColonne <em>Colonne</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Colonne</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.listView#getColonne()
   * @see #getlistView()
   * @generated
   */
  EAttribute getlistView_Colonne();

  /**
   * Returns the meta object for the reference '{@link org.xtext.UnivTlemcen.pfe.pfe.listView#getStyle <em>Style</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Style</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.listView#getStyle()
   * @see #getlistView()
   * @generated
   */
  EReference getlistView_Style();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.RadioButton <em>Radio Button</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Radio Button</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.RadioButton
   * @generated
   */
  EClass getRadioButton();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.RadioButton#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.RadioButton#getName()
   * @see #getRadioButton()
   * @generated
   */
  EAttribute getRadioButton_Name();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.RadioButton#getLigne <em>Ligne</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Ligne</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.RadioButton#getLigne()
   * @see #getRadioButton()
   * @generated
   */
  EAttribute getRadioButton_Ligne();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.RadioButton#getColonne <em>Colonne</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Colonne</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.RadioButton#getColonne()
   * @see #getRadioButton()
   * @generated
   */
  EAttribute getRadioButton_Colonne();

  /**
   * Returns the meta object for the reference '{@link org.xtext.UnivTlemcen.pfe.pfe.RadioButton#getStyle <em>Style</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Style</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.RadioButton#getStyle()
   * @see #getRadioButton()
   * @generated
   */
  EReference getRadioButton_Style();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.CheckBox <em>Check Box</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Check Box</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.CheckBox
   * @generated
   */
  EClass getCheckBox();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.CheckBox#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.CheckBox#getName()
   * @see #getCheckBox()
   * @generated
   */
  EAttribute getCheckBox_Name();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.CheckBox#getLigne <em>Ligne</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Ligne</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.CheckBox#getLigne()
   * @see #getCheckBox()
   * @generated
   */
  EAttribute getCheckBox_Ligne();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.CheckBox#getColonne <em>Colonne</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Colonne</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.CheckBox#getColonne()
   * @see #getCheckBox()
   * @generated
   */
  EAttribute getCheckBox_Colonne();

  /**
   * Returns the meta object for the reference '{@link org.xtext.UnivTlemcen.pfe.pfe.CheckBox#getStyle <em>Style</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Style</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.CheckBox#getStyle()
   * @see #getCheckBox()
   * @generated
   */
  EReference getCheckBox_Style();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.Text <em>Text</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Text</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Text
   * @generated
   */
  EClass getText();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Text#getContenu <em>Contenu</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Contenu</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Text#getContenu()
   * @see #getText()
   * @generated
   */
  EAttribute getText_Contenu();

  /**
   * Returns the meta object for the reference '{@link org.xtext.UnivTlemcen.pfe.pfe.Text#getStyle <em>Style</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Style</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Text#getStyle()
   * @see #getText()
   * @generated
   */
  EReference getText_Style();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.Input <em>Input</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Input</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Input
   * @generated
   */
  EClass getInput();

  /**
   * Returns the meta object for the reference '{@link org.xtext.UnivTlemcen.pfe.pfe.Input#getStyle <em>Style</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Style</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Input#getStyle()
   * @see #getInput()
   * @generated
   */
  EReference getInput_Style();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.Icone <em>Icone</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Icone</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Icone
   * @generated
   */
  EClass getIcone();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Icone#getType <em>Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Type</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Icone#getType()
   * @see #getIcone()
   * @generated
   */
  EAttribute getIcone_Type();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.SocialIcon <em>Social Icon</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Social Icon</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.SocialIcon
   * @generated
   */
  EClass getSocialIcon();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.SocialIcon#getType <em>Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Type</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.SocialIcon#getType()
   * @see #getSocialIcon()
   * @generated
   */
  EAttribute getSocialIcon_Type();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.SocialIcon#getButton <em>Button</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Button</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.SocialIcon#getButton()
   * @see #getSocialIcon()
   * @generated
   */
  EAttribute getSocialIcon_Button();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.SocialIcon#getRaised <em>Raised</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Raised</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.SocialIcon#getRaised()
   * @see #getSocialIcon()
   * @generated
   */
  EAttribute getSocialIcon_Raised();

  /**
   * Returns the meta object for the reference '{@link org.xtext.UnivTlemcen.pfe.pfe.SocialIcon#getOnclique <em>Onclique</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Onclique</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.SocialIcon#getOnclique()
   * @see #getSocialIcon()
   * @generated
   */
  EReference getSocialIcon_Onclique();

  /**
   * Returns the meta object for the reference '{@link org.xtext.UnivTlemcen.pfe.pfe.SocialIcon#getOnlongclique <em>Onlongclique</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Onlongclique</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.SocialIcon#getOnlongclique()
   * @see #getSocialIcon()
   * @generated
   */
  EReference getSocialIcon_Onlongclique();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.Tab <em>Tab</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Tab</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Tab
   * @generated
   */
  EClass getTab();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Tab#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Tab#getName()
   * @see #getTab()
   * @generated
   */
  EAttribute getTab_Name();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Tab#getTitle <em>Title</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Title</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Tab#getTitle()
   * @see #getTab()
   * @generated
   */
  EAttribute getTab_Title();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Tab#getText <em>Text</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Text</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Tab#getText()
   * @see #getTab()
   * @generated
   */
  EAttribute getTab_Text();

  /**
   * Returns the meta object for the containment reference '{@link org.xtext.UnivTlemcen.pfe.pfe.Tab#getIcon <em>Icon</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Icon</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Tab#getIcon()
   * @see #getTab()
   * @generated
   */
  EReference getTab_Icon();

  /**
   * Returns the meta object for the containment reference list '{@link org.xtext.UnivTlemcen.pfe.pfe.Tab#getElements <em>Elements</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Elements</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Tab#getElements()
   * @see #getTab()
   * @generated
   */
  EReference getTab_Elements();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Tab#getLigne <em>Ligne</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Ligne</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Tab#getLigne()
   * @see #getTab()
   * @generated
   */
  EAttribute getTab_Ligne();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Tab#getColonne <em>Colonne</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Colonne</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Tab#getColonne()
   * @see #getTab()
   * @generated
   */
  EAttribute getTab_Colonne();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.Heading <em>Heading</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Heading</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Heading
   * @generated
   */
  EClass getHeading();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Heading#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Heading#getName()
   * @see #getHeading()
   * @generated
   */
  EAttribute getHeading_Name();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Heading#getType <em>Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Type</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Heading#getType()
   * @see #getHeading()
   * @generated
   */
  EAttribute getHeading_Type();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Heading#getLigne <em>Ligne</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Ligne</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Heading#getLigne()
   * @see #getHeading()
   * @generated
   */
  EAttribute getHeading_Ligne();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Heading#getColonne <em>Colonne</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Colonne</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Heading#getColonne()
   * @see #getHeading()
   * @generated
   */
  EAttribute getHeading_Colonne();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.ContainerStyle <em>Container Style</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Container Style</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.ContainerStyle
   * @generated
   */
  EClass getContainerStyle();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.ContainerStyle#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.ContainerStyle#getName()
   * @see #getContainerStyle()
   * @generated
   */
  EAttribute getContainerStyle_Name();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.ContainerFonctions <em>Container Fonctions</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Container Fonctions</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.ContainerFonctions
   * @generated
   */
  EClass getContainerFonctions();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.ContainerFonctions#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.ContainerFonctions#getName()
   * @see #getContainerFonctions()
   * @generated
   */
  EAttribute getContainerFonctions_Name();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.Layout <em>Layout</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Layout</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Layout
   * @generated
   */
  EClass getLayout();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Layout#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Layout#getName()
   * @see #getLayout()
   * @generated
   */
  EAttribute getLayout_Name();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Layout#getTitre <em>Titre</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Titre</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Layout#getTitre()
   * @see #getLayout()
   * @generated
   */
  EAttribute getLayout_Titre();

  /**
   * Returns the meta object for the reference list '{@link org.xtext.UnivTlemcen.pfe.pfe.Layout#getContient <em>Contient</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference list '<em>Contient</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Layout#getContient()
   * @see #getLayout()
   * @generated
   */
  EReference getLayout_Contient();

  /**
   * Returns the meta object for the reference '{@link org.xtext.UnivTlemcen.pfe.pfe.Layout#getStyle <em>Style</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Style</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Layout#getStyle()
   * @see #getLayout()
   * @generated
   */
  EReference getLayout_Style();

  /**
   * Returns the meta object for the reference '{@link org.xtext.UnivTlemcen.pfe.pfe.Layout#getStyleB <em>Style B</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Style B</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Layout#getStyleB()
   * @see #getLayout()
   * @generated
   */
  EReference getLayout_StyleB();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton <em>Bouton</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Bouton</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Bouton
   * @generated
   */
  EClass getBouton();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Bouton#getName()
   * @see #getBouton()
   * @generated
   */
  EAttribute getBouton_Name();

  /**
   * Returns the meta object for the reference '{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getIcon <em>Icon</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Icon</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Bouton#getIcon()
   * @see #getBouton()
   * @generated
   */
  EReference getBouton_Icon();

  /**
   * Returns the meta object for the reference list '{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getOnclique <em>Onclique</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference list '<em>Onclique</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Bouton#getOnclique()
   * @see #getBouton()
   * @generated
   */
  EReference getBouton_Onclique();

  /**
   * Returns the meta object for the reference list '{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getOnlongclique <em>Onlongclique</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference list '<em>Onlongclique</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Bouton#getOnlongclique()
   * @see #getBouton()
   * @generated
   */
  EReference getBouton_Onlongclique();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getProp <em>Prop</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Prop</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Bouton#getProp()
   * @see #getBouton()
   * @generated
   */
  EAttribute getBouton_Prop();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getIconRight <em>Icon Right</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Icon Right</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Bouton#getIconRight()
   * @see #getBouton()
   * @generated
   */
  EAttribute getBouton_IconRight();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getLigne <em>Ligne</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Ligne</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Bouton#getLigne()
   * @see #getBouton()
   * @generated
   */
  EAttribute getBouton_Ligne();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getColonne <em>Colonne</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Colonne</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Bouton#getColonne()
   * @see #getBouton()
   * @generated
   */
  EAttribute getBouton_Colonne();

  /**
   * Returns the meta object for the reference '{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getStyle <em>Style</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Style</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Bouton#getStyle()
   * @see #getBouton()
   * @generated
   */
  EReference getBouton_Style();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.Video <em>Video</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Video</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Video
   * @generated
   */
  EClass getVideo();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Video#getUrlV <em>Url V</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Url V</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Video#getUrlV()
   * @see #getVideo()
   * @generated
   */
  EAttribute getVideo_UrlV();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Video#getMutte <em>Mutte</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Mutte</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Video#getMutte()
   * @see #getVideo()
   * @generated
   */
  EAttribute getVideo_Mutte();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Video#getWidtht <em>Widtht</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Widtht</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Video#getWidtht()
   * @see #getVideo()
   * @generated
   */
  EAttribute getVideo_Widtht();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Video#getHeightr <em>Heightr</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Heightr</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Video#getHeightr()
   * @see #getVideo()
   * @generated
   */
  EAttribute getVideo_Heightr();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Video#getLigneAudio <em>Ligne Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Ligne Audio</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Video#getLigneAudio()
   * @see #getVideo()
   * @generated
   */
  EAttribute getVideo_LigneAudio();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Video#getColoneAudio <em>Colone Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Colone Audio</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Video#getColoneAudio()
   * @see #getVideo()
   * @generated
   */
  EAttribute getVideo_ColoneAudio();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.Audio <em>Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Audio</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Audio
   * @generated
   */
  EClass getAudio();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Audio#getUrlT <em>Url T</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Url T</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Audio#getUrlT()
   * @see #getAudio()
   * @generated
   */
  EAttribute getAudio_UrlT();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Audio#getTextbout <em>Textbout</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Textbout</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Audio#getTextbout()
   * @see #getAudio()
   * @generated
   */
  EAttribute getAudio_Textbout();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Audio#getLigneAudio <em>Ligne Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Ligne Audio</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Audio#getLigneAudio()
   * @see #getAudio()
   * @generated
   */
  EAttribute getAudio_LigneAudio();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Audio#getColoneAudio <em>Colone Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Colone Audio</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Audio#getColoneAudio()
   * @see #getAudio()
   * @generated
   */
  EAttribute getAudio_ColoneAudio();

  /**
   * Returns the meta object for the reference '{@link org.xtext.UnivTlemcen.pfe.pfe.Audio#getStyleAudio <em>Style Audio</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Style Audio</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Audio#getStyleAudio()
   * @see #getAudio()
   * @generated
   */
  EReference getAudio_StyleAudio();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.MapView <em>Map View</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Map View</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.MapView
   * @generated
   */
  EClass getMapView();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.MapView#getLatitude <em>Latitude</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Latitude</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.MapView#getLatitude()
   * @see #getMapView()
   * @generated
   */
  EAttribute getMapView_Latitude();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.MapView#getLongitude <em>Longitude</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Longitude</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.MapView#getLongitude()
   * @see #getMapView()
   * @generated
   */
  EAttribute getMapView_Longitude();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.MapView#getLatitudeDelta <em>Latitude Delta</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Latitude Delta</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.MapView#getLatitudeDelta()
   * @see #getMapView()
   * @generated
   */
  EAttribute getMapView_LatitudeDelta();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.MapView#getLongitudeDelta <em>Longitude Delta</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Longitude Delta</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.MapView#getLongitudeDelta()
   * @see #getMapView()
   * @generated
   */
  EAttribute getMapView_LongitudeDelta();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.MapView#getLigne <em>Ligne</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Ligne</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.MapView#getLigne()
   * @see #getMapView()
   * @generated
   */
  EAttribute getMapView_Ligne();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.MapView#getColone <em>Colone</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Colone</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.MapView#getColone()
   * @see #getMapView()
   * @generated
   */
  EAttribute getMapView_Colone();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.Image <em>Image</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Image</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Image
   * @generated
   */
  EClass getImage();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Image#getUrl <em>Url</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Url</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Image#getUrl()
   * @see #getImage()
   * @generated
   */
  EAttribute getImage_Url();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Image#getLigne <em>Ligne</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Ligne</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Image#getLigne()
   * @see #getImage()
   * @generated
   */
  EAttribute getImage_Ligne();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.Image#getColone <em>Colone</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Colone</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Image#getColone()
   * @see #getImage()
   * @generated
   */
  EAttribute getImage_Colone();

  /**
   * Returns the meta object for the reference '{@link org.xtext.UnivTlemcen.pfe.pfe.Image#getStyle <em>Style</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Style</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Image#getStyle()
   * @see #getImage()
   * @generated
   */
  EReference getImage_Style();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.Model <em>Model</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Model</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Model
   * @generated
   */
  EClass getModel();

  /**
   * Returns the meta object for class '{@link org.xtext.UnivTlemcen.pfe.pfe.TableDefinition <em>Table Definition</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Table Definition</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.TableDefinition
   * @generated
   */
  EClass getTableDefinition();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.UnivTlemcen.pfe.pfe.TableDefinition#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.TableDefinition#getName()
   * @see #getTableDefinition()
   * @generated
   */
  EAttribute getTableDefinition_Name();

  /**
   * Returns the meta object for the reference list '{@link org.xtext.UnivTlemcen.pfe.pfe.TableDefinition#getChamp <em>Champ</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference list '<em>Champ</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.TableDefinition#getChamp()
   * @see #getTableDefinition()
   * @generated
   */
  EReference getTableDefinition_Champ();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.One <em>One</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>One</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.One
   * @generated
   */
  EEnum getOne();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.Nine <em>Nine</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Nine</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Nine
   * @generated
   */
  EEnum getNine();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.Eignth <em>Eignth</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Eignth</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Eignth
   * @generated
   */
  EEnum getEignth();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.Three <em>Three</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Three</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Three
   * @generated
   */
  EEnum getThree();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.Foor <em>Foor</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Foor</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Foor
   * @generated
   */
  EEnum getFoor();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.Colors <em>Colors</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Colors</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
   * @generated
   */
  EEnum getColors();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.aliIT <em>ali IT</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>ali IT</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.aliIT
   * @generated
   */
  EEnum getaliIT();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.alfem <em>alfem</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>alfem</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.alfem
   * @generated
   */
  EEnum getalfem();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.bordersty <em>bordersty</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>bordersty</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.bordersty
   * @generated
   */
  EEnum getbordersty();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.textType <em>text Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>text Type</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.textType
   * @generated
   */
  EEnum gettextType();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.Backnum <em>Backnum</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Backnum</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.Backnum
   * @generated
   */
  EEnum getBacknum();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.TypeH <em>Type H</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Type H</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.TypeH
   * @generated
   */
  EEnum getTypeH();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.IconType <em>Icon Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Icon Type</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.IconType
   * @generated
   */
  EEnum getIconType();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.sizelist <em>sizelist</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>sizelist</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.sizelist
   * @generated
   */
  EEnum getsizelist();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.SocialIconType <em>Social Icon Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Social Icon Type</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.SocialIconType
   * @generated
   */
  EEnum getSocialIconType();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.flexd <em>flexd</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>flexd</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.flexd
   * @generated
   */
  EEnum getflexd();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.mut <em>mut</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>mut</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.mut
   * @generated
   */
  EEnum getmut();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.buttonType <em>button Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>button Type</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.buttonType
   * @generated
   */
  EEnum getbuttonType();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.raisedType <em>raised Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>raised Type</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.raisedType
   * @generated
   */
  EEnum getraisedType();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.PropType <em>Prop Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Prop Type</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.PropType
   * @generated
   */
  EEnum getPropType();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.IconRightType <em>Icon Right Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Icon Right Type</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.IconRightType
   * @generated
   */
  EEnum getIconRightType();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.JustifyContentType <em>Justify Content Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Justify Content Type</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.JustifyContentType
   * @generated
   */
  EEnum getJustifyContentType();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.entier <em>entier</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>entier</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.entier
   * @generated
   */
  EEnum getentier();

  /**
   * Returns the meta object for enum '{@link org.xtext.UnivTlemcen.pfe.pfe.LC <em>LC</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>LC</em>'.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @generated
   */
  EEnum getLC();

  /**
   * Returns the factory that creates the instances of the model.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the factory that creates the instances of the model.
   * @generated
   */
  PfeFactory getPfeFactory();

  /**
   * <!-- begin-user-doc -->
   * Defines literals for the meta objects that represent
   * <ul>
   *   <li>each class,</li>
   *   <li>each feature of each class,</li>
   *   <li>each enum,</li>
   *   <li>and each data type</li>
   * </ul>
   * <!-- end-user-doc -->
   * @generated
   */
  interface Literals
  {
    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ApplicationImpl <em>Application</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.ApplicationImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getApplication()
     * @generated
     */
    EClass APPLICATION = eINSTANCE.getApplication();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute APPLICATION__NAME = eINSTANCE.getApplication_Name();

    /**
     * The meta object literal for the '<em><b>Package Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute APPLICATION__PACKAGE_NAME = eINSTANCE.getApplication_PackageName();

    /**
     * The meta object literal for the '<em><b>First Layout</b></em>' reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference APPLICATION__FIRST_LAYOUT = eINSTANCE.getApplication_FirstLayout();

    /**
     * The meta object literal for the '<em><b>Model</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference APPLICATION__MODEL = eINSTANCE.getApplication_Model();

    /**
     * The meta object literal for the '<em><b>Vue</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference APPLICATION__VUE = eINSTANCE.getApplication_Vue();

    /**
     * The meta object literal for the '<em><b>Controleur</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference APPLICATION__CONTROLEUR = eINSTANCE.getApplication_Controleur();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ControleurImpl <em>Controleur</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.ControleurImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getControleur()
     * @generated
     */
    EClass CONTROLEUR = eINSTANCE.getControleur();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.FonctionsImpl <em>Fonctions</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.FonctionsImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getFonctions()
     * @generated
     */
    EClass FONCTIONS = eINSTANCE.getFonctions();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute FONCTIONS__NAME = eINSTANCE.getFonctions_Name();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.stylesheetImpl <em>stylesheet</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.stylesheetImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getstylesheet()
     * @generated
     */
    EClass STYLESHEET = eINSTANCE.getstylesheet();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.fonctionImpl <em>fonction</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.fonctionImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getfonction()
     * @generated
     */
    EClass FONCTION = eINSTANCE.getfonction();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl <em>Style Text</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.StyleTextImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getStyleText()
     * @generated
     */
    EClass STYLE_TEXT = eINSTANCE.getStyleText();

    /**
     * The meta object literal for the '<em><b>Colore</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__COLORE = eINSTANCE.getStyleText_Colore();

    /**
     * The meta object literal for the '<em><b>Font Family E</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__FONT_FAMILY_E = eINSTANCE.getStyleText_FontFamilyE();

    /**
     * The meta object literal for the '<em><b>Font Sizes</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__FONT_SIZES = eINSTANCE.getStyleText_FontSizes();

    /**
     * The meta object literal for the '<em><b>Font Styles</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__FONT_STYLES = eINSTANCE.getStyleText_FontStyles();

    /**
     * The meta object literal for the '<em><b>Font Weighte</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__FONT_WEIGHTE = eINSTANCE.getStyleText_FontWeighte();

    /**
     * The meta object literal for the '<em><b>Line Heighte</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__LINE_HEIGHTE = eINSTANCE.getStyleText_LineHeighte();

    /**
     * The meta object literal for the '<em><b>Text Aligne</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__TEXT_ALIGNE = eINSTANCE.getStyleText_TextAligne();

    /**
     * The meta object literal for the '<em><b>Backface Visibilitye</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__BACKFACE_VISIBILITYE = eINSTANCE.getStyleText_BackfaceVisibilitye();

    /**
     * The meta object literal for the '<em><b>Background Colore</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__BACKGROUND_COLORE = eINSTANCE.getStyleText_BackgroundColore();

    /**
     * The meta object literal for the '<em><b>Border Bottom Colore</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__BORDER_BOTTOM_COLORE = eINSTANCE.getStyleText_BorderBottomColore();

    /**
     * The meta object literal for the '<em><b>Border Bottom Left Radiuse</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__BORDER_BOTTOM_LEFT_RADIUSE = eINSTANCE.getStyleText_BorderBottomLeftRadiuse();

    /**
     * The meta object literal for the '<em><b>Border Bottom Right Radiuse</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__BORDER_BOTTOM_RIGHT_RADIUSE = eINSTANCE.getStyleText_BorderBottomRightRadiuse();

    /**
     * The meta object literal for the '<em><b>Border Bottom Widthe</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__BORDER_BOTTOM_WIDTHE = eINSTANCE.getStyleText_BorderBottomWidthe();

    /**
     * The meta object literal for the '<em><b>Border Colore</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__BORDER_COLORE = eINSTANCE.getStyleText_BorderColore();

    /**
     * The meta object literal for the '<em><b>Border Left Colore</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__BORDER_LEFT_COLORE = eINSTANCE.getStyleText_BorderLeftColore();

    /**
     * The meta object literal for the '<em><b>Border Left Widthe</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__BORDER_LEFT_WIDTHE = eINSTANCE.getStyleText_BorderLeftWidthe();

    /**
     * The meta object literal for the '<em><b>Border Radiuse</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__BORDER_RADIUSE = eINSTANCE.getStyleText_BorderRadiuse();

    /**
     * The meta object literal for the '<em><b>Border Right Colore</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__BORDER_RIGHT_COLORE = eINSTANCE.getStyleText_BorderRightColore();

    /**
     * The meta object literal for the '<em><b>Border Right Width</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__BORDER_RIGHT_WIDTH = eINSTANCE.getStyleText_BorderRightWidth();

    /**
     * The meta object literal for the '<em><b>Border Styles</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__BORDER_STYLES = eINSTANCE.getStyleText_BorderStyles();

    /**
     * The meta object literal for the '<em><b>Border Top Colore</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__BORDER_TOP_COLORE = eINSTANCE.getStyleText_BorderTopColore();

    /**
     * The meta object literal for the '<em><b>Border Top Left Radiuse</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__BORDER_TOP_LEFT_RADIUSE = eINSTANCE.getStyleText_BorderTopLeftRadiuse();

    /**
     * The meta object literal for the '<em><b>Border Top Right Radiuse</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__BORDER_TOP_RIGHT_RADIUSE = eINSTANCE.getStyleText_BorderTopRightRadiuse();

    /**
     * The meta object literal for the '<em><b>Border Top Widthe</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__BORDER_TOP_WIDTHE = eINSTANCE.getStyleText_BorderTopWidthe();

    /**
     * The meta object literal for the '<em><b>Border Widthe</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__BORDER_WIDTHE = eINSTANCE.getStyleText_BorderWidthe();

    /**
     * The meta object literal for the '<em><b>Opacitye</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_TEXT__OPACITYE = eINSTANCE.getStyleText_Opacitye();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl <em>Style View</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.StyleViewImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getStyleView()
     * @generated
     */
    EClass STYLE_VIEW = eINSTANCE.getStyleView();

    /**
     * The meta object literal for the '<em><b>Backface Visibility2</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__BACKFACE_VISIBILITY2 = eINSTANCE.getStyleView_BackfaceVisibility2();

    /**
     * The meta object literal for the '<em><b>Background Color2</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__BACKGROUND_COLOR2 = eINSTANCE.getStyleView_BackgroundColor2();

    /**
     * The meta object literal for the '<em><b>Border Bottom Color2</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__BORDER_BOTTOM_COLOR2 = eINSTANCE.getStyleView_BorderBottomColor2();

    /**
     * The meta object literal for the '<em><b>Border Bottom Left Radius2</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__BORDER_BOTTOM_LEFT_RADIUS2 = eINSTANCE.getStyleView_BorderBottomLeftRadius2();

    /**
     * The meta object literal for the '<em><b>Border Bottom Right Radius2</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__BORDER_BOTTOM_RIGHT_RADIUS2 = eINSTANCE.getStyleView_BorderBottomRightRadius2();

    /**
     * The meta object literal for the '<em><b>Border Bottom Width2</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__BORDER_BOTTOM_WIDTH2 = eINSTANCE.getStyleView_BorderBottomWidth2();

    /**
     * The meta object literal for the '<em><b>Border Colort</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__BORDER_COLORT = eINSTANCE.getStyleView_BorderColort();

    /**
     * The meta object literal for the '<em><b>Border Left Colort</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__BORDER_LEFT_COLORT = eINSTANCE.getStyleView_BorderLeftColort();

    /**
     * The meta object literal for the '<em><b>Border Left Widtht</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__BORDER_LEFT_WIDTHT = eINSTANCE.getStyleView_BorderLeftWidtht();

    /**
     * The meta object literal for the '<em><b>Border Radiust</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__BORDER_RADIUST = eINSTANCE.getStyleView_BorderRadiust();

    /**
     * The meta object literal for the '<em><b>Border Right Colort</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__BORDER_RIGHT_COLORT = eINSTANCE.getStyleView_BorderRightColort();

    /**
     * The meta object literal for the '<em><b>Border Right Widtht</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__BORDER_RIGHT_WIDTHT = eINSTANCE.getStyleView_BorderRightWidtht();

    /**
     * The meta object literal for the '<em><b>Border Stylet</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__BORDER_STYLET = eINSTANCE.getStyleView_BorderStylet();

    /**
     * The meta object literal for the '<em><b>Border Top Colort</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__BORDER_TOP_COLORT = eINSTANCE.getStyleView_BorderTopColort();

    /**
     * The meta object literal for the '<em><b>Border Top Left Radiust</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__BORDER_TOP_LEFT_RADIUST = eINSTANCE.getStyleView_BorderTopLeftRadiust();

    /**
     * The meta object literal for the '<em><b>Border Top Right Radiust</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__BORDER_TOP_RIGHT_RADIUST = eINSTANCE.getStyleView_BorderTopRightRadiust();

    /**
     * The meta object literal for the '<em><b>Border Top Widtht</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__BORDER_TOP_WIDTHT = eINSTANCE.getStyleView_BorderTopWidtht();

    /**
     * The meta object literal for the '<em><b>Border Widtht</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__BORDER_WIDTHT = eINSTANCE.getStyleView_BorderWidtht();

    /**
     * The meta object literal for the '<em><b>Opacityt</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__OPACITYT = eINSTANCE.getStyleView_Opacityt();

    /**
     * The meta object literal for the '<em><b>Align Itemst</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__ALIGN_ITEMST = eINSTANCE.getStyleView_AlignItemst();

    /**
     * The meta object literal for the '<em><b>Align Selft</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__ALIGN_SELFT = eINSTANCE.getStyleView_AlignSelft();

    /**
     * The meta object literal for the '<em><b>Bottomt</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__BOTTOMT = eINSTANCE.getStyleView_Bottomt();

    /**
     * The meta object literal for the '<em><b>Flext</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__FLEXT = eINSTANCE.getStyleView_Flext();

    /**
     * The meta object literal for the '<em><b>Flex Directiont</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__FLEX_DIRECTIONT = eINSTANCE.getStyleView_FlexDirectiont();

    /**
     * The meta object literal for the '<em><b>Flex Wrapt</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__FLEX_WRAPT = eINSTANCE.getStyleView_FlexWrapt();

    /**
     * The meta object literal for the '<em><b>Heighte</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__HEIGHTE = eINSTANCE.getStyleView_Heighte();

    /**
     * The meta object literal for the '<em><b>Justify Contente</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__JUSTIFY_CONTENTE = eINSTANCE.getStyleView_JustifyContente();

    /**
     * The meta object literal for the '<em><b>Lefte</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__LEFTE = eINSTANCE.getStyleView_Lefte();

    /**
     * The meta object literal for the '<em><b>Margin</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__MARGIN = eINSTANCE.getStyleView_Margin();

    /**
     * The meta object literal for the '<em><b>Margin Bottome</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__MARGIN_BOTTOME = eINSTANCE.getStyleView_MarginBottome();

    /**
     * The meta object literal for the '<em><b>Margin Lefte</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__MARGIN_LEFTE = eINSTANCE.getStyleView_MarginLefte();

    /**
     * The meta object literal for the '<em><b>Margin Righte</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__MARGIN_RIGHTE = eINSTANCE.getStyleView_MarginRighte();

    /**
     * The meta object literal for the '<em><b>Margin Tope</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__MARGIN_TOPE = eINSTANCE.getStyleView_MarginTope();

    /**
     * The meta object literal for the '<em><b>Margin Verticale</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__MARGIN_VERTICALE = eINSTANCE.getStyleView_MarginVerticale();

    /**
     * The meta object literal for the '<em><b>Paddingt</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__PADDINGT = eINSTANCE.getStyleView_Paddingt();

    /**
     * The meta object literal for the '<em><b>Padding Bottomt</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__PADDING_BOTTOMT = eINSTANCE.getStyleView_PaddingBottomt();

    /**
     * The meta object literal for the '<em><b>Padding Horizontale</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__PADDING_HORIZONTALE = eINSTANCE.getStyleView_PaddingHorizontale();

    /**
     * The meta object literal for the '<em><b>Padding Righte</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__PADDING_RIGHTE = eINSTANCE.getStyleView_PaddingRighte();

    /**
     * The meta object literal for the '<em><b>Padding Tope</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__PADDING_TOPE = eINSTANCE.getStyleView_PaddingTope();

    /**
     * The meta object literal for the '<em><b>Padding Verticale</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__PADDING_VERTICALE = eINSTANCE.getStyleView_PaddingVerticale();

    /**
     * The meta object literal for the '<em><b>Rightt</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__RIGHTT = eINSTANCE.getStyleView_Rightt();

    /**
     * The meta object literal for the '<em><b>Widtht</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_VIEW__WIDTHT = eINSTANCE.getStyleView_Widtht();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl <em>Style Image</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.StyleImageImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getStyleImage()
     * @generated
     */
    EClass STYLE_IMAGE = eINSTANCE.getStyleImage();

    /**
     * The meta object literal for the '<em><b>Backface Visibility</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__BACKFACE_VISIBILITY = eINSTANCE.getStyleImage_BackfaceVisibility();

    /**
     * The meta object literal for the '<em><b>Background Colora</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__BACKGROUND_COLORA = eINSTANCE.getStyleImage_BackgroundColora();

    /**
     * The meta object literal for the '<em><b>Border Bottom Left Radiusa</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__BORDER_BOTTOM_LEFT_RADIUSA = eINSTANCE.getStyleImage_BorderBottomLeftRadiusa();

    /**
     * The meta object literal for the '<em><b>Border Bottom Right Radiusa</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__BORDER_BOTTOM_RIGHT_RADIUSA = eINSTANCE.getStyleImage_BorderBottomRightRadiusa();

    /**
     * The meta object literal for the '<em><b>Border Colora</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__BORDER_COLORA = eINSTANCE.getStyleImage_BorderColora();

    /**
     * The meta object literal for the '<em><b>Border Radiusa</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__BORDER_RADIUSA = eINSTANCE.getStyleImage_BorderRadiusa();

    /**
     * The meta object literal for the '<em><b>Border Top Left Radiusa</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__BORDER_TOP_LEFT_RADIUSA = eINSTANCE.getStyleImage_BorderTopLeftRadiusa();

    /**
     * The meta object literal for the '<em><b>Border Top Right Radiusa</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__BORDER_TOP_RIGHT_RADIUSA = eINSTANCE.getStyleImage_BorderTopRightRadiusa();

    /**
     * The meta object literal for the '<em><b>Border Widtha</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__BORDER_WIDTHA = eINSTANCE.getStyleImage_BorderWidtha();

    /**
     * The meta object literal for the '<em><b>Opacitya</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__OPACITYA = eINSTANCE.getStyleImage_Opacitya();

    /**
     * The meta object literal for the '<em><b>Overflowa</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__OVERFLOWA = eINSTANCE.getStyleImage_Overflowa();

    /**
     * The meta object literal for the '<em><b>Align Itemst</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__ALIGN_ITEMST = eINSTANCE.getStyleImage_AlignItemst();

    /**
     * The meta object literal for the '<em><b>Align Selft</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__ALIGN_SELFT = eINSTANCE.getStyleImage_AlignSelft();

    /**
     * The meta object literal for the '<em><b>Bottomt</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__BOTTOMT = eINSTANCE.getStyleImage_Bottomt();

    /**
     * The meta object literal for the '<em><b>Flext</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__FLEXT = eINSTANCE.getStyleImage_Flext();

    /**
     * The meta object literal for the '<em><b>Justify Contente</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__JUSTIFY_CONTENTE = eINSTANCE.getStyleImage_JustifyContente();

    /**
     * The meta object literal for the '<em><b>Lefte</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__LEFTE = eINSTANCE.getStyleImage_Lefte();

    /**
     * The meta object literal for the '<em><b>Margin</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__MARGIN = eINSTANCE.getStyleImage_Margin();

    /**
     * The meta object literal for the '<em><b>Margin Bottome</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__MARGIN_BOTTOME = eINSTANCE.getStyleImage_MarginBottome();

    /**
     * The meta object literal for the '<em><b>Margin Lefte</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__MARGIN_LEFTE = eINSTANCE.getStyleImage_MarginLefte();

    /**
     * The meta object literal for the '<em><b>Margin Righte</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__MARGIN_RIGHTE = eINSTANCE.getStyleImage_MarginRighte();

    /**
     * The meta object literal for the '<em><b>Margin Tope</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__MARGIN_TOPE = eINSTANCE.getStyleImage_MarginTope();

    /**
     * The meta object literal for the '<em><b>Margin Verticale</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__MARGIN_VERTICALE = eINSTANCE.getStyleImage_MarginVerticale();

    /**
     * The meta object literal for the '<em><b>Paddingt</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__PADDINGT = eINSTANCE.getStyleImage_Paddingt();

    /**
     * The meta object literal for the '<em><b>Padding Bottomt</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__PADDING_BOTTOMT = eINSTANCE.getStyleImage_PaddingBottomt();

    /**
     * The meta object literal for the '<em><b>Padding Horizontale</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__PADDING_HORIZONTALE = eINSTANCE.getStyleImage_PaddingHorizontale();

    /**
     * The meta object literal for the '<em><b>Padding Righte</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__PADDING_RIGHTE = eINSTANCE.getStyleImage_PaddingRighte();

    /**
     * The meta object literal for the '<em><b>Padding Tope</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__PADDING_TOPE = eINSTANCE.getStyleImage_PaddingTope();

    /**
     * The meta object literal for the '<em><b>Padding Verticale</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__PADDING_VERTICALE = eINSTANCE.getStyleImage_PaddingVerticale();

    /**
     * The meta object literal for the '<em><b>Rightt</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__RIGHTT = eINSTANCE.getStyleImage_Rightt();

    /**
     * The meta object literal for the '<em><b>Widtht</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__WIDTHT = eINSTANCE.getStyleImage_Widtht();

    /**
     * The meta object literal for the '<em><b>Flex Directiont</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__FLEX_DIRECTIONT = eINSTANCE.getStyleImage_FlexDirectiont();

    /**
     * The meta object literal for the '<em><b>Flex Wrapt</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__FLEX_WRAPT = eINSTANCE.getStyleImage_FlexWrapt();

    /**
     * The meta object literal for the '<em><b>Heighte</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLE_IMAGE__HEIGHTE = eINSTANCE.getStyleImage_Heighte();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl <em>Styleflexbox</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getStyleflexbox()
     * @generated
     */
    EClass STYLEFLEXBOX = eINSTANCE.getStyleflexbox();

    /**
     * The meta object literal for the '<em><b>Align Items3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__ALIGN_ITEMS3 = eINSTANCE.getStyleflexbox_AlignItems3();

    /**
     * The meta object literal for the '<em><b>Align Self3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__ALIGN_SELF3 = eINSTANCE.getStyleflexbox_AlignSelf3();

    /**
     * The meta object literal for the '<em><b>Border Bottom Width3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__BORDER_BOTTOM_WIDTH3 = eINSTANCE.getStyleflexbox_BorderBottomWidth3();

    /**
     * The meta object literal for the '<em><b>Border Left Width3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__BORDER_LEFT_WIDTH3 = eINSTANCE.getStyleflexbox_BorderLeftWidth3();

    /**
     * The meta object literal for the '<em><b>Border Right Width3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__BORDER_RIGHT_WIDTH3 = eINSTANCE.getStyleflexbox_BorderRightWidth3();

    /**
     * The meta object literal for the '<em><b>Border Top Width3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__BORDER_TOP_WIDTH3 = eINSTANCE.getStyleflexbox_BorderTopWidth3();

    /**
     * The meta object literal for the '<em><b>Border Width3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__BORDER_WIDTH3 = eINSTANCE.getStyleflexbox_BorderWidth3();

    /**
     * The meta object literal for the '<em><b>Bottom3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__BOTTOM3 = eINSTANCE.getStyleflexbox_Bottom3();

    /**
     * The meta object literal for the '<em><b>Flex3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__FLEX3 = eINSTANCE.getStyleflexbox_Flex3();

    /**
     * The meta object literal for the '<em><b>Flex Direction3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__FLEX_DIRECTION3 = eINSTANCE.getStyleflexbox_FlexDirection3();

    /**
     * The meta object literal for the '<em><b>Flex Wrap3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__FLEX_WRAP3 = eINSTANCE.getStyleflexbox_FlexWrap3();

    /**
     * The meta object literal for the '<em><b>Height3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__HEIGHT3 = eINSTANCE.getStyleflexbox_Height3();

    /**
     * The meta object literal for the '<em><b>Justify Content3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__JUSTIFY_CONTENT3 = eINSTANCE.getStyleflexbox_JustifyContent3();

    /**
     * The meta object literal for the '<em><b>Left3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__LEFT3 = eINSTANCE.getStyleflexbox_Left3();

    /**
     * The meta object literal for the '<em><b>Margin3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__MARGIN3 = eINSTANCE.getStyleflexbox_Margin3();

    /**
     * The meta object literal for the '<em><b>Margin Bottom3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__MARGIN_BOTTOM3 = eINSTANCE.getStyleflexbox_MarginBottom3();

    /**
     * The meta object literal for the '<em><b>Margin Left3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__MARGIN_LEFT3 = eINSTANCE.getStyleflexbox_MarginLeft3();

    /**
     * The meta object literal for the '<em><b>Margin Right3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__MARGIN_RIGHT3 = eINSTANCE.getStyleflexbox_MarginRight3();

    /**
     * The meta object literal for the '<em><b>Margin Top3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__MARGIN_TOP3 = eINSTANCE.getStyleflexbox_MarginTop3();

    /**
     * The meta object literal for the '<em><b>Margin Vertical3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__MARGIN_VERTICAL3 = eINSTANCE.getStyleflexbox_MarginVertical3();

    /**
     * The meta object literal for the '<em><b>Pendding3</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__PENDDING3 = eINSTANCE.getStyleflexbox_Pendding3();

    /**
     * The meta object literal for the '<em><b>Pandding B</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STYLEFLEXBOX__PANDDING_B = eINSTANCE.getStyleflexbox_PanddingB();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.RemplirTableImpl <em>Remplir Table</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.RemplirTableImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getRemplirTable()
     * @generated
     */
    EClass REMPLIR_TABLE = eINSTANCE.getRemplirTable();

    /**
     * The meta object literal for the '<em><b>Utiliser</b></em>' reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference REMPLIR_TABLE__UTILISER = eINSTANCE.getRemplirTable_Utiliser();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.AlerteFonctionImpl <em>Alerte Fonction</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.AlerteFonctionImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getAlerteFonction()
     * @generated
     */
    EClass ALERTE_FONCTION = eINSTANCE.getAlerteFonction();

    /**
     * The meta object literal for the '<em><b>Message</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ALERTE_FONCTION__MESSAGE = eINSTANCE.getAlerteFonction_Message();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.NavigateImpl <em>Navigate</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.NavigateImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getNavigate()
     * @generated
     */
    EClass NAVIGATE = eINSTANCE.getNavigate();

    /**
     * The meta object literal for the '<em><b>Ref</b></em>' reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference NAVIGATE__REF = eINSTANCE.getNavigate_Ref();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.VueImpl <em>Vue</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.VueImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getVue()
     * @generated
     */
    EClass VUE = eINSTANCE.getVue();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ElementsImpl <em>Elements</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.ElementsImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getElements()
     * @generated
     */
    EClass ELEMENTS = eINSTANCE.getElements();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.composantImpl <em>composant</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.composantImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getcomposant()
     * @generated
     */
    EClass COMPOSANT = eINSTANCE.getcomposant();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute COMPOSANT__NAME = eINSTANCE.getcomposant_Name();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.FormsImpl <em>Forms</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.FormsImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getForms()
     * @generated
     */
    EClass FORMS = eINSTANCE.getForms();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute FORMS__NAME = eINSTANCE.getForms_Name();

    /**
     * The meta object literal for the '<em><b>Ligne</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute FORMS__LIGNE = eINSTANCE.getForms_Ligne();

    /**
     * The meta object literal for the '<em><b>Colonne</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute FORMS__COLONNE = eINSTANCE.getForms_Colonne();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.listsImpl <em>lists</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.listsImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getlists()
     * @generated
     */
    EClass LISTS = eINSTANCE.getlists();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.IconsImpl <em>Icons</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.IconsImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getIcons()
     * @generated
     */
    EClass ICONS = eINSTANCE.getIcons();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ICONS__NAME = eINSTANCE.getIcons_Name();

    /**
     * The meta object literal for the '<em><b>Ligne</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ICONS__LIGNE = eINSTANCE.getIcons_Ligne();

    /**
     * The meta object literal for the '<em><b>Colonne</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ICONS__COLONNE = eINSTANCE.getIcons_Colonne();

    /**
     * The meta object literal for the '<em><b>Style</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference ICONS__STYLE = eINSTANCE.getIcons_Style();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.listViewImpl <em>list View</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.listViewImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getlistView()
     * @generated
     */
    EClass LIST_VIEW = eINSTANCE.getlistView();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute LIST_VIEW__NAME = eINSTANCE.getlistView_Name();

    /**
     * The meta object literal for the '<em><b>Utiliser</b></em>' reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference LIST_VIEW__UTILISER = eINSTANCE.getlistView_Utiliser();

    /**
     * The meta object literal for the '<em><b>Ligne</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute LIST_VIEW__LIGNE = eINSTANCE.getlistView_Ligne();

    /**
     * The meta object literal for the '<em><b>Colonne</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute LIST_VIEW__COLONNE = eINSTANCE.getlistView_Colonne();

    /**
     * The meta object literal for the '<em><b>Style</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference LIST_VIEW__STYLE = eINSTANCE.getlistView_Style();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.RadioButtonImpl <em>Radio Button</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.RadioButtonImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getRadioButton()
     * @generated
     */
    EClass RADIO_BUTTON = eINSTANCE.getRadioButton();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute RADIO_BUTTON__NAME = eINSTANCE.getRadioButton_Name();

    /**
     * The meta object literal for the '<em><b>Ligne</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute RADIO_BUTTON__LIGNE = eINSTANCE.getRadioButton_Ligne();

    /**
     * The meta object literal for the '<em><b>Colonne</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute RADIO_BUTTON__COLONNE = eINSTANCE.getRadioButton_Colonne();

    /**
     * The meta object literal for the '<em><b>Style</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference RADIO_BUTTON__STYLE = eINSTANCE.getRadioButton_Style();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.CheckBoxImpl <em>Check Box</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.CheckBoxImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getCheckBox()
     * @generated
     */
    EClass CHECK_BOX = eINSTANCE.getCheckBox();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute CHECK_BOX__NAME = eINSTANCE.getCheckBox_Name();

    /**
     * The meta object literal for the '<em><b>Ligne</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute CHECK_BOX__LIGNE = eINSTANCE.getCheckBox_Ligne();

    /**
     * The meta object literal for the '<em><b>Colonne</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute CHECK_BOX__COLONNE = eINSTANCE.getCheckBox_Colonne();

    /**
     * The meta object literal for the '<em><b>Style</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference CHECK_BOX__STYLE = eINSTANCE.getCheckBox_Style();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.TextImpl <em>Text</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.TextImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getText()
     * @generated
     */
    EClass TEXT = eINSTANCE.getText();

    /**
     * The meta object literal for the '<em><b>Contenu</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute TEXT__CONTENU = eINSTANCE.getText_Contenu();

    /**
     * The meta object literal for the '<em><b>Style</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference TEXT__STYLE = eINSTANCE.getText_Style();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.InputImpl <em>Input</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.InputImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getInput()
     * @generated
     */
    EClass INPUT = eINSTANCE.getInput();

    /**
     * The meta object literal for the '<em><b>Style</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference INPUT__STYLE = eINSTANCE.getInput_Style();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.IconeImpl <em>Icone</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.IconeImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getIcone()
     * @generated
     */
    EClass ICONE = eINSTANCE.getIcone();

    /**
     * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ICONE__TYPE = eINSTANCE.getIcone_Type();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.SocialIconImpl <em>Social Icon</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.SocialIconImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getSocialIcon()
     * @generated
     */
    EClass SOCIAL_ICON = eINSTANCE.getSocialIcon();

    /**
     * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SOCIAL_ICON__TYPE = eINSTANCE.getSocialIcon_Type();

    /**
     * The meta object literal for the '<em><b>Button</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SOCIAL_ICON__BUTTON = eINSTANCE.getSocialIcon_Button();

    /**
     * The meta object literal for the '<em><b>Raised</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute SOCIAL_ICON__RAISED = eINSTANCE.getSocialIcon_Raised();

    /**
     * The meta object literal for the '<em><b>Onclique</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference SOCIAL_ICON__ONCLIQUE = eINSTANCE.getSocialIcon_Onclique();

    /**
     * The meta object literal for the '<em><b>Onlongclique</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference SOCIAL_ICON__ONLONGCLIQUE = eINSTANCE.getSocialIcon_Onlongclique();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.TabImpl <em>Tab</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.TabImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getTab()
     * @generated
     */
    EClass TAB = eINSTANCE.getTab();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute TAB__NAME = eINSTANCE.getTab_Name();

    /**
     * The meta object literal for the '<em><b>Title</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute TAB__TITLE = eINSTANCE.getTab_Title();

    /**
     * The meta object literal for the '<em><b>Text</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute TAB__TEXT = eINSTANCE.getTab_Text();

    /**
     * The meta object literal for the '<em><b>Icon</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference TAB__ICON = eINSTANCE.getTab_Icon();

    /**
     * The meta object literal for the '<em><b>Elements</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference TAB__ELEMENTS = eINSTANCE.getTab_Elements();

    /**
     * The meta object literal for the '<em><b>Ligne</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute TAB__LIGNE = eINSTANCE.getTab_Ligne();

    /**
     * The meta object literal for the '<em><b>Colonne</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute TAB__COLONNE = eINSTANCE.getTab_Colonne();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.HeadingImpl <em>Heading</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.HeadingImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getHeading()
     * @generated
     */
    EClass HEADING = eINSTANCE.getHeading();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute HEADING__NAME = eINSTANCE.getHeading_Name();

    /**
     * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute HEADING__TYPE = eINSTANCE.getHeading_Type();

    /**
     * The meta object literal for the '<em><b>Ligne</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute HEADING__LIGNE = eINSTANCE.getHeading_Ligne();

    /**
     * The meta object literal for the '<em><b>Colonne</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute HEADING__COLONNE = eINSTANCE.getHeading_Colonne();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ContainerStyleImpl <em>Container Style</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.ContainerStyleImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getContainerStyle()
     * @generated
     */
    EClass CONTAINER_STYLE = eINSTANCE.getContainerStyle();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute CONTAINER_STYLE__NAME = eINSTANCE.getContainerStyle_Name();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ContainerFonctionsImpl <em>Container Fonctions</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.ContainerFonctionsImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getContainerFonctions()
     * @generated
     */
    EClass CONTAINER_FONCTIONS = eINSTANCE.getContainerFonctions();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute CONTAINER_FONCTIONS__NAME = eINSTANCE.getContainerFonctions_Name();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.LayoutImpl <em>Layout</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.LayoutImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getLayout()
     * @generated
     */
    EClass LAYOUT = eINSTANCE.getLayout();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute LAYOUT__NAME = eINSTANCE.getLayout_Name();

    /**
     * The meta object literal for the '<em><b>Titre</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute LAYOUT__TITRE = eINSTANCE.getLayout_Titre();

    /**
     * The meta object literal for the '<em><b>Contient</b></em>' reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference LAYOUT__CONTIENT = eINSTANCE.getLayout_Contient();

    /**
     * The meta object literal for the '<em><b>Style</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference LAYOUT__STYLE = eINSTANCE.getLayout_Style();

    /**
     * The meta object literal for the '<em><b>Style B</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference LAYOUT__STYLE_B = eINSTANCE.getLayout_StyleB();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.BoutonImpl <em>Bouton</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.BoutonImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getBouton()
     * @generated
     */
    EClass BOUTON = eINSTANCE.getBouton();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute BOUTON__NAME = eINSTANCE.getBouton_Name();

    /**
     * The meta object literal for the '<em><b>Icon</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference BOUTON__ICON = eINSTANCE.getBouton_Icon();

    /**
     * The meta object literal for the '<em><b>Onclique</b></em>' reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference BOUTON__ONCLIQUE = eINSTANCE.getBouton_Onclique();

    /**
     * The meta object literal for the '<em><b>Onlongclique</b></em>' reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference BOUTON__ONLONGCLIQUE = eINSTANCE.getBouton_Onlongclique();

    /**
     * The meta object literal for the '<em><b>Prop</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute BOUTON__PROP = eINSTANCE.getBouton_Prop();

    /**
     * The meta object literal for the '<em><b>Icon Right</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute BOUTON__ICON_RIGHT = eINSTANCE.getBouton_IconRight();

    /**
     * The meta object literal for the '<em><b>Ligne</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute BOUTON__LIGNE = eINSTANCE.getBouton_Ligne();

    /**
     * The meta object literal for the '<em><b>Colonne</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute BOUTON__COLONNE = eINSTANCE.getBouton_Colonne();

    /**
     * The meta object literal for the '<em><b>Style</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference BOUTON__STYLE = eINSTANCE.getBouton_Style();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.VideoImpl <em>Video</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.VideoImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getVideo()
     * @generated
     */
    EClass VIDEO = eINSTANCE.getVideo();

    /**
     * The meta object literal for the '<em><b>Url V</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute VIDEO__URL_V = eINSTANCE.getVideo_UrlV();

    /**
     * The meta object literal for the '<em><b>Mutte</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute VIDEO__MUTTE = eINSTANCE.getVideo_Mutte();

    /**
     * The meta object literal for the '<em><b>Widtht</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute VIDEO__WIDTHT = eINSTANCE.getVideo_Widtht();

    /**
     * The meta object literal for the '<em><b>Heightr</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute VIDEO__HEIGHTR = eINSTANCE.getVideo_Heightr();

    /**
     * The meta object literal for the '<em><b>Ligne Audio</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute VIDEO__LIGNE_AUDIO = eINSTANCE.getVideo_LigneAudio();

    /**
     * The meta object literal for the '<em><b>Colone Audio</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute VIDEO__COLONE_AUDIO = eINSTANCE.getVideo_ColoneAudio();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.AudioImpl <em>Audio</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.AudioImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getAudio()
     * @generated
     */
    EClass AUDIO = eINSTANCE.getAudio();

    /**
     * The meta object literal for the '<em><b>Url T</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute AUDIO__URL_T = eINSTANCE.getAudio_UrlT();

    /**
     * The meta object literal for the '<em><b>Textbout</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute AUDIO__TEXTBOUT = eINSTANCE.getAudio_Textbout();

    /**
     * The meta object literal for the '<em><b>Ligne Audio</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute AUDIO__LIGNE_AUDIO = eINSTANCE.getAudio_LigneAudio();

    /**
     * The meta object literal for the '<em><b>Colone Audio</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute AUDIO__COLONE_AUDIO = eINSTANCE.getAudio_ColoneAudio();

    /**
     * The meta object literal for the '<em><b>Style Audio</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference AUDIO__STYLE_AUDIO = eINSTANCE.getAudio_StyleAudio();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.MapViewImpl <em>Map View</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.MapViewImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getMapView()
     * @generated
     */
    EClass MAP_VIEW = eINSTANCE.getMapView();

    /**
     * The meta object literal for the '<em><b>Latitude</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute MAP_VIEW__LATITUDE = eINSTANCE.getMapView_Latitude();

    /**
     * The meta object literal for the '<em><b>Longitude</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute MAP_VIEW__LONGITUDE = eINSTANCE.getMapView_Longitude();

    /**
     * The meta object literal for the '<em><b>Latitude Delta</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute MAP_VIEW__LATITUDE_DELTA = eINSTANCE.getMapView_LatitudeDelta();

    /**
     * The meta object literal for the '<em><b>Longitude Delta</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute MAP_VIEW__LONGITUDE_DELTA = eINSTANCE.getMapView_LongitudeDelta();

    /**
     * The meta object literal for the '<em><b>Ligne</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute MAP_VIEW__LIGNE = eINSTANCE.getMapView_Ligne();

    /**
     * The meta object literal for the '<em><b>Colone</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute MAP_VIEW__COLONE = eINSTANCE.getMapView_Colone();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ImageImpl <em>Image</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.ImageImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getImage()
     * @generated
     */
    EClass IMAGE = eINSTANCE.getImage();

    /**
     * The meta object literal for the '<em><b>Url</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IMAGE__URL = eINSTANCE.getImage_Url();

    /**
     * The meta object literal for the '<em><b>Ligne</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IMAGE__LIGNE = eINSTANCE.getImage_Ligne();

    /**
     * The meta object literal for the '<em><b>Colone</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute IMAGE__COLONE = eINSTANCE.getImage_Colone();

    /**
     * The meta object literal for the '<em><b>Style</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference IMAGE__STYLE = eINSTANCE.getImage_Style();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.ModelImpl <em>Model</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.ModelImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getModel()
     * @generated
     */
    EClass MODEL = eINSTANCE.getModel();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.impl.TableDefinitionImpl <em>Table Definition</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.TableDefinitionImpl
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getTableDefinition()
     * @generated
     */
    EClass TABLE_DEFINITION = eINSTANCE.getTableDefinition();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute TABLE_DEFINITION__NAME = eINSTANCE.getTableDefinition_Name();

    /**
     * The meta object literal for the '<em><b>Champ</b></em>' reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference TABLE_DEFINITION__CHAMP = eINSTANCE.getTableDefinition_Champ();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.One <em>One</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.One
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getOne()
     * @generated
     */
    EEnum ONE = eINSTANCE.getOne();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.Nine <em>Nine</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.Nine
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getNine()
     * @generated
     */
    EEnum NINE = eINSTANCE.getNine();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.Eignth <em>Eignth</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.Eignth
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getEignth()
     * @generated
     */
    EEnum EIGNTH = eINSTANCE.getEignth();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.Three <em>Three</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.Three
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getThree()
     * @generated
     */
    EEnum THREE = eINSTANCE.getThree();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.Foor <em>Foor</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.Foor
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getFoor()
     * @generated
     */
    EEnum FOOR = eINSTANCE.getFoor();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.Colors <em>Colors</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.Colors
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getColors()
     * @generated
     */
    EEnum COLORS = eINSTANCE.getColors();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.aliIT <em>ali IT</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.aliIT
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getaliIT()
     * @generated
     */
    EEnum ALI_IT = eINSTANCE.getaliIT();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.alfem <em>alfem</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.alfem
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getalfem()
     * @generated
     */
    EEnum ALFEM = eINSTANCE.getalfem();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.bordersty <em>bordersty</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.bordersty
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getbordersty()
     * @generated
     */
    EEnum BORDERSTY = eINSTANCE.getbordersty();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.textType <em>text Type</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.textType
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#gettextType()
     * @generated
     */
    EEnum TEXT_TYPE = eINSTANCE.gettextType();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.Backnum <em>Backnum</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.Backnum
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getBacknum()
     * @generated
     */
    EEnum BACKNUM = eINSTANCE.getBacknum();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.TypeH <em>Type H</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.TypeH
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getTypeH()
     * @generated
     */
    EEnum TYPE_H = eINSTANCE.getTypeH();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.IconType <em>Icon Type</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.IconType
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getIconType()
     * @generated
     */
    EEnum ICON_TYPE = eINSTANCE.getIconType();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.sizelist <em>sizelist</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.sizelist
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getsizelist()
     * @generated
     */
    EEnum SIZELIST = eINSTANCE.getsizelist();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.SocialIconType <em>Social Icon Type</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.SocialIconType
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getSocialIconType()
     * @generated
     */
    EEnum SOCIAL_ICON_TYPE = eINSTANCE.getSocialIconType();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.flexd <em>flexd</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.flexd
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getflexd()
     * @generated
     */
    EEnum FLEXD = eINSTANCE.getflexd();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.mut <em>mut</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.mut
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getmut()
     * @generated
     */
    EEnum MUT = eINSTANCE.getmut();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.buttonType <em>button Type</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.buttonType
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getbuttonType()
     * @generated
     */
    EEnum BUTTON_TYPE = eINSTANCE.getbuttonType();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.raisedType <em>raised Type</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.raisedType
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getraisedType()
     * @generated
     */
    EEnum RAISED_TYPE = eINSTANCE.getraisedType();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.PropType <em>Prop Type</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.PropType
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getPropType()
     * @generated
     */
    EEnum PROP_TYPE = eINSTANCE.getPropType();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.IconRightType <em>Icon Right Type</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.IconRightType
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getIconRightType()
     * @generated
     */
    EEnum ICON_RIGHT_TYPE = eINSTANCE.getIconRightType();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.JustifyContentType <em>Justify Content Type</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.JustifyContentType
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getJustifyContentType()
     * @generated
     */
    EEnum JUSTIFY_CONTENT_TYPE = eINSTANCE.getJustifyContentType();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.entier <em>entier</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.entier
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getentier()
     * @generated
     */
    EEnum ENTIER = eINSTANCE.getentier();

    /**
     * The meta object literal for the '{@link org.xtext.UnivTlemcen.pfe.pfe.LC <em>LC</em>}' enum.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.UnivTlemcen.pfe.pfe.LC
     * @see org.xtext.UnivTlemcen.pfe.pfe.impl.PfePackageImpl#getLC()
     * @generated
     */
    EEnum LC = eINSTANCE.getLC();

  }

} //PfePackage
