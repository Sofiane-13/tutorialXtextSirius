/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>stylesheet</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getstylesheet()
 * @model
 * @generated
 */
public interface stylesheet extends Fonctions
{
} // stylesheet
