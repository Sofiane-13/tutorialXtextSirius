/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>ali IT</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getaliIT()
 * @model
 * @generated
 */
public enum aliIT implements Enumerator
{
  /**
   * The '<em><b>None</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #NONE_VALUE
   * @generated
   * @ordered
   */
  NONE(0, "none", "none"),

  /**
   * The '<em><b>Flex</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #FLEX_VALUE
   * @generated
   * @ordered
   */
  FLEX(1, "flex", "flex-start"),

  /**
   * The '<em><b>Flex1</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #FLEX1_VALUE
   * @generated
   * @ordered
   */
  FLEX1(2, "flex1", "flex-end"),

  /**
   * The '<em><b>Cnt</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #CNT_VALUE
   * @generated
   * @ordered
   */
  CNT(3, "cnt", "center"),

  /**
   * The '<em><b>Str</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #STR_VALUE
   * @generated
   * @ordered
   */
  STR(4, "str", "stretch");

  /**
   * The '<em><b>None</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>None</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #NONE
   * @model name="none"
   * @generated
   * @ordered
   */
  public static final int NONE_VALUE = 0;

  /**
   * The '<em><b>Flex</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Flex</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #FLEX
   * @model name="flex" literal="flex-start"
   * @generated
   * @ordered
   */
  public static final int FLEX_VALUE = 1;

  /**
   * The '<em><b>Flex1</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Flex1</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #FLEX1
   * @model name="flex1" literal="flex-end"
   * @generated
   * @ordered
   */
  public static final int FLEX1_VALUE = 2;

  /**
   * The '<em><b>Cnt</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Cnt</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #CNT
   * @model name="cnt" literal="center"
   * @generated
   * @ordered
   */
  public static final int CNT_VALUE = 3;

  /**
   * The '<em><b>Str</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Str</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #STR
   * @model name="str" literal="stretch"
   * @generated
   * @ordered
   */
  public static final int STR_VALUE = 4;

  /**
   * An array of all the '<em><b>ali IT</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static final aliIT[] VALUES_ARRAY =
    new aliIT[]
    {
      NONE,
      FLEX,
      FLEX1,
      CNT,
      STR,
    };

  /**
   * A public read-only list of all the '<em><b>ali IT</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static final List<aliIT> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

  /**
   * Returns the '<em><b>ali IT</b></em>' literal with the specified literal value.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static aliIT get(String literal)
  {
    for (int i = 0; i < VALUES_ARRAY.length; ++i)
    {
      aliIT result = VALUES_ARRAY[i];
      if (result.toString().equals(literal))
      {
        return result;
      }
    }
    return null;
  }

  /**
   * Returns the '<em><b>ali IT</b></em>' literal with the specified name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static aliIT getByName(String name)
  {
    for (int i = 0; i < VALUES_ARRAY.length; ++i)
    {
      aliIT result = VALUES_ARRAY[i];
      if (result.getName().equals(name))
      {
        return result;
      }
    }
    return null;
  }

  /**
   * Returns the '<em><b>ali IT</b></em>' literal with the specified integer value.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static aliIT get(int value)
  {
    switch (value)
    {
      case NONE_VALUE: return NONE;
      case FLEX_VALUE: return FLEX;
      case FLEX1_VALUE: return FLEX1;
      case CNT_VALUE: return CNT;
      case STR_VALUE: return STR;
    }
    return null;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final int value;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final String name;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final String literal;

  /**
   * Only this class can construct instances.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private aliIT(int value, String name, String literal)
  {
    this.value = value;
    this.name = name;
    this.literal = literal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public int getValue()
  {
    return value;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getLiteral()
  {
    return literal;
  }

  /**
   * Returns the literal value of the enumerator, which is its string representation.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    return literal;
  }
  
} //aliIT
