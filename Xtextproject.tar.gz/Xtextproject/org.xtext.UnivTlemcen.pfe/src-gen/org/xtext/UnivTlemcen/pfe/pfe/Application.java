/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Application</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Application#getName <em>Name</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Application#getPackageName <em>Package Name</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Application#getFirstLayout <em>First Layout</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Application#getModel <em>Model</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Application#getVue <em>Vue</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Application#getControleur <em>Controleur</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getApplication()
 * @model
 * @generated
 */
public interface Application extends EObject
{
  /**
   * Returns the value of the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' attribute.
   * @see #setName(String)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getApplication_Name()
   * @model
   * @generated
   */
  String getName();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Application#getName <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name</em>' attribute.
   * @see #getName()
   * @generated
   */
  void setName(String value);

  /**
   * Returns the value of the '<em><b>Package Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Package Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Package Name</em>' attribute.
   * @see #setPackageName(String)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getApplication_PackageName()
   * @model
   * @generated
   */
  String getPackageName();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Application#getPackageName <em>Package Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Package Name</em>' attribute.
   * @see #getPackageName()
   * @generated
   */
  void setPackageName(String value);

  /**
   * Returns the value of the '<em><b>First Layout</b></em>' reference list.
   * The list contents are of type {@link org.xtext.UnivTlemcen.pfe.pfe.Layout}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>First Layout</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>First Layout</em>' reference list.
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getApplication_FirstLayout()
   * @model
   * @generated
   */
  EList<Layout> getFirstLayout();

  /**
   * Returns the value of the '<em><b>Model</b></em>' containment reference list.
   * The list contents are of type {@link org.xtext.UnivTlemcen.pfe.pfe.Model}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Model</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Model</em>' containment reference list.
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getApplication_Model()
   * @model containment="true"
   * @generated
   */
  EList<Model> getModel();

  /**
   * Returns the value of the '<em><b>Vue</b></em>' containment reference list.
   * The list contents are of type {@link org.xtext.UnivTlemcen.pfe.pfe.Vue}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Vue</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Vue</em>' containment reference list.
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getApplication_Vue()
   * @model containment="true"
   * @generated
   */
  EList<Vue> getVue();

  /**
   * Returns the value of the '<em><b>Controleur</b></em>' containment reference list.
   * The list contents are of type {@link org.xtext.UnivTlemcen.pfe.pfe.Controleur}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Controleur</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Controleur</em>' containment reference list.
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getApplication_Controleur()
   * @model containment="true"
   * @generated
   */
  EList<Controleur> getControleur();

} // Application
