/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Foor</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getFoor()
 * @model
 * @generated
 */
public enum Foor implements Enumerator
{
  /**
   * The '<em><b>Nrmal</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #NRMAL_VALUE
   * @generated
   * @ordered
   */
  NRMAL(0, "nrmal", "normal"),

  /**
   * The '<em><b>Bold</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #BOLD_VALUE
   * @generated
   * @ordered
   */
  BOLD(1, "bold", "bold"),

  /**
   * The '<em><b>A</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #A_VALUE
   * @generated
   * @ordered
   */
  A(2, "A", "100"),

  /**
   * The '<em><b>B</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #B_VALUE
   * @generated
   * @ordered
   */
  B(3, "B", "200"),

  /**
   * The '<em><b>C</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #C_VALUE
   * @generated
   * @ordered
   */
  C(4, "C", "300"),

  /**
   * The '<em><b>D</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #D_VALUE
   * @generated
   * @ordered
   */
  D(5, "D", "400"),

  /**
   * The '<em><b>E</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #E_VALUE
   * @generated
   * @ordered
   */
  E(6, "E", "500"),

  /**
   * The '<em><b>F</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #F_VALUE
   * @generated
   * @ordered
   */
  F(7, "F", "600"),

  /**
   * The '<em><b>G</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #G_VALUE
   * @generated
   * @ordered
   */
  G(8, "G", "700"),

  /**
   * The '<em><b>H</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #H_VALUE
   * @generated
   * @ordered
   */
  H(9, "H", "800"),

  /**
   * The '<em><b>I</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #I_VALUE
   * @generated
   * @ordered
   */
  I(10, "I", "900");

  /**
   * The '<em><b>Nrmal</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Nrmal</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #NRMAL
   * @model name="nrmal" literal="normal"
   * @generated
   * @ordered
   */
  public static final int NRMAL_VALUE = 0;

  /**
   * The '<em><b>Bold</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>Bold</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #BOLD
   * @model name="bold"
   * @generated
   * @ordered
   */
  public static final int BOLD_VALUE = 1;

  /**
   * The '<em><b>A</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>A</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #A
   * @model literal="100"
   * @generated
   * @ordered
   */
  public static final int A_VALUE = 2;

  /**
   * The '<em><b>B</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>B</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #B
   * @model literal="200"
   * @generated
   * @ordered
   */
  public static final int B_VALUE = 3;

  /**
   * The '<em><b>C</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>C</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #C
   * @model literal="300"
   * @generated
   * @ordered
   */
  public static final int C_VALUE = 4;

  /**
   * The '<em><b>D</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>D</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #D
   * @model literal="400"
   * @generated
   * @ordered
   */
  public static final int D_VALUE = 5;

  /**
   * The '<em><b>E</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>E</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #E
   * @model literal="500"
   * @generated
   * @ordered
   */
  public static final int E_VALUE = 6;

  /**
   * The '<em><b>F</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>F</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #F
   * @model literal="600"
   * @generated
   * @ordered
   */
  public static final int F_VALUE = 7;

  /**
   * The '<em><b>G</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>G</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #G
   * @model literal="700"
   * @generated
   * @ordered
   */
  public static final int G_VALUE = 8;

  /**
   * The '<em><b>H</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>H</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #H
   * @model literal="800"
   * @generated
   * @ordered
   */
  public static final int H_VALUE = 9;

  /**
   * The '<em><b>I</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>I</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #I
   * @model literal="900"
   * @generated
   * @ordered
   */
  public static final int I_VALUE = 10;

  /**
   * An array of all the '<em><b>Foor</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static final Foor[] VALUES_ARRAY =
    new Foor[]
    {
      NRMAL,
      BOLD,
      A,
      B,
      C,
      D,
      E,
      F,
      G,
      H,
      I,
    };

  /**
   * A public read-only list of all the '<em><b>Foor</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static final List<Foor> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

  /**
   * Returns the '<em><b>Foor</b></em>' literal with the specified literal value.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static Foor get(String literal)
  {
    for (int i = 0; i < VALUES_ARRAY.length; ++i)
    {
      Foor result = VALUES_ARRAY[i];
      if (result.toString().equals(literal))
      {
        return result;
      }
    }
    return null;
  }

  /**
   * Returns the '<em><b>Foor</b></em>' literal with the specified name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static Foor getByName(String name)
  {
    for (int i = 0; i < VALUES_ARRAY.length; ++i)
    {
      Foor result = VALUES_ARRAY[i];
      if (result.getName().equals(name))
      {
        return result;
      }
    }
    return null;
  }

  /**
   * Returns the '<em><b>Foor</b></em>' literal with the specified integer value.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static Foor get(int value)
  {
    switch (value)
    {
      case NRMAL_VALUE: return NRMAL;
      case BOLD_VALUE: return BOLD;
      case A_VALUE: return A;
      case B_VALUE: return B;
      case C_VALUE: return C;
      case D_VALUE: return D;
      case E_VALUE: return E;
      case F_VALUE: return F;
      case G_VALUE: return G;
      case H_VALUE: return H;
      case I_VALUE: return I;
    }
    return null;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final int value;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final String name;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private final String literal;

  /**
   * Only this class can construct instances.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private Foor(int value, String name, String literal)
  {
    this.value = value;
    this.name = name;
    this.literal = literal;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public int getValue()
  {
    return value;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getLiteral()
  {
    return literal;
  }

  /**
   * Returns the literal value of the enumerator, which is its string representation.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    return literal;
  }
  
} //Foor
