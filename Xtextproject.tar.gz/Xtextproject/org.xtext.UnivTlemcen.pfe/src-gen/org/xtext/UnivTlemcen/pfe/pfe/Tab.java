/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tab</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Tab#getName <em>Name</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Tab#getTitle <em>Title</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Tab#getText <em>Text</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Tab#getIcon <em>Icon</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Tab#getElements <em>Elements</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Tab#getLigne <em>Ligne</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Tab#getColonne <em>Colonne</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getTab()
 * @model
 * @generated
 */
public interface Tab extends Elements
{
  /**
   * Returns the value of the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' attribute.
   * @see #setName(String)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getTab_Name()
   * @model
   * @generated
   */
  String getName();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Tab#getName <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name</em>' attribute.
   * @see #getName()
   * @generated
   */
  void setName(String value);

  /**
   * Returns the value of the '<em><b>Title</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Title</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Title</em>' attribute.
   * @see #setTitle(String)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getTab_Title()
   * @model
   * @generated
   */
  String getTitle();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Tab#getTitle <em>Title</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Title</em>' attribute.
   * @see #getTitle()
   * @generated
   */
  void setTitle(String value);

  /**
   * Returns the value of the '<em><b>Text</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.textType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Text</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Text</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.textType
   * @see #setText(textType)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getTab_Text()
   * @model
   * @generated
   */
  textType getText();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Tab#getText <em>Text</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Text</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.textType
   * @see #getText()
   * @generated
   */
  void setText(textType value);

  /**
   * Returns the value of the '<em><b>Icon</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Icon</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Icon</em>' containment reference.
   * @see #setIcon(Icone)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getTab_Icon()
   * @model containment="true"
   * @generated
   */
  Icone getIcon();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Tab#getIcon <em>Icon</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Icon</em>' containment reference.
   * @see #getIcon()
   * @generated
   */
  void setIcon(Icone value);

  /**
   * Returns the value of the '<em><b>Elements</b></em>' containment reference list.
   * The list contents are of type {@link org.xtext.UnivTlemcen.pfe.pfe.Elements}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Elements</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Elements</em>' containment reference list.
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getTab_Elements()
   * @model containment="true"
   * @generated
   */
  EList<Elements> getElements();

  /**
   * Returns the value of the '<em><b>Ligne</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.LC}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Ligne</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Ligne</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #setLigne(LC)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getTab_Ligne()
   * @model
   * @generated
   */
  LC getLigne();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Tab#getLigne <em>Ligne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Ligne</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #getLigne()
   * @generated
   */
  void setLigne(LC value);

  /**
   * Returns the value of the '<em><b>Colonne</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.LC}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Colonne</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Colonne</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #setColonne(LC)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getTab_Colonne()
   * @model
   * @generated
   */
  LC getColonne();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Tab#getColonne <em>Colonne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Colonne</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #getColonne()
   * @generated
   */
  void setColonne(LC value);

} // Tab
