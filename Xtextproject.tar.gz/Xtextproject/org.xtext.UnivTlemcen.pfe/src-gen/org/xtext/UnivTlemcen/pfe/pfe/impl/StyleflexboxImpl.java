/**
 */
package org.xtext.UnivTlemcen.pfe.pfe.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.xtext.UnivTlemcen.pfe.pfe.JustifyContentType;
import org.xtext.UnivTlemcen.pfe.pfe.One;
import org.xtext.UnivTlemcen.pfe.pfe.PfePackage;
import org.xtext.UnivTlemcen.pfe.pfe.Styleflexbox;
import org.xtext.UnivTlemcen.pfe.pfe.alfem;
import org.xtext.UnivTlemcen.pfe.pfe.aliIT;
import org.xtext.UnivTlemcen.pfe.pfe.entier;
import org.xtext.UnivTlemcen.pfe.pfe.flexd;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Styleflexbox</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getAlignItems3 <em>Align Items3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getAlignSelf3 <em>Align Self3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getBorderBottomWidth3 <em>Border Bottom Width3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getBorderLeftWidth3 <em>Border Left Width3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getBorderRightWidth3 <em>Border Right Width3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getBorderTopWidth3 <em>Border Top Width3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getBorderWidth3 <em>Border Width3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getBottom3 <em>Bottom3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getFlex3 <em>Flex3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getFlexDirection3 <em>Flex Direction3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getFlexWrap3 <em>Flex Wrap3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getHeight3 <em>Height3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getJustifyContent3 <em>Justify Content3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getLeft3 <em>Left3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getMargin3 <em>Margin3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getMarginBottom3 <em>Margin Bottom3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getMarginLeft3 <em>Margin Left3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getMarginRight3 <em>Margin Right3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getMarginTop3 <em>Margin Top3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getMarginVertical3 <em>Margin Vertical3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getPendding3 <em>Pendding3</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.StyleflexboxImpl#getPanddingB <em>Pandding B</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class StyleflexboxImpl extends stylesheetImpl implements Styleflexbox
{
  /**
   * The default value of the '{@link #getAlignItems3() <em>Align Items3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAlignItems3()
   * @generated
   * @ordered
   */
  protected static final aliIT ALIGN_ITEMS3_EDEFAULT = aliIT.NONE;

  /**
   * The cached value of the '{@link #getAlignItems3() <em>Align Items3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAlignItems3()
   * @generated
   * @ordered
   */
  protected aliIT alignItems3 = ALIGN_ITEMS3_EDEFAULT;

  /**
   * The default value of the '{@link #getAlignSelf3() <em>Align Self3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAlignSelf3()
   * @generated
   * @ordered
   */
  protected static final alfem ALIGN_SELF3_EDEFAULT = alfem.NONE;

  /**
   * The cached value of the '{@link #getAlignSelf3() <em>Align Self3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAlignSelf3()
   * @generated
   * @ordered
   */
  protected alfem alignSelf3 = ALIGN_SELF3_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderBottomWidth3() <em>Border Bottom Width3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomWidth3()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_BOTTOM_WIDTH3_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderBottomWidth3() <em>Border Bottom Width3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderBottomWidth3()
   * @generated
   * @ordered
   */
  protected entier borderBottomWidth3 = BORDER_BOTTOM_WIDTH3_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderLeftWidth3() <em>Border Left Width3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderLeftWidth3()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_LEFT_WIDTH3_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderLeftWidth3() <em>Border Left Width3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderLeftWidth3()
   * @generated
   * @ordered
   */
  protected entier borderLeftWidth3 = BORDER_LEFT_WIDTH3_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderRightWidth3() <em>Border Right Width3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderRightWidth3()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_RIGHT_WIDTH3_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderRightWidth3() <em>Border Right Width3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderRightWidth3()
   * @generated
   * @ordered
   */
  protected entier borderRightWidth3 = BORDER_RIGHT_WIDTH3_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderTopWidth3() <em>Border Top Width3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopWidth3()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_TOP_WIDTH3_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderTopWidth3() <em>Border Top Width3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderTopWidth3()
   * @generated
   * @ordered
   */
  protected entier borderTopWidth3 = BORDER_TOP_WIDTH3_EDEFAULT;

  /**
   * The default value of the '{@link #getBorderWidth3() <em>Border Width3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderWidth3()
   * @generated
   * @ordered
   */
  protected static final entier BORDER_WIDTH3_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBorderWidth3() <em>Border Width3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBorderWidth3()
   * @generated
   * @ordered
   */
  protected entier borderWidth3 = BORDER_WIDTH3_EDEFAULT;

  /**
   * The default value of the '{@link #getBottom3() <em>Bottom3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBottom3()
   * @generated
   * @ordered
   */
  protected static final entier BOTTOM3_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getBottom3() <em>Bottom3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBottom3()
   * @generated
   * @ordered
   */
  protected entier bottom3 = BOTTOM3_EDEFAULT;

  /**
   * The default value of the '{@link #getFlex3() <em>Flex3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFlex3()
   * @generated
   * @ordered
   */
  protected static final entier FLEX3_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getFlex3() <em>Flex3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFlex3()
   * @generated
   * @ordered
   */
  protected entier flex3 = FLEX3_EDEFAULT;

  /**
   * The default value of the '{@link #getFlexDirection3() <em>Flex Direction3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFlexDirection3()
   * @generated
   * @ordered
   */
  protected static final flexd FLEX_DIRECTION3_EDEFAULT = flexd.NONE;

  /**
   * The cached value of the '{@link #getFlexDirection3() <em>Flex Direction3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFlexDirection3()
   * @generated
   * @ordered
   */
  protected flexd flexDirection3 = FLEX_DIRECTION3_EDEFAULT;

  /**
   * The default value of the '{@link #getFlexWrap3() <em>Flex Wrap3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFlexWrap3()
   * @generated
   * @ordered
   */
  protected static final One FLEX_WRAP3_EDEFAULT = One.WRAP;

  /**
   * The cached value of the '{@link #getFlexWrap3() <em>Flex Wrap3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFlexWrap3()
   * @generated
   * @ordered
   */
  protected One flexWrap3 = FLEX_WRAP3_EDEFAULT;

  /**
   * The default value of the '{@link #getHeight3() <em>Height3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHeight3()
   * @generated
   * @ordered
   */
  protected static final entier HEIGHT3_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getHeight3() <em>Height3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHeight3()
   * @generated
   * @ordered
   */
  protected entier height3 = HEIGHT3_EDEFAULT;

  /**
   * The default value of the '{@link #getJustifyContent3() <em>Justify Content3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getJustifyContent3()
   * @generated
   * @ordered
   */
  protected static final JustifyContentType JUSTIFY_CONTENT3_EDEFAULT = JustifyContentType.NONE;

  /**
   * The cached value of the '{@link #getJustifyContent3() <em>Justify Content3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getJustifyContent3()
   * @generated
   * @ordered
   */
  protected JustifyContentType justifyContent3 = JUSTIFY_CONTENT3_EDEFAULT;

  /**
   * The default value of the '{@link #getLeft3() <em>Left3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLeft3()
   * @generated
   * @ordered
   */
  protected static final entier LEFT3_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getLeft3() <em>Left3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLeft3()
   * @generated
   * @ordered
   */
  protected entier left3 = LEFT3_EDEFAULT;

  /**
   * The default value of the '{@link #getMargin3() <em>Margin3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMargin3()
   * @generated
   * @ordered
   */
  protected static final entier MARGIN3_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getMargin3() <em>Margin3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMargin3()
   * @generated
   * @ordered
   */
  protected entier margin3 = MARGIN3_EDEFAULT;

  /**
   * The default value of the '{@link #getMarginBottom3() <em>Margin Bottom3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginBottom3()
   * @generated
   * @ordered
   */
  protected static final entier MARGIN_BOTTOM3_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getMarginBottom3() <em>Margin Bottom3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginBottom3()
   * @generated
   * @ordered
   */
  protected entier marginBottom3 = MARGIN_BOTTOM3_EDEFAULT;

  /**
   * The default value of the '{@link #getMarginLeft3() <em>Margin Left3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginLeft3()
   * @generated
   * @ordered
   */
  protected static final entier MARGIN_LEFT3_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getMarginLeft3() <em>Margin Left3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginLeft3()
   * @generated
   * @ordered
   */
  protected entier marginLeft3 = MARGIN_LEFT3_EDEFAULT;

  /**
   * The default value of the '{@link #getMarginRight3() <em>Margin Right3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginRight3()
   * @generated
   * @ordered
   */
  protected static final entier MARGIN_RIGHT3_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getMarginRight3() <em>Margin Right3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginRight3()
   * @generated
   * @ordered
   */
  protected entier marginRight3 = MARGIN_RIGHT3_EDEFAULT;

  /**
   * The default value of the '{@link #getMarginTop3() <em>Margin Top3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginTop3()
   * @generated
   * @ordered
   */
  protected static final entier MARGIN_TOP3_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getMarginTop3() <em>Margin Top3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginTop3()
   * @generated
   * @ordered
   */
  protected entier marginTop3 = MARGIN_TOP3_EDEFAULT;

  /**
   * The default value of the '{@link #getMarginVertical3() <em>Margin Vertical3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginVertical3()
   * @generated
   * @ordered
   */
  protected static final entier MARGIN_VERTICAL3_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getMarginVertical3() <em>Margin Vertical3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMarginVertical3()
   * @generated
   * @ordered
   */
  protected entier marginVertical3 = MARGIN_VERTICAL3_EDEFAULT;

  /**
   * The default value of the '{@link #getPendding3() <em>Pendding3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPendding3()
   * @generated
   * @ordered
   */
  protected static final entier PENDDING3_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getPendding3() <em>Pendding3</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPendding3()
   * @generated
   * @ordered
   */
  protected entier pendding3 = PENDDING3_EDEFAULT;

  /**
   * The default value of the '{@link #getPanddingB() <em>Pandding B</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPanddingB()
   * @generated
   * @ordered
   */
  protected static final entier PANDDING_B_EDEFAULT = entier.NONE;

  /**
   * The cached value of the '{@link #getPanddingB() <em>Pandding B</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPanddingB()
   * @generated
   * @ordered
   */
  protected entier panddingB = PANDDING_B_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected StyleflexboxImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return PfePackage.Literals.STYLEFLEXBOX;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public aliIT getAlignItems3()
  {
    return alignItems3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAlignItems3(aliIT newAlignItems3)
  {
    aliIT oldAlignItems3 = alignItems3;
    alignItems3 = newAlignItems3 == null ? ALIGN_ITEMS3_EDEFAULT : newAlignItems3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__ALIGN_ITEMS3, oldAlignItems3, alignItems3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public alfem getAlignSelf3()
  {
    return alignSelf3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAlignSelf3(alfem newAlignSelf3)
  {
    alfem oldAlignSelf3 = alignSelf3;
    alignSelf3 = newAlignSelf3 == null ? ALIGN_SELF3_EDEFAULT : newAlignSelf3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__ALIGN_SELF3, oldAlignSelf3, alignSelf3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderBottomWidth3()
  {
    return borderBottomWidth3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderBottomWidth3(entier newBorderBottomWidth3)
  {
    entier oldBorderBottomWidth3 = borderBottomWidth3;
    borderBottomWidth3 = newBorderBottomWidth3 == null ? BORDER_BOTTOM_WIDTH3_EDEFAULT : newBorderBottomWidth3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__BORDER_BOTTOM_WIDTH3, oldBorderBottomWidth3, borderBottomWidth3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderLeftWidth3()
  {
    return borderLeftWidth3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderLeftWidth3(entier newBorderLeftWidth3)
  {
    entier oldBorderLeftWidth3 = borderLeftWidth3;
    borderLeftWidth3 = newBorderLeftWidth3 == null ? BORDER_LEFT_WIDTH3_EDEFAULT : newBorderLeftWidth3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__BORDER_LEFT_WIDTH3, oldBorderLeftWidth3, borderLeftWidth3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderRightWidth3()
  {
    return borderRightWidth3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderRightWidth3(entier newBorderRightWidth3)
  {
    entier oldBorderRightWidth3 = borderRightWidth3;
    borderRightWidth3 = newBorderRightWidth3 == null ? BORDER_RIGHT_WIDTH3_EDEFAULT : newBorderRightWidth3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__BORDER_RIGHT_WIDTH3, oldBorderRightWidth3, borderRightWidth3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderTopWidth3()
  {
    return borderTopWidth3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderTopWidth3(entier newBorderTopWidth3)
  {
    entier oldBorderTopWidth3 = borderTopWidth3;
    borderTopWidth3 = newBorderTopWidth3 == null ? BORDER_TOP_WIDTH3_EDEFAULT : newBorderTopWidth3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__BORDER_TOP_WIDTH3, oldBorderTopWidth3, borderTopWidth3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBorderWidth3()
  {
    return borderWidth3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBorderWidth3(entier newBorderWidth3)
  {
    entier oldBorderWidth3 = borderWidth3;
    borderWidth3 = newBorderWidth3 == null ? BORDER_WIDTH3_EDEFAULT : newBorderWidth3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__BORDER_WIDTH3, oldBorderWidth3, borderWidth3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getBottom3()
  {
    return bottom3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setBottom3(entier newBottom3)
  {
    entier oldBottom3 = bottom3;
    bottom3 = newBottom3 == null ? BOTTOM3_EDEFAULT : newBottom3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__BOTTOM3, oldBottom3, bottom3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getFlex3()
  {
    return flex3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFlex3(entier newFlex3)
  {
    entier oldFlex3 = flex3;
    flex3 = newFlex3 == null ? FLEX3_EDEFAULT : newFlex3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__FLEX3, oldFlex3, flex3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public flexd getFlexDirection3()
  {
    return flexDirection3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFlexDirection3(flexd newFlexDirection3)
  {
    flexd oldFlexDirection3 = flexDirection3;
    flexDirection3 = newFlexDirection3 == null ? FLEX_DIRECTION3_EDEFAULT : newFlexDirection3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__FLEX_DIRECTION3, oldFlexDirection3, flexDirection3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public One getFlexWrap3()
  {
    return flexWrap3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFlexWrap3(One newFlexWrap3)
  {
    One oldFlexWrap3 = flexWrap3;
    flexWrap3 = newFlexWrap3 == null ? FLEX_WRAP3_EDEFAULT : newFlexWrap3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__FLEX_WRAP3, oldFlexWrap3, flexWrap3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getHeight3()
  {
    return height3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setHeight3(entier newHeight3)
  {
    entier oldHeight3 = height3;
    height3 = newHeight3 == null ? HEIGHT3_EDEFAULT : newHeight3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__HEIGHT3, oldHeight3, height3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public JustifyContentType getJustifyContent3()
  {
    return justifyContent3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setJustifyContent3(JustifyContentType newJustifyContent3)
  {
    JustifyContentType oldJustifyContent3 = justifyContent3;
    justifyContent3 = newJustifyContent3 == null ? JUSTIFY_CONTENT3_EDEFAULT : newJustifyContent3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__JUSTIFY_CONTENT3, oldJustifyContent3, justifyContent3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getLeft3()
  {
    return left3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLeft3(entier newLeft3)
  {
    entier oldLeft3 = left3;
    left3 = newLeft3 == null ? LEFT3_EDEFAULT : newLeft3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__LEFT3, oldLeft3, left3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getMargin3()
  {
    return margin3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMargin3(entier newMargin3)
  {
    entier oldMargin3 = margin3;
    margin3 = newMargin3 == null ? MARGIN3_EDEFAULT : newMargin3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__MARGIN3, oldMargin3, margin3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getMarginBottom3()
  {
    return marginBottom3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMarginBottom3(entier newMarginBottom3)
  {
    entier oldMarginBottom3 = marginBottom3;
    marginBottom3 = newMarginBottom3 == null ? MARGIN_BOTTOM3_EDEFAULT : newMarginBottom3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__MARGIN_BOTTOM3, oldMarginBottom3, marginBottom3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getMarginLeft3()
  {
    return marginLeft3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMarginLeft3(entier newMarginLeft3)
  {
    entier oldMarginLeft3 = marginLeft3;
    marginLeft3 = newMarginLeft3 == null ? MARGIN_LEFT3_EDEFAULT : newMarginLeft3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__MARGIN_LEFT3, oldMarginLeft3, marginLeft3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getMarginRight3()
  {
    return marginRight3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMarginRight3(entier newMarginRight3)
  {
    entier oldMarginRight3 = marginRight3;
    marginRight3 = newMarginRight3 == null ? MARGIN_RIGHT3_EDEFAULT : newMarginRight3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__MARGIN_RIGHT3, oldMarginRight3, marginRight3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getMarginTop3()
  {
    return marginTop3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMarginTop3(entier newMarginTop3)
  {
    entier oldMarginTop3 = marginTop3;
    marginTop3 = newMarginTop3 == null ? MARGIN_TOP3_EDEFAULT : newMarginTop3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__MARGIN_TOP3, oldMarginTop3, marginTop3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getMarginVertical3()
  {
    return marginVertical3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMarginVertical3(entier newMarginVertical3)
  {
    entier oldMarginVertical3 = marginVertical3;
    marginVertical3 = newMarginVertical3 == null ? MARGIN_VERTICAL3_EDEFAULT : newMarginVertical3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__MARGIN_VERTICAL3, oldMarginVertical3, marginVertical3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getPendding3()
  {
    return pendding3;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPendding3(entier newPendding3)
  {
    entier oldPendding3 = pendding3;
    pendding3 = newPendding3 == null ? PENDDING3_EDEFAULT : newPendding3;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__PENDDING3, oldPendding3, pendding3));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public entier getPanddingB()
  {
    return panddingB;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPanddingB(entier newPanddingB)
  {
    entier oldPanddingB = panddingB;
    panddingB = newPanddingB == null ? PANDDING_B_EDEFAULT : newPanddingB;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.STYLEFLEXBOX__PANDDING_B, oldPanddingB, panddingB));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case PfePackage.STYLEFLEXBOX__ALIGN_ITEMS3:
        return getAlignItems3();
      case PfePackage.STYLEFLEXBOX__ALIGN_SELF3:
        return getAlignSelf3();
      case PfePackage.STYLEFLEXBOX__BORDER_BOTTOM_WIDTH3:
        return getBorderBottomWidth3();
      case PfePackage.STYLEFLEXBOX__BORDER_LEFT_WIDTH3:
        return getBorderLeftWidth3();
      case PfePackage.STYLEFLEXBOX__BORDER_RIGHT_WIDTH3:
        return getBorderRightWidth3();
      case PfePackage.STYLEFLEXBOX__BORDER_TOP_WIDTH3:
        return getBorderTopWidth3();
      case PfePackage.STYLEFLEXBOX__BORDER_WIDTH3:
        return getBorderWidth3();
      case PfePackage.STYLEFLEXBOX__BOTTOM3:
        return getBottom3();
      case PfePackage.STYLEFLEXBOX__FLEX3:
        return getFlex3();
      case PfePackage.STYLEFLEXBOX__FLEX_DIRECTION3:
        return getFlexDirection3();
      case PfePackage.STYLEFLEXBOX__FLEX_WRAP3:
        return getFlexWrap3();
      case PfePackage.STYLEFLEXBOX__HEIGHT3:
        return getHeight3();
      case PfePackage.STYLEFLEXBOX__JUSTIFY_CONTENT3:
        return getJustifyContent3();
      case PfePackage.STYLEFLEXBOX__LEFT3:
        return getLeft3();
      case PfePackage.STYLEFLEXBOX__MARGIN3:
        return getMargin3();
      case PfePackage.STYLEFLEXBOX__MARGIN_BOTTOM3:
        return getMarginBottom3();
      case PfePackage.STYLEFLEXBOX__MARGIN_LEFT3:
        return getMarginLeft3();
      case PfePackage.STYLEFLEXBOX__MARGIN_RIGHT3:
        return getMarginRight3();
      case PfePackage.STYLEFLEXBOX__MARGIN_TOP3:
        return getMarginTop3();
      case PfePackage.STYLEFLEXBOX__MARGIN_VERTICAL3:
        return getMarginVertical3();
      case PfePackage.STYLEFLEXBOX__PENDDING3:
        return getPendding3();
      case PfePackage.STYLEFLEXBOX__PANDDING_B:
        return getPanddingB();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case PfePackage.STYLEFLEXBOX__ALIGN_ITEMS3:
        setAlignItems3((aliIT)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__ALIGN_SELF3:
        setAlignSelf3((alfem)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__BORDER_BOTTOM_WIDTH3:
        setBorderBottomWidth3((entier)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__BORDER_LEFT_WIDTH3:
        setBorderLeftWidth3((entier)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__BORDER_RIGHT_WIDTH3:
        setBorderRightWidth3((entier)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__BORDER_TOP_WIDTH3:
        setBorderTopWidth3((entier)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__BORDER_WIDTH3:
        setBorderWidth3((entier)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__BOTTOM3:
        setBottom3((entier)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__FLEX3:
        setFlex3((entier)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__FLEX_DIRECTION3:
        setFlexDirection3((flexd)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__FLEX_WRAP3:
        setFlexWrap3((One)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__HEIGHT3:
        setHeight3((entier)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__JUSTIFY_CONTENT3:
        setJustifyContent3((JustifyContentType)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__LEFT3:
        setLeft3((entier)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__MARGIN3:
        setMargin3((entier)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__MARGIN_BOTTOM3:
        setMarginBottom3((entier)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__MARGIN_LEFT3:
        setMarginLeft3((entier)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__MARGIN_RIGHT3:
        setMarginRight3((entier)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__MARGIN_TOP3:
        setMarginTop3((entier)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__MARGIN_VERTICAL3:
        setMarginVertical3((entier)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__PENDDING3:
        setPendding3((entier)newValue);
        return;
      case PfePackage.STYLEFLEXBOX__PANDDING_B:
        setPanddingB((entier)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.STYLEFLEXBOX__ALIGN_ITEMS3:
        setAlignItems3(ALIGN_ITEMS3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__ALIGN_SELF3:
        setAlignSelf3(ALIGN_SELF3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__BORDER_BOTTOM_WIDTH3:
        setBorderBottomWidth3(BORDER_BOTTOM_WIDTH3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__BORDER_LEFT_WIDTH3:
        setBorderLeftWidth3(BORDER_LEFT_WIDTH3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__BORDER_RIGHT_WIDTH3:
        setBorderRightWidth3(BORDER_RIGHT_WIDTH3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__BORDER_TOP_WIDTH3:
        setBorderTopWidth3(BORDER_TOP_WIDTH3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__BORDER_WIDTH3:
        setBorderWidth3(BORDER_WIDTH3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__BOTTOM3:
        setBottom3(BOTTOM3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__FLEX3:
        setFlex3(FLEX3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__FLEX_DIRECTION3:
        setFlexDirection3(FLEX_DIRECTION3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__FLEX_WRAP3:
        setFlexWrap3(FLEX_WRAP3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__HEIGHT3:
        setHeight3(HEIGHT3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__JUSTIFY_CONTENT3:
        setJustifyContent3(JUSTIFY_CONTENT3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__LEFT3:
        setLeft3(LEFT3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__MARGIN3:
        setMargin3(MARGIN3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__MARGIN_BOTTOM3:
        setMarginBottom3(MARGIN_BOTTOM3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__MARGIN_LEFT3:
        setMarginLeft3(MARGIN_LEFT3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__MARGIN_RIGHT3:
        setMarginRight3(MARGIN_RIGHT3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__MARGIN_TOP3:
        setMarginTop3(MARGIN_TOP3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__MARGIN_VERTICAL3:
        setMarginVertical3(MARGIN_VERTICAL3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__PENDDING3:
        setPendding3(PENDDING3_EDEFAULT);
        return;
      case PfePackage.STYLEFLEXBOX__PANDDING_B:
        setPanddingB(PANDDING_B_EDEFAULT);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.STYLEFLEXBOX__ALIGN_ITEMS3:
        return alignItems3 != ALIGN_ITEMS3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__ALIGN_SELF3:
        return alignSelf3 != ALIGN_SELF3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__BORDER_BOTTOM_WIDTH3:
        return borderBottomWidth3 != BORDER_BOTTOM_WIDTH3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__BORDER_LEFT_WIDTH3:
        return borderLeftWidth3 != BORDER_LEFT_WIDTH3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__BORDER_RIGHT_WIDTH3:
        return borderRightWidth3 != BORDER_RIGHT_WIDTH3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__BORDER_TOP_WIDTH3:
        return borderTopWidth3 != BORDER_TOP_WIDTH3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__BORDER_WIDTH3:
        return borderWidth3 != BORDER_WIDTH3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__BOTTOM3:
        return bottom3 != BOTTOM3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__FLEX3:
        return flex3 != FLEX3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__FLEX_DIRECTION3:
        return flexDirection3 != FLEX_DIRECTION3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__FLEX_WRAP3:
        return flexWrap3 != FLEX_WRAP3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__HEIGHT3:
        return height3 != HEIGHT3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__JUSTIFY_CONTENT3:
        return justifyContent3 != JUSTIFY_CONTENT3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__LEFT3:
        return left3 != LEFT3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__MARGIN3:
        return margin3 != MARGIN3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__MARGIN_BOTTOM3:
        return marginBottom3 != MARGIN_BOTTOM3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__MARGIN_LEFT3:
        return marginLeft3 != MARGIN_LEFT3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__MARGIN_RIGHT3:
        return marginRight3 != MARGIN_RIGHT3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__MARGIN_TOP3:
        return marginTop3 != MARGIN_TOP3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__MARGIN_VERTICAL3:
        return marginVertical3 != MARGIN_VERTICAL3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__PENDDING3:
        return pendding3 != PENDDING3_EDEFAULT;
      case PfePackage.STYLEFLEXBOX__PANDDING_B:
        return panddingB != PANDDING_B_EDEFAULT;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (alignItems3: ");
    result.append(alignItems3);
    result.append(", alignSelf3: ");
    result.append(alignSelf3);
    result.append(", borderBottomWidth3: ");
    result.append(borderBottomWidth3);
    result.append(", borderLeftWidth3: ");
    result.append(borderLeftWidth3);
    result.append(", borderRightWidth3: ");
    result.append(borderRightWidth3);
    result.append(", borderTopWidth3: ");
    result.append(borderTopWidth3);
    result.append(", borderWidth3: ");
    result.append(borderWidth3);
    result.append(", bottom3: ");
    result.append(bottom3);
    result.append(", flex3: ");
    result.append(flex3);
    result.append(", flexDirection3: ");
    result.append(flexDirection3);
    result.append(", flexWrap3: ");
    result.append(flexWrap3);
    result.append(", height3: ");
    result.append(height3);
    result.append(", justifyContent3: ");
    result.append(justifyContent3);
    result.append(", left3: ");
    result.append(left3);
    result.append(", margin3: ");
    result.append(margin3);
    result.append(", marginBottom3: ");
    result.append(marginBottom3);
    result.append(", marginLeft3: ");
    result.append(marginLeft3);
    result.append(", marginRight3: ");
    result.append(marginRight3);
    result.append(", marginTop3: ");
    result.append(marginTop3);
    result.append(", marginVertical3: ");
    result.append(marginVertical3);
    result.append(", pendding3: ");
    result.append(pendding3);
    result.append(", panddingB: ");
    result.append(panddingB);
    result.append(')');
    return result.toString();
  }

} //StyleflexboxImpl
