/**
 */
package org.xtext.UnivTlemcen.pfe.pfe.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.xtext.UnivTlemcen.pfe.pfe.PfePackage;
import org.xtext.UnivTlemcen.pfe.pfe.SocialIcon;
import org.xtext.UnivTlemcen.pfe.pfe.SocialIconType;
import org.xtext.UnivTlemcen.pfe.pfe.buttonType;
import org.xtext.UnivTlemcen.pfe.pfe.fonction;
import org.xtext.UnivTlemcen.pfe.pfe.raisedType;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Social Icon</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.SocialIconImpl#getType <em>Type</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.SocialIconImpl#getButton <em>Button</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.SocialIconImpl#getRaised <em>Raised</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.SocialIconImpl#getOnclique <em>Onclique</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.SocialIconImpl#getOnlongclique <em>Onlongclique</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class SocialIconImpl extends IconsImpl implements SocialIcon
{
  /**
   * The default value of the '{@link #getType() <em>Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getType()
   * @generated
   * @ordered
   */
  protected static final SocialIconType TYPE_EDEFAULT = SocialIconType.NONE;

  /**
   * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getType()
   * @generated
   * @ordered
   */
  protected SocialIconType type = TYPE_EDEFAULT;

  /**
   * The default value of the '{@link #getButton() <em>Button</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getButton()
   * @generated
   * @ordered
   */
  protected static final buttonType BUTTON_EDEFAULT = buttonType.NONE;

  /**
   * The cached value of the '{@link #getButton() <em>Button</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getButton()
   * @generated
   * @ordered
   */
  protected buttonType button = BUTTON_EDEFAULT;

  /**
   * The default value of the '{@link #getRaised() <em>Raised</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getRaised()
   * @generated
   * @ordered
   */
  protected static final raisedType RAISED_EDEFAULT = raisedType.NONE;

  /**
   * The cached value of the '{@link #getRaised() <em>Raised</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getRaised()
   * @generated
   * @ordered
   */
  protected raisedType raised = RAISED_EDEFAULT;

  /**
   * The cached value of the '{@link #getOnclique() <em>Onclique</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOnclique()
   * @generated
   * @ordered
   */
  protected fonction onclique;

  /**
   * The cached value of the '{@link #getOnlongclique() <em>Onlongclique</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOnlongclique()
   * @generated
   * @ordered
   */
  protected fonction onlongclique;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected SocialIconImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return PfePackage.Literals.SOCIAL_ICON;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public SocialIconType getType()
  {
    return type;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setType(SocialIconType newType)
  {
    SocialIconType oldType = type;
    type = newType == null ? TYPE_EDEFAULT : newType;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.SOCIAL_ICON__TYPE, oldType, type));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public buttonType getButton()
  {
    return button;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setButton(buttonType newButton)
  {
    buttonType oldButton = button;
    button = newButton == null ? BUTTON_EDEFAULT : newButton;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.SOCIAL_ICON__BUTTON, oldButton, button));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public raisedType getRaised()
  {
    return raised;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setRaised(raisedType newRaised)
  {
    raisedType oldRaised = raised;
    raised = newRaised == null ? RAISED_EDEFAULT : newRaised;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.SOCIAL_ICON__RAISED, oldRaised, raised));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public fonction getOnclique()
  {
    if (onclique != null && onclique.eIsProxy())
    {
      InternalEObject oldOnclique = (InternalEObject)onclique;
      onclique = (fonction)eResolveProxy(oldOnclique);
      if (onclique != oldOnclique)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, PfePackage.SOCIAL_ICON__ONCLIQUE, oldOnclique, onclique));
      }
    }
    return onclique;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public fonction basicGetOnclique()
  {
    return onclique;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setOnclique(fonction newOnclique)
  {
    fonction oldOnclique = onclique;
    onclique = newOnclique;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.SOCIAL_ICON__ONCLIQUE, oldOnclique, onclique));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public fonction getOnlongclique()
  {
    if (onlongclique != null && onlongclique.eIsProxy())
    {
      InternalEObject oldOnlongclique = (InternalEObject)onlongclique;
      onlongclique = (fonction)eResolveProxy(oldOnlongclique);
      if (onlongclique != oldOnlongclique)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, PfePackage.SOCIAL_ICON__ONLONGCLIQUE, oldOnlongclique, onlongclique));
      }
    }
    return onlongclique;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public fonction basicGetOnlongclique()
  {
    return onlongclique;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setOnlongclique(fonction newOnlongclique)
  {
    fonction oldOnlongclique = onlongclique;
    onlongclique = newOnlongclique;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.SOCIAL_ICON__ONLONGCLIQUE, oldOnlongclique, onlongclique));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case PfePackage.SOCIAL_ICON__TYPE:
        return getType();
      case PfePackage.SOCIAL_ICON__BUTTON:
        return getButton();
      case PfePackage.SOCIAL_ICON__RAISED:
        return getRaised();
      case PfePackage.SOCIAL_ICON__ONCLIQUE:
        if (resolve) return getOnclique();
        return basicGetOnclique();
      case PfePackage.SOCIAL_ICON__ONLONGCLIQUE:
        if (resolve) return getOnlongclique();
        return basicGetOnlongclique();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case PfePackage.SOCIAL_ICON__TYPE:
        setType((SocialIconType)newValue);
        return;
      case PfePackage.SOCIAL_ICON__BUTTON:
        setButton((buttonType)newValue);
        return;
      case PfePackage.SOCIAL_ICON__RAISED:
        setRaised((raisedType)newValue);
        return;
      case PfePackage.SOCIAL_ICON__ONCLIQUE:
        setOnclique((fonction)newValue);
        return;
      case PfePackage.SOCIAL_ICON__ONLONGCLIQUE:
        setOnlongclique((fonction)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.SOCIAL_ICON__TYPE:
        setType(TYPE_EDEFAULT);
        return;
      case PfePackage.SOCIAL_ICON__BUTTON:
        setButton(BUTTON_EDEFAULT);
        return;
      case PfePackage.SOCIAL_ICON__RAISED:
        setRaised(RAISED_EDEFAULT);
        return;
      case PfePackage.SOCIAL_ICON__ONCLIQUE:
        setOnclique((fonction)null);
        return;
      case PfePackage.SOCIAL_ICON__ONLONGCLIQUE:
        setOnlongclique((fonction)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.SOCIAL_ICON__TYPE:
        return type != TYPE_EDEFAULT;
      case PfePackage.SOCIAL_ICON__BUTTON:
        return button != BUTTON_EDEFAULT;
      case PfePackage.SOCIAL_ICON__RAISED:
        return raised != RAISED_EDEFAULT;
      case PfePackage.SOCIAL_ICON__ONCLIQUE:
        return onclique != null;
      case PfePackage.SOCIAL_ICON__ONLONGCLIQUE:
        return onlongclique != null;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (type: ");
    result.append(type);
    result.append(", button: ");
    result.append(button);
    result.append(", raised: ");
    result.append(raised);
    result.append(')');
    return result.toString();
  }

} //SocialIconImpl
