/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Remplir Table</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.RemplirTable#getUtiliser <em>Utiliser</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getRemplirTable()
 * @model
 * @generated
 */
public interface RemplirTable extends fonction
{
  /**
   * Returns the value of the '<em><b>Utiliser</b></em>' reference list.
   * The list contents are of type {@link org.xtext.UnivTlemcen.pfe.pfe.TableDefinition}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Utiliser</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Utiliser</em>' reference list.
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getRemplirTable_Utiliser()
   * @model
   * @generated
   */
  EList<TableDefinition> getUtiliser();

} // RemplirTable
