/**
 */
package org.xtext.UnivTlemcen.pfe.pfe.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import org.xtext.UnivTlemcen.pfe.pfe.Elements;
import org.xtext.UnivTlemcen.pfe.pfe.Layout;
import org.xtext.UnivTlemcen.pfe.pfe.PfePackage;
import org.xtext.UnivTlemcen.pfe.pfe.StyleView;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Layout</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.LayoutImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.LayoutImpl#getTitre <em>Titre</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.LayoutImpl#getContient <em>Contient</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.LayoutImpl#getStyle <em>Style</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.impl.LayoutImpl#getStyleB <em>Style B</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class LayoutImpl extends ElementsImpl implements Layout
{
  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The default value of the '{@link #getTitre() <em>Titre</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTitre()
   * @generated
   * @ordered
   */
  protected static final String TITRE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getTitre() <em>Titre</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTitre()
   * @generated
   * @ordered
   */
  protected String titre = TITRE_EDEFAULT;

  /**
   * The cached value of the '{@link #getContient() <em>Contient</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getContient()
   * @generated
   * @ordered
   */
  protected EList<Elements> contient;

  /**
   * The cached value of the '{@link #getStyle() <em>Style</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getStyle()
   * @generated
   * @ordered
   */
  protected StyleView style;

  /**
   * The cached value of the '{@link #getStyleB() <em>Style B</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getStyleB()
   * @generated
   * @ordered
   */
  protected StyleView styleB;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected LayoutImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return PfePackage.Literals.LAYOUT;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName)
  {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.LAYOUT__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getTitre()
  {
    return titre;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTitre(String newTitre)
  {
    String oldTitre = titre;
    titre = newTitre;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.LAYOUT__TITRE, oldTitre, titre));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Elements> getContient()
  {
    if (contient == null)
    {
      contient = new EObjectResolvingEList<Elements>(Elements.class, this, PfePackage.LAYOUT__CONTIENT);
    }
    return contient;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public StyleView getStyle()
  {
    if (style != null && style.eIsProxy())
    {
      InternalEObject oldStyle = (InternalEObject)style;
      style = (StyleView)eResolveProxy(oldStyle);
      if (style != oldStyle)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, PfePackage.LAYOUT__STYLE, oldStyle, style));
      }
    }
    return style;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public StyleView basicGetStyle()
  {
    return style;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setStyle(StyleView newStyle)
  {
    StyleView oldStyle = style;
    style = newStyle;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.LAYOUT__STYLE, oldStyle, style));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public StyleView getStyleB()
  {
    if (styleB != null && styleB.eIsProxy())
    {
      InternalEObject oldStyleB = (InternalEObject)styleB;
      styleB = (StyleView)eResolveProxy(oldStyleB);
      if (styleB != oldStyleB)
      {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, PfePackage.LAYOUT__STYLE_B, oldStyleB, styleB));
      }
    }
    return styleB;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public StyleView basicGetStyleB()
  {
    return styleB;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setStyleB(StyleView newStyleB)
  {
    StyleView oldStyleB = styleB;
    styleB = newStyleB;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, PfePackage.LAYOUT__STYLE_B, oldStyleB, styleB));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case PfePackage.LAYOUT__NAME:
        return getName();
      case PfePackage.LAYOUT__TITRE:
        return getTitre();
      case PfePackage.LAYOUT__CONTIENT:
        return getContient();
      case PfePackage.LAYOUT__STYLE:
        if (resolve) return getStyle();
        return basicGetStyle();
      case PfePackage.LAYOUT__STYLE_B:
        if (resolve) return getStyleB();
        return basicGetStyleB();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case PfePackage.LAYOUT__NAME:
        setName((String)newValue);
        return;
      case PfePackage.LAYOUT__TITRE:
        setTitre((String)newValue);
        return;
      case PfePackage.LAYOUT__CONTIENT:
        getContient().clear();
        getContient().addAll((Collection<? extends Elements>)newValue);
        return;
      case PfePackage.LAYOUT__STYLE:
        setStyle((StyleView)newValue);
        return;
      case PfePackage.LAYOUT__STYLE_B:
        setStyleB((StyleView)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.LAYOUT__NAME:
        setName(NAME_EDEFAULT);
        return;
      case PfePackage.LAYOUT__TITRE:
        setTitre(TITRE_EDEFAULT);
        return;
      case PfePackage.LAYOUT__CONTIENT:
        getContient().clear();
        return;
      case PfePackage.LAYOUT__STYLE:
        setStyle((StyleView)null);
        return;
      case PfePackage.LAYOUT__STYLE_B:
        setStyleB((StyleView)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case PfePackage.LAYOUT__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case PfePackage.LAYOUT__TITRE:
        return TITRE_EDEFAULT == null ? titre != null : !TITRE_EDEFAULT.equals(titre);
      case PfePackage.LAYOUT__CONTIENT:
        return contient != null && !contient.isEmpty();
      case PfePackage.LAYOUT__STYLE:
        return style != null;
      case PfePackage.LAYOUT__STYLE_B:
        return styleB != null;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (name: ");
    result.append(name);
    result.append(", titre: ");
    result.append(titre);
    result.append(')');
    return result.toString();
  }

} //LayoutImpl
