/**
 */
package org.xtext.UnivTlemcen.pfe.pfe;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Bouton</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getName <em>Name</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getIcon <em>Icon</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getOnclique <em>Onclique</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getOnlongclique <em>Onlongclique</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getProp <em>Prop</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getIconRight <em>Icon Right</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getLigne <em>Ligne</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getColonne <em>Colonne</em>}</li>
 *   <li>{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getStyle <em>Style</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getBouton()
 * @model
 * @generated
 */
public interface Bouton extends Elements
{
  /**
   * Returns the value of the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' attribute.
   * @see #setName(String)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getBouton_Name()
   * @model
   * @generated
   */
  String getName();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getName <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name</em>' attribute.
   * @see #getName()
   * @generated
   */
  void setName(String value);

  /**
   * Returns the value of the '<em><b>Icon</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Icon</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Icon</em>' reference.
   * @see #setIcon(Icone)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getBouton_Icon()
   * @model
   * @generated
   */
  Icone getIcon();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getIcon <em>Icon</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Icon</em>' reference.
   * @see #getIcon()
   * @generated
   */
  void setIcon(Icone value);

  /**
   * Returns the value of the '<em><b>Onclique</b></em>' reference list.
   * The list contents are of type {@link org.xtext.UnivTlemcen.pfe.pfe.fonction}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Onclique</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Onclique</em>' reference list.
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getBouton_Onclique()
   * @model
   * @generated
   */
  EList<fonction> getOnclique();

  /**
   * Returns the value of the '<em><b>Onlongclique</b></em>' reference list.
   * The list contents are of type {@link org.xtext.UnivTlemcen.pfe.pfe.fonction}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Onlongclique</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Onlongclique</em>' reference list.
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getBouton_Onlongclique()
   * @model
   * @generated
   */
  EList<fonction> getOnlongclique();

  /**
   * Returns the value of the '<em><b>Prop</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.PropType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Prop</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Prop</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.PropType
   * @see #setProp(PropType)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getBouton_Prop()
   * @model
   * @generated
   */
  PropType getProp();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getProp <em>Prop</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Prop</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.PropType
   * @see #getProp()
   * @generated
   */
  void setProp(PropType value);

  /**
   * Returns the value of the '<em><b>Icon Right</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.IconRightType}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Icon Right</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Icon Right</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.IconRightType
   * @see #setIconRight(IconRightType)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getBouton_IconRight()
   * @model
   * @generated
   */
  IconRightType getIconRight();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getIconRight <em>Icon Right</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Icon Right</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.IconRightType
   * @see #getIconRight()
   * @generated
   */
  void setIconRight(IconRightType value);

  /**
   * Returns the value of the '<em><b>Ligne</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.LC}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Ligne</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Ligne</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #setLigne(LC)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getBouton_Ligne()
   * @model
   * @generated
   */
  LC getLigne();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getLigne <em>Ligne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Ligne</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #getLigne()
   * @generated
   */
  void setLigne(LC value);

  /**
   * Returns the value of the '<em><b>Colonne</b></em>' attribute.
   * The literals are from the enumeration {@link org.xtext.UnivTlemcen.pfe.pfe.LC}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Colonne</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Colonne</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #setColonne(LC)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getBouton_Colonne()
   * @model
   * @generated
   */
  LC getColonne();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getColonne <em>Colonne</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Colonne</em>' attribute.
   * @see org.xtext.UnivTlemcen.pfe.pfe.LC
   * @see #getColonne()
   * @generated
   */
  void setColonne(LC value);

  /**
   * Returns the value of the '<em><b>Style</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Style</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Style</em>' reference.
   * @see #setStyle(StyleView)
   * @see org.xtext.UnivTlemcen.pfe.pfe.PfePackage#getBouton_Style()
   * @model
   * @generated
   */
  StyleView getStyle();

  /**
   * Sets the value of the '{@link org.xtext.UnivTlemcen.pfe.pfe.Bouton#getStyle <em>Style</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Style</em>' reference.
   * @see #getStyle()
   * @generated
   */
  void setStyle(StyleView value);

} // Bouton
